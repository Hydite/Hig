use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Default)]
pub struct CacheStats {
    pub hits: usize,
    pub misses: usize,
    pub bytes_reused: u64,
    pub bytes_compressed: u64,
}

impl CacheStats {
    pub fn hit_rate(&self) -> f64 {
        let total = self.hits + self.misses;
        if total == 0 {
            0.0
        } else {
            self.hits as f64 / total as f64
        }
    }
}

pub fn reusable_path_chunks(
    record: &PathCacheRecord,
    file_size: u64,
    chunk_size: u64,
) -> Option<Vec<PathChunkRecord>> {
    if record.chunk_size != Some(chunk_size) || record.chunks.is_empty() {
        return None;
    }
    let mut expected_offset = 0_u64;
    for chunk in &record.chunks {
        if chunk.file_offset != expected_offset || chunk.len == 0 {
            return None;
        }
        expected_offset = expected_offset.checked_add(chunk.len)?;
        if expected_offset > file_size {
            return None;
        }
    }
    if expected_offset != file_size {
        return None;
    }
    Some(record.chunks.clone())
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheRecord {
    pub hash_hex: String,
    pub block_file: String,
    pub original_size: u64,
    pub compressed_size: u64,
    pub codec: String,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct CacheIndex {
    #[serde(default)]
    pub records: BTreeMap<String, CacheRecord>,
    #[serde(default)]
    pub paths: BTreeMap<String, PathCacheRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PathCacheRecord {
    pub relative_path: String,
    pub size: u64,
    pub mtime_ns: i128,
    pub permissions: u32,
    pub content_hash: [u8; 32],
    pub last_seen_unix_ns: i128,
    #[serde(default)]
    pub chunk_size: Option<u64>,
    #[serde(default)]
    pub chunks: Vec<PathChunkRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PathChunkRecord {
    pub chunk_hash: [u8; 32],
    pub file_offset: u64,
    pub len: u64,
}

#[derive(Debug, Clone)]
pub struct CacheStore {
    root: PathBuf,
    index: CacheIndex,
}

impl CacheStore {
    pub fn open(root: impl AsRef<Path>) -> anyhow::Result<Self> {
        let root = root.as_ref().to_path_buf();
        fs::create_dir_all(root.join("blocks"))?;
        let index_path = root.join("index.json");
        let index = if index_path.exists() {
            serde_json::from_slice(&fs::read(index_path)?)?
        } else {
            CacheIndex::default()
        };
        Ok(Self { root, index })
    }

    pub fn get(&self, hash: &[u8; 32]) -> anyhow::Result<Option<Vec<u8>>> {
        let hash_hex = hex::encode(hash);
        let Some(record) = self.index.records.get(&hash_hex) else {
            return Ok(None);
        };
        let block_path = self.root.join("blocks").join(&record.block_file);
        if !block_path.exists() {
            return Ok(None);
        }
        Ok(Some(fs::read(block_path)?))
    }

    pub fn get_batch(&self, key: &[u8; 32]) -> anyhow::Result<Option<Vec<u8>>> {
        let key_hex = hex::encode(key);
        let block_path = self
            .root
            .join("blocks")
            .join(format!("{key_hex}.batch.zst"));
        if !block_path.exists() {
            return Ok(None);
        }
        Ok(Some(fs::read(block_path)?))
    }

    pub fn get_chunk(&self, hash: &[u8; 32]) -> anyhow::Result<Option<Vec<u8>>> {
        let hash_hex = hex::encode(hash);
        let block_path = self
            .root
            .join("blocks")
            .join(format!("{hash_hex}.chunk.zst"));
        if !block_path.exists() {
            return Ok(None);
        }
        Ok(Some(fs::read(block_path)?))
    }

    pub fn get_path_record(&self, relative_path: &str) -> Option<&PathCacheRecord> {
        self.index.paths.get(relative_path)
    }

    pub fn insert(
        &mut self,
        hash: &[u8; 32],
        original_size: u64,
        compressed: &[u8],
    ) -> anyhow::Result<()> {
        let hash_hex = hex::encode(hash);
        let block_file = format!("{hash_hex}.zst");
        fs::write(self.root.join("blocks").join(&block_file), compressed)?;
        self.index.records.insert(
            hash_hex.clone(),
            CacheRecord {
                hash_hex,
                block_file,
                original_size,
                compressed_size: compressed.len() as u64,
                codec: "zstd".to_string(),
            },
        );
        Ok(())
    }

    pub fn insert_batch(&mut self, key: &[u8; 32], compressed: &[u8]) -> anyhow::Result<()> {
        let key_hex = hex::encode(key);
        fs::write(
            self.root
                .join("blocks")
                .join(format!("{key_hex}.batch.zst")),
            compressed,
        )?;
        Ok(())
    }

    pub fn insert_chunk(&mut self, hash: &[u8; 32], compressed: &[u8]) -> anyhow::Result<()> {
        let hash_hex = hex::encode(hash);
        fs::write(
            self.root
                .join("blocks")
                .join(format!("{hash_hex}.chunk.zst")),
            compressed,
        )?;
        Ok(())
    }

    pub fn upsert_path_record(&mut self, record: PathCacheRecord) -> anyhow::Result<()> {
        self.index
            .paths
            .insert(record.relative_path.clone(), record);
        Ok(())
    }

    pub fn save(&self) -> anyhow::Result<()> {
        let bytes = serde_json::to_vec_pretty(&self.index)?;
        fs::write(self.root.join("index.json"), bytes)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cache_index_roundtrip() {
        let temp = tempfile::tempdir().unwrap();
        let hash = *blake3::hash(b"data").as_bytes();
        let mut cache = CacheStore::open(temp.path()).unwrap();
        assert!(cache.get(&hash).unwrap().is_none());
        cache.insert(&hash, 4, b"compressed").unwrap();
        cache.save().unwrap();
        let reopened = CacheStore::open(temp.path()).unwrap();
        assert_eq!(reopened.get(&hash).unwrap().unwrap(), b"compressed");
    }

    #[test]
    fn old_cache_index_without_paths_deserializes() {
        let index: CacheIndex = serde_json::from_str(r#"{"records":{}}"#).unwrap();
        assert!(index.records.is_empty());
        assert!(index.paths.is_empty());
        let record: PathCacheRecord = serde_json::from_str(
            r#"{"relative_path":"a.txt","size":4,"mtime_ns":1,"permissions":420,"content_hash":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"last_seen_unix_ns":2}"#,
        )
        .unwrap();
        assert_eq!(record.chunk_size, None);
        assert!(record.chunks.is_empty());
    }

    #[test]
    fn path_cache_roundtrip() {
        let temp = tempfile::tempdir().unwrap();
        let hash = *blake3::hash(b"data").as_bytes();
        let mut cache = CacheStore::open(temp.path()).unwrap();
        cache
            .upsert_path_record(PathCacheRecord {
                relative_path: "a.txt".to_string(),
                size: 4,
                mtime_ns: 123,
                permissions: 0o644,
                content_hash: hash,
                last_seen_unix_ns: 456,
                chunk_size: None,
                chunks: Vec::new(),
            })
            .unwrap();
        cache.save().unwrap();
        let reopened = CacheStore::open(temp.path()).unwrap();
        let record = reopened.get_path_record("a.txt").unwrap();
        assert_eq!(record.content_hash, hash);
        assert_eq!(record.mtime_ns, 123);
    }

    #[test]
    fn reusable_path_chunks_require_complete_coverage() {
        let hash = *blake3::hash(b"chunk").as_bytes();
        let mut record = PathCacheRecord {
            relative_path: "large.bin".to_string(),
            size: 16,
            mtime_ns: 123,
            permissions: 0o644,
            content_hash: hash,
            last_seen_unix_ns: 456,
            chunk_size: Some(8),
            chunks: vec![
                PathChunkRecord {
                    chunk_hash: hash,
                    file_offset: 0,
                    len: 8,
                },
                PathChunkRecord {
                    chunk_hash: hash,
                    file_offset: 8,
                    len: 8,
                },
            ],
        };
        assert!(reusable_path_chunks(&record, 16, 8).is_some());
        assert!(reusable_path_chunks(&record, 16, 4).is_none());
        record.chunks[1].file_offset = 9;
        assert!(reusable_path_chunks(&record, 16, 8).is_none());
        record.chunks[1].file_offset = 8;
        record.chunks[1].len = 9;
        assert!(reusable_path_chunks(&record, 16, 8).is_none());
    }
}
