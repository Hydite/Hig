use anyhow::Context;
use clap::{Parser, Subcommand, ValueEnum};
use hig_core::{
    ArchiveFormat, ArchiveSizeBreakdown, BatchOptions, BlockStats, CacheStats, ChunkOptions,
    Compression, DaemonMode, DaemonRequest, DaemonResponse, EncryptionMode, JobKeyMaterial,
    KdfProfile, L1CacheReport, L2CacheReport, ManifestFormat, PackAuthMode, PackCriticalTimings,
    PackJobRequest, PackOptions, PackReport, PackResponseMode, PackSummary, PackTimings,
    PipelineOptions, PipelineReport, ScanStats, SerializablePackOptions, SessionReport, SolidMode,
    SpeedMode, UnpackOptions, bench, cache_writer_available, daemon_socket_path, daemon_status,
    default_session_ttl, derive_key, derive_session_binding, pack, random_bytes, request_daemon,
    run_daemon_server, stop_daemon, unpack,
};
use std::ffi::OsStr;
use std::fs;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command as ProcessCommand, Stdio};
use std::time::Duration;
use std::time::{Instant, SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
enum BenchSuite {
    Source,
    Lobehub,
    Small500,
    Textmix,
    Repeat4m,
    Random8m,
    Binarymix,
    All,
}

#[derive(Debug, Parser)]
#[command(
    name = "hig",
    version,
    about = "High-speed cached encrypted archive prototype"
)]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ReportMode {
    Short,
    Verbose,
    Json,
    Quiet,
}

#[derive(Debug, Clone, Copy)]
struct ReportFlags {
    verbose: bool,
    json: bool,
    quiet: bool,
}

impl ReportFlags {
    fn mode(self) -> anyhow::Result<ReportMode> {
        let count = usize::from(self.verbose) + usize::from(self.json) + usize::from(self.quiet);
        anyhow::ensure!(
            count <= 1,
            "--verbose, --json, and --quiet are mutually exclusive"
        );
        Ok(if self.json {
            ReportMode::Json
        } else if self.verbose {
            ReportMode::Verbose
        } else if self.quiet {
            ReportMode::Quiet
        } else {
            ReportMode::Short
        })
    }
}

#[derive(Debug, Subcommand)]
enum Command {
    Pack {
        input_dir: PathBuf,
        #[arg(short, long)]
        output: PathBuf,
        #[arg(long)]
        password: Option<String>,
        #[arg(
            long,
            default_value = "password",
            help = "Encryption mode: password uses Argon2id + ChaCha20-Poly1305; none provides no confidentiality or authentication"
        )]
        encryption: EncryptionMode,
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        #[arg(long)]
        threads: Option<usize>,
        #[arg(long, default_value = "zstd")]
        compression: Compression,
        #[arg(
            long,
            help = "Explicit zstd level; balanced otherwise selects level 5 or probes large chunks"
        )]
        level: Option<i32>,
        #[arg(long)]
        no_cache: bool,
        #[arg(long, default_value = "higv2")]
        format: ArchiveFormat,
        #[arg(long, default_value = "compact")]
        manifest_format: ManifestFormat,
        #[arg(long)]
        no_batch: bool,
        #[arg(long, default_value_t = 65_536)]
        small_file_threshold: u64,
        #[arg(long, default_value_t = 4_194_304)]
        max_batch_raw_bytes: u64,
        #[arg(long)]
        no_chunk: bool,
        #[arg(long, default_value_t = 8_388_608)]
        chunk_file_threshold: u64,
        #[arg(long, default_value_t = 1_048_576)]
        chunk_size: u64,
        #[arg(
            long,
            default_value = "balanced",
            help = "balanced keeps the safest defaults; fastest trusts metadata and reuses locally sealed ciphertext, revealing block equality"
        )]
        speed: SpeedMode,
        #[arg(
            long,
            help = "KDF profile: secure, interactive, or benchmark-only fast-bench. fastest defaults to interactive unless explicitly set"
        )]
        kdf_profile: Option<KdfProfile>,
        #[arg(
            long,
            help = "Trust path/size/mtime/permissions metadata to reuse cached hashes without rereading files. Fast, but unsafe if file contents changed while metadata was preserved. --speed fastest enables this automatically."
        )]
        trust_metadata: bool,
        #[arg(
            long,
            help = "Use a previously unlocked in-memory Hig session key and skip KDF"
        )]
        use_session: bool,
        #[arg(
            long,
            default_value = "auto",
            help = "Daemon mode: auto, off, or required"
        )]
        daemon: DaemonMode,
        #[arg(long, default_value = "auto", help = "Solid grouping: auto or off")]
        solid: SolidMode,
        #[arg(long, help = "Print full human telemetry")]
        verbose: bool,
        #[arg(long, help = "Print complete PackReport as JSON")]
        json: bool,
        #[arg(long, help = "Suppress success output")]
        quiet: bool,
    },
    Unpack {
        archive_file: PathBuf,
        #[arg(short = 'd', long)]
        output_dir: PathBuf,
        #[arg(long)]
        password: Option<String>,
        #[arg(long)]
        overwrite: bool,
    },
    Bench {
        input_dir: PathBuf,
        #[arg(short, long, default_value = "bench.hig")]
        output: PathBuf,
        #[arg(long)]
        password: Option<String>,
        #[arg(
            long,
            default_value = "password",
            help = "Encryption mode: password uses Argon2id + ChaCha20-Poly1305; none provides no confidentiality or authentication"
        )]
        encryption: EncryptionMode,
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        #[arg(long)]
        threads: Option<usize>,
        #[arg(long, default_value = "zstd")]
        compression: Compression,
        #[arg(
            long,
            help = "Explicit zstd level; balanced otherwise selects level 5 or probes large chunks"
        )]
        level: Option<i32>,
        #[arg(long)]
        no_cache: bool,
        #[arg(long, default_value = "higv2")]
        format: ArchiveFormat,
        #[arg(long, default_value = "compact")]
        manifest_format: ManifestFormat,
        #[arg(long)]
        no_batch: bool,
        #[arg(long, default_value_t = 65_536)]
        small_file_threshold: u64,
        #[arg(long, default_value_t = 4_194_304)]
        max_batch_raw_bytes: u64,
        #[arg(long)]
        no_chunk: bool,
        #[arg(long, default_value_t = 8_388_608)]
        chunk_file_threshold: u64,
        #[arg(long, default_value_t = 1_048_576)]
        chunk_size: u64,
        #[arg(long, default_value = "balanced")]
        speed: SpeedMode,
        #[arg(
            long,
            help = "KDF profile: secure, interactive, or fast-bench. fast-bench is for benchmarking only and is not recommended for production archives."
        )]
        kdf_profile: Option<KdfProfile>,
        #[arg(
            long,
            help = "Trust path/size/mtime/permissions metadata to reuse cached hashes without rereading files. Fast, but unsafe if file contents changed while metadata was preserved. --speed fastest enables this automatically."
        )]
        trust_metadata: bool,
        #[arg(
            long,
            help = "Use a previously unlocked in-memory Hig session key and skip KDF"
        )]
        use_session: bool,
        #[arg(
            long,
            default_value = "auto",
            help = "Daemon mode: auto, off, or required"
        )]
        daemon: DaemonMode,
        #[arg(long, default_value = "auto", help = "Solid grouping: auto or off")]
        solid: SolidMode,
        #[arg(long, help = "Print full human telemetry")]
        verbose: bool,
        #[arg(long, help = "Print complete PackReport as JSON")]
        json: bool,
        #[arg(long, help = "Suppress success output")]
        quiet: bool,
        #[arg(
            long,
            help = "Compare Hig against zip, tar+gzip, and tar+zstd, writing artifacts/hig-v1.8.5-benchmark.md"
        )]
        compare: bool,
        #[arg(
            long,
            help = "Directory used for benchmark temporary files and copy baseline qualification"
        )]
        bench_dir: Option<PathBuf>,
        #[arg(
            long,
            default_value = "all",
            help = "Benchmark corpus suite: source, lobehub, small500, textmix, repeat4m, random8m, binarymix, or all"
        )]
        bench_suite: BenchSuite,
    },
    Session {
        #[command(subcommand)]
        command: SessionCommand,
    },
    Daemon {
        #[command(subcommand)]
        command: DaemonCommand,
    },
    Cache {
        #[command(subcommand)]
        command: CacheCommand,
    },
}

#[derive(Debug, Subcommand)]
enum SessionCommand {
    Unlock {
        #[arg(long)]
        password: String,
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        #[arg(long)]
        ttl_secs: Option<u64>,
        #[arg(long, default_value = "secure")]
        kdf_profile: KdfProfile,
    },
    Status {
        #[arg(long)]
        cache_dir: Option<PathBuf>,
    },
    Clear {
        #[arg(long)]
        cache_dir: Option<PathBuf>,
    },
}

#[derive(Debug, Subcommand)]
enum DaemonCommand {
    Start {
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        #[arg(long)]
        ttl_secs: Option<u64>,
    },
    Status {
        #[arg(long)]
        cache_dir: Option<PathBuf>,
    },
    Stop {
        #[arg(long)]
        cache_dir: Option<PathBuf>,
    },
    #[command(hide = true)]
    Serve {
        #[arg(long)]
        cache_dir: PathBuf,
        #[arg(long)]
        ttl_secs: u64,
    },
}

#[derive(Debug, Subcommand)]
enum CacheCommand {
    Status {
        #[arg(long)]
        cache_dir: Option<PathBuf>,
    },
    Gc {
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        #[arg(long)]
        dry_run: bool,
    },
    Compact {
        #[arg(long)]
        cache_dir: Option<PathBuf>,
        #[arg(long)]
        dry_run: bool,
    },
}

fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Command::Pack {
            input_dir,
            output,
            password,
            encryption,
            cache_dir,
            threads,
            compression,
            level,
            no_cache,
            format,
            manifest_format,
            no_batch,
            small_file_threshold,
            max_batch_raw_bytes,
            no_chunk,
            chunk_file_threshold,
            chunk_size,
            speed,
            kdf_profile,
            trust_metadata,
            use_session,
            daemon,
            solid,
            verbose,
            json,
            quiet,
        } => {
            let report_mode = ReportFlags {
                verbose,
                json,
                quiet,
            }
            .mode()?;
            validate_pack_encryption_args(encryption, password.as_deref(), use_session)?;
            let kdf_profile = effective_kdf_profile(speed, kdf_profile);
            let solid = effective_solid(speed, solid);
            let options = PackOptions {
                input_dir,
                output_file: output,
                password,
                encryption,
                cache_dir,
                threads,
                compression,
                level,
                use_cache: !no_cache,
                trust_metadata,
                format,
                batch: BatchOptions {
                    enabled: !no_batch,
                    small_file_threshold,
                    max_batch_raw_bytes,
                },
                chunk: ChunkOptions {
                    enabled: !no_chunk,
                    chunk_file_threshold,
                    chunk_size,
                },
                speed,
                kdf_profile,
                sealed_cache: speed == SpeedMode::Fastest,
                manifest_format,
                use_session,
                session_required: use_session,
                session_ttl_secs: None,
                solid,
                pipeline: PipelineOptions {
                    daemon_mode: daemon,
                    ..PipelineOptions::default()
                },
            };
            let report = pack_with_daemon_policy(options, report_mode)?;
            print_report("pack", &report, report_mode)?;
        }
        Command::Unpack {
            archive_file,
            output_dir,
            password,
            overwrite,
        } => {
            unpack(UnpackOptions {
                archive_file,
                output_dir,
                password,
                overwrite,
            })?;
            println!("unpack: ok");
        }
        Command::Bench {
            input_dir,
            output,
            password,
            encryption,
            cache_dir,
            threads,
            compression,
            level,
            no_cache,
            format,
            manifest_format,
            no_batch,
            small_file_threshold,
            max_batch_raw_bytes,
            no_chunk,
            chunk_file_threshold,
            chunk_size,
            speed,
            kdf_profile,
            trust_metadata,
            use_session,
            daemon,
            solid,
            verbose,
            json,
            quiet,
            compare,
            bench_dir,
            bench_suite,
        } => {
            let report_mode = ReportFlags {
                verbose,
                json,
                quiet,
            }
            .mode()?;
            validate_pack_encryption_args(encryption, password.as_deref(), use_session)?;
            let kdf_profile = effective_kdf_profile(speed, kdf_profile);
            let solid = effective_solid(speed, solid);
            if compare {
                if password.is_none() {
                    anyhow::bail!("--compare requires --password for secure benchmark rows");
                }
                run_compare(CompareOptions {
                    input_dir,
                    output,
                    password,
                    cache_dir,
                    threads,
                    compression,
                    level,
                    use_cache: !no_cache,
                    batch: BatchOptions {
                        enabled: !no_batch,
                        small_file_threshold,
                        max_batch_raw_bytes,
                    },
                    chunk: ChunkOptions {
                        enabled: !no_chunk,
                        chunk_file_threshold,
                        chunk_size,
                    },
                    bench_dir,
                    bench_suite,
                    manifest_format,
                    use_session,
                    daemon,
                    solid,
                    report_mode,
                })?;
                return Ok(());
            }
            let report = bench(PackOptions {
                input_dir,
                output_file: output,
                password,
                encryption,
                cache_dir,
                threads,
                compression,
                level,
                use_cache: !no_cache,
                trust_metadata,
                format,
                batch: BatchOptions {
                    enabled: !no_batch,
                    small_file_threshold,
                    max_batch_raw_bytes,
                },
                chunk: ChunkOptions {
                    enabled: !no_chunk,
                    chunk_file_threshold,
                    chunk_size,
                },
                speed,
                kdf_profile,
                sealed_cache: speed == SpeedMode::Fastest,
                manifest_format,
                use_session,
                session_required: use_session,
                session_ttl_secs: None,
                solid,
                pipeline: PipelineOptions {
                    daemon_mode: daemon,
                    ..PipelineOptions::default()
                },
            })?;
            print_report("bench:first", &report.first, report_mode)?;
            print_report("bench:second", &report.second, report_mode)?;
            if report_mode != ReportMode::Quiet && report.second.duration.as_secs_f64() > 0.0 {
                println!(
                    "bench:speedup {:.2}x",
                    report.first.duration.as_secs_f64() / report.second.duration.as_secs_f64()
                );
            }
        }
        Command::Session { command } => handle_session(command)?,
        Command::Daemon { command } => handle_daemon(command)?,
        Command::Cache { command } => handle_cache(command)?,
    }
    Ok(())
}

fn handle_cache(command: CacheCommand) -> anyhow::Result<()> {
    let (cache_dir, request) = match command {
        CacheCommand::Status { cache_dir } => (
            cache_dir.unwrap_or_else(default_cache_dir),
            DaemonRequest::CacheStatus,
        ),
        CacheCommand::Gc { cache_dir, dry_run } => (
            cache_dir.unwrap_or_else(default_cache_dir),
            DaemonRequest::CacheGc { dry_run },
        ),
        CacheCommand::Compact { cache_dir, dry_run } => (
            cache_dir.unwrap_or_else(default_cache_dir),
            DaemonRequest::CacheCompact { dry_run },
        ),
    };
    ensure_daemon(&cache_dir, default_session_ttl(None))?;
    match request_daemon(&cache_dir, request)? {
        Some(DaemonResponse::CacheMaintenance(report)) => {
            println!(
                "cache: total_bytes={} budget_bytes={} files={} removable_bytes={} removed_bytes={} compacted_bytes={} generation={} journal_bytes={} journal_entries={} journal_replayed_entries={} journal_compacted_entries={} journal_dirty_record_estimate={} journal_compact_recommended={} journal_estimated_reclaimed_bytes={} last_compact_unix_ns={} dry_run={}",
                report.total_bytes,
                report.budget_bytes,
                report.files,
                report.removable_bytes,
                report.removed_bytes,
                report.compacted_bytes,
                report.generation,
                report.journal_bytes,
                report.journal_entries,
                report.journal_replayed_entries,
                report.journal_compacted_entries,
                report.journal_dirty_record_estimate,
                report.journal_compact_recommended,
                report.journal_estimated_reclaimed_bytes,
                report.last_compact_unix_ns,
                report.dry_run
            );
            Ok(())
        }
        Some(DaemonResponse::Error { message, .. }) => anyhow::bail!(message),
        _ => anyhow::bail!("daemon did not return cache maintenance status"),
    }
}

fn validate_pack_encryption_args(
    encryption: EncryptionMode,
    password: Option<&str>,
    use_session: bool,
) -> anyhow::Result<()> {
    match (encryption, password, use_session) {
        (EncryptionMode::Password, Some(value), _) if !value.is_empty() => Ok(()),
        (EncryptionMode::Password, None, true) => Ok(()),
        (EncryptionMode::Password, _, _) => {
            anyhow::bail!("--encryption password requires --password")
        }
        (EncryptionMode::None, None, false) => Ok(()),
        (EncryptionMode::None, _, _) => {
            anyhow::bail!("--password and --use-session cannot be used with --encryption none")
        }
    }
}

fn pack_with_daemon_policy(
    options: PackOptions,
    report_mode: ReportMode,
) -> anyhow::Result<PackReport> {
    if options.format == ArchiveFormat::HigV1
        || options.pipeline.daemon_mode == DaemonMode::Off
        || !options.use_cache
    {
        return pack(options);
    }
    let cache_dir = options
        .cache_dir
        .clone()
        .unwrap_or_else(|| options.input_dir.join(".hig-cache"));
    fs::create_dir_all(&cache_dir)?;
    let connect_started = Instant::now();
    let daemon_ready = ensure_daemon(&cache_dir, default_session_ttl(None));
    if let Err(error) = daemon_ready {
        if options.pipeline.daemon_mode == DaemonMode::Required || options.use_session {
            return Err(error);
        }
        return pack(options);
    }
    let daemon_connect_us = connect_started.elapsed().as_micros() as u64;
    let kdf = options.kdf_profile.params();
    let binding = derive_session_binding(&cache_dir, options.kdf_profile, &kdf, options.encryption);
    let mut ephemeral_key = None;
    let auth_mode = if options.encryption == EncryptionMode::None {
        PackAuthMode::None
    } else if options.use_session {
        PackAuthMode::UseSession
    } else if options.password.is_some() {
        let salt = random_bytes::<16>();
        let password = options
            .password
            .as_deref()
            .ok_or_else(|| anyhow::anyhow!("password encryption requires a password"))?;
        let key = derive_key(password, &salt, &kdf)?;
        ephemeral_key = Some(JobKeyMaterial { key, salt });
        PackAuthMode::PreferSessionOrJobKey
    } else {
        PackAuthMode::UseSession
    };
    let request = DaemonRequest::Pack(PackJobRequest {
        options: SerializablePackOptions::from_pack(&options),
        binding_fingerprint: Some(binding.fingerprint),
        ephemeral_key,
        auth_mode,
        response_mode: response_mode_for_report(report_mode),
    });
    let socket_started = Instant::now();
    let response = request_daemon(&cache_dir, request);
    let pack_roundtrip_us = socket_started.elapsed().as_micros() as u64;
    match response {
        Ok(Some(DaemonResponse::PackComplete(mut report))) => {
            report.timings_us.daemon_connect_us = daemon_connect_us;
            report.timings_us.socket_request_us = pack_roundtrip_us;
            report.timings_us.socket_pack_roundtrip_us = pack_roundtrip_us;
            Ok(*report)
        }
        Ok(Some(DaemonResponse::PackSummary(mut summary))) => {
            summary.timings_us.daemon_connect_us = daemon_connect_us;
            summary.timings_us.socket_request_us = pack_roundtrip_us;
            summary.timings_us.socket_pack_roundtrip_us = pack_roundtrip_us;
            Ok(report_from_summary(summary))
        }
        Err(error) if options.pipeline.daemon_mode == DaemonMode::Auto && !options.use_session => {
            if cache_writer_available(&cache_dir)? {
                eprintln!("hig: daemon exited, falling back to standalone: {error}");
                pack(options)
            } else {
                Err(error)
            }
        }
        Ok(Some(DaemonResponse::Error { code, message })) => {
            anyhow::bail!("daemon {:?}: {}", code, message)
        }
        Ok(_) => anyhow::bail!("daemon returned an unexpected pack response"),
        Err(error) => Err(error),
    }
}

fn response_mode_for_report(report_mode: ReportMode) -> PackResponseMode {
    match report_mode {
        ReportMode::Short | ReportMode::Quiet => PackResponseMode::Summary,
        ReportMode::Verbose | ReportMode::Json => PackResponseMode::Full,
    }
}

fn report_from_summary(summary: PackSummary) -> PackReport {
    let mut timings_us = summary.timings_us.clone();
    if timings_us.total_us == 0 {
        timings_us.total_us = summary.duration_us;
    }
    PackReport {
        input_files: summary.input_files,
        input_bytes: summary.input_bytes,
        archive_bytes: summary.archive_bytes,
        duration: Duration::from_micros(summary.duration_us),
        timings: PackTimings {
            scan_ms: (timings_us.walk_us + timings_us.metadata_us + timings_us.hash_us) as u128
                / 1000,
            plan_ms: timings_us.plan_us as u128 / 1000,
            kdf_ms: 0,
            pack_blocks_ms: timings_us.read_us.saturating_add(timings_us.compression_us) as u128
                / 1000,
            write_ms: timings_us.output_write_us as u128 / 1000,
            crypto_ms: timings_us.crypto_us as u128 / 1000,
            read_ms: timings_us.read_us as u128 / 1000,
            compression_ms: timings_us.compression_us as u128 / 1000,
            ..PackTimings::default()
        },
        cache: CacheStats {
            hits: summary.cache_hits,
            misses: summary.cache_misses,
            ..CacheStats::default()
        },
        scan: ScanStats::default(),
        blocks: BlockStats {
            solid_groups: summary.solid_groups,
            solid_files: summary.solid_files,
            cache_policy_misses: summary.cache_policy_misses,
            ..BlockStats::default()
        },
        speed: summary.speed,
        kdf_profile: summary.kdf_profile,
        encryption_mode: summary.encryption_mode,
        worker_count: 0,
        writer_strategy: Default::default(),
        archive_preallocated_bytes: 0,
        cached_payload_open_count: 0,
        cached_range_open_count: 0,
        cached_payload_read_bytes: 0,
        prefetched_bytes: 0,
        peak_pipeline_memory_bytes: 0,
        direct_write_count: 0,
        buffered_write_count: 0,
        preallocation_enabled: false,
        critical: PackCriticalTimings::default(),
        metadata: ArchiveSizeBreakdown {
            total_archive_bytes: summary.archive_bytes,
            ..ArchiveSizeBreakdown::default()
        },
        session: SessionReport {
            session_used: summary.session_used,
            kdf_skipped_by_session: summary.session_used,
            ..SessionReport::default()
        },
        l1: L1CacheReport::default(),
        l2: L2CacheReport {
            cache_index_commit_ms: summary.cache_index_commit_ms,
            cache_commit_mode: summary.cache_commit_mode,
            cache_shards_written: summary.cache_shards_written,
            ..L2CacheReport::default()
        },
        pipeline: PipelineReport {
            daemon_used: true,
            ..PipelineReport::default()
        },
        timings_us,
    }
}

fn effective_kdf_profile(speed: SpeedMode, requested: Option<KdfProfile>) -> KdfProfile {
    requested.unwrap_or(match speed {
        SpeedMode::Balanced => KdfProfile::Secure,
        SpeedMode::Fastest => KdfProfile::Interactive,
    })
}

fn effective_solid(speed: SpeedMode, requested: SolidMode) -> SolidMode {
    match speed {
        SpeedMode::Balanced => requested,
        SpeedMode::Fastest => SolidMode::Off,
    }
}

fn handle_session(command: SessionCommand) -> anyhow::Result<()> {
    match command {
        SessionCommand::Unlock {
            password,
            cache_dir,
            ttl_secs,
            kdf_profile,
        } => {
            let cache_dir = cache_dir.unwrap_or_else(default_cache_dir);
            fs::create_dir_all(&cache_dir)?;
            let ttl_secs = default_session_ttl(ttl_secs);
            let started = Instant::now();
            ensure_daemon(&cache_dir, ttl_secs)?;
            unlock_session_for_cache(&cache_dir, &password, kdf_profile, ttl_secs)?;
            let status = daemon_status(&cache_dir)?;
            println!(
                "session: unlocked cache_dir={} ttl_secs={} age_secs={} kdf_ms={}",
                cache_dir.display(),
                ttl_secs,
                status.session_age_secs,
                started.elapsed().as_millis()
            );
            Ok(())
        }
        SessionCommand::Status { cache_dir } => {
            let cache_dir = cache_dir.unwrap_or_else(default_cache_dir);
            let status = daemon_status(&cache_dir)?;
            if status.session_active {
                println!(
                    "session: active cache_dir={} age_secs={} ttl_secs={}",
                    cache_dir.display(),
                    status.session_age_secs,
                    status.ttl_secs
                );
            } else {
                println!("session: inactive cache_dir={}", cache_dir.display());
            }
            Ok(())
        }
        SessionCommand::Clear { cache_dir } => {
            let cache_dir = cache_dir.unwrap_or_else(default_cache_dir);
            let cleared = matches!(
                request_daemon(&cache_dir, DaemonRequest::ClearSession)?,
                Some(DaemonResponse::SessionCleared)
            );
            println!(
                "session: {} cache_dir={}",
                if cleared { "cleared" } else { "inactive" },
                cache_dir.display()
            );
            Ok(())
        }
    }
}

fn handle_daemon(command: DaemonCommand) -> anyhow::Result<()> {
    match command {
        DaemonCommand::Start {
            cache_dir,
            ttl_secs,
        } => {
            let cache_dir = cache_dir.unwrap_or_else(default_cache_dir);
            fs::create_dir_all(&cache_dir)?;
            let ttl_secs = default_session_ttl(ttl_secs);
            ensure_daemon(&cache_dir, ttl_secs)?;
            let status = daemon_status(&cache_dir)?;
            println!(
                "daemon: started cache_dir={} active={} ttl_secs={}",
                cache_dir.display(),
                status.active,
                ttl_secs
            );
            Ok(())
        }
        DaemonCommand::Status { cache_dir } => {
            let cache_dir = cache_dir.unwrap_or_else(default_cache_dir);
            let status = daemon_status(&cache_dir)?;
            if status.active {
                println!(
                    "daemon: active cache_dir={} age_secs={} uptime_secs={} ttl_secs={} jobs_completed={} active_jobs={} queued_jobs={} cache_open_count={} session_active={} journal_bytes={}",
                    cache_dir.display(),
                    status.age_secs,
                    status.uptime_secs,
                    status.ttl_secs,
                    status.jobs_completed,
                    status.active_jobs,
                    status.queued_jobs,
                    status.cache_open_count,
                    status.session_active,
                    status.journal_bytes
                );
            } else {
                println!("daemon: inactive cache_dir={}", cache_dir.display());
            }
            Ok(())
        }
        DaemonCommand::Stop { cache_dir } => {
            let cache_dir = cache_dir.unwrap_or_else(default_cache_dir);
            let stopped = stop_daemon(&cache_dir)?;
            println!(
                "daemon: {} cache_dir={}",
                if stopped { "stopped" } else { "inactive" },
                cache_dir.display()
            );
            Ok(())
        }
        DaemonCommand::Serve {
            cache_dir,
            ttl_secs,
        } => run_daemon_server(&cache_dir, ttl_secs),
    }
}

fn ensure_daemon(cache_dir: &Path, ttl_secs: u64) -> anyhow::Result<()> {
    if daemon_status(cache_dir)?.active {
        return Ok(());
    }
    fs::create_dir_all(cache_dir)?;
    let socket = daemon_socket_path(cache_dir);
    if socket.exists() {
        let _ = fs::remove_file(&socket);
    }
    let mut child = ProcessCommand::new(std::env::current_exe()?)
        .arg("daemon")
        .arg("serve")
        .arg("--cache-dir")
        .arg(cache_dir)
        .arg("--ttl-secs")
        .arg(ttl_secs.to_string())
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()?;
    for _ in 0..100 {
        if socket.exists() && daemon_status(cache_dir)?.active {
            return Ok(());
        }
        if child.try_wait()?.is_some() {
            anyhow::bail!("Hig daemon exited during startup");
        }
        std::thread::sleep(std::time::Duration::from_millis(20));
    }
    anyhow::bail!("Hig daemon did not create its socket")
}

fn unlock_session_for_cache(
    cache_dir: &Path,
    password: &str,
    kdf_profile: KdfProfile,
    ttl_secs: u64,
) -> anyhow::Result<()> {
    fs::create_dir_all(cache_dir)?;
    ensure_daemon(cache_dir, ttl_secs)?;
    let kdf = kdf_profile.params();
    let binding = derive_session_binding(cache_dir, kdf_profile, &kdf, EncryptionMode::Password);
    let salt = match request_daemon(
        cache_dir,
        DaemonRequest::UnlockChallenge {
            binding: binding.clone(),
        },
    )? {
        Some(DaemonResponse::UnlockChallenge { salt }) => salt,
        Some(DaemonResponse::Error { message, .. }) => anyhow::bail!(message),
        _ => anyhow::bail!("daemon did not provide an unlock challenge"),
    };
    let mut key = derive_key(password, &salt, &kdf)?;
    let response = request_daemon(
        cache_dir,
        DaemonRequest::InstallSessionKey {
            binding,
            key,
            salt,
            ttl_secs,
        },
    );
    use zeroize::Zeroize;
    key.zeroize();
    match response? {
        Some(DaemonResponse::SessionInstalled) => Ok(()),
        Some(DaemonResponse::Error { message, .. }) => anyhow::bail!(message),
        _ => anyhow::bail!("daemon did not install the session key"),
    }
}

fn default_cache_dir() -> PathBuf {
    PathBuf::from(".hig-cache")
}

fn print_report(label: &str, report: &PackReport, mode: ReportMode) -> anyhow::Result<()> {
    match mode {
        ReportMode::Short => print_short_report(label, report),
        ReportMode::Verbose => print_verbose_report(label, report),
        ReportMode::Json => print_json_report(label, report),
        ReportMode::Quiet => Ok(()),
    }
}

fn print_short_report(label: &str, report: &PackReport) -> anyhow::Result<()> {
    let seconds = report.duration.as_secs_f64().max(0.000_001);
    let mib = report.input_bytes as f64 / 1024.0 / 1024.0;
    let reduction = if report.input_bytes == 0 {
        0.0
    } else {
        (1.0 - report.archive_bytes as f64 / report.input_bytes as f64) * 100.0
    };
    println!(
        "{label}: files={} input_bytes={} archive_bytes={} reduction={:.2}% duration_ms={:.3} throughput_mib_s={:.2} encryption={:?} speed={:?} cache_hit_rate={:.2}%",
        report.input_files,
        report.input_bytes,
        report.archive_bytes,
        reduction,
        report.duration.as_secs_f64() * 1000.0,
        mib / seconds,
        report.encryption_mode,
        report.speed,
        report.cache.hit_rate() * 100.0
    );
    Ok(())
}

fn print_json_report(label: &str, report: &PackReport) -> anyhow::Result<()> {
    let value = serde_json::json!({
        "label": label,
        "report": report,
    });
    println!("{}", serde_json::to_string(&value)?);
    Ok(())
}

fn print_verbose_report(label: &str, report: &PackReport) -> anyhow::Result<()> {
    let seconds = report.duration.as_secs_f64().max(0.000_001);
    let mib = report.input_bytes as f64 / 1024.0 / 1024.0;
    println!(
        "{label}: files={} input_bytes={} archive_bytes={} duration_ms={} throughput_mib_s={:.2} encryption={:?} speed={:?} kdf_profile={:?} session_used={} session_lookup_ms={} session_key_age_secs={} kdf_skipped_by_session={} workers={} writer_strategy={:?} preallocated_bytes={} preallocation_enabled={} cached_payload_opens={} cached_range_opens={} cached_payload_read_bytes={} prefetched_bytes={} direct_writes={} buffered_writes={} peak_pipeline_memory_bytes={} scan_ms={} plan_ms={} kdf_ms={} kdf_overlapped_ms={} read_ms={} compression_ms={} crypto_ms={} pack_blocks_ms={} manifest_ms={} write_ms={} payload_read_ms={} payload_write_ms={} writer_wait_ms={} output_flush_ms={} output_rename_ms={} cache_hits={} cache_misses={} cache_hit_rate={:.2}% hashed_files={} metadata_hash_reuses={} scan_cache_hits={} scan_cache_misses={} scan_cache_hit_rate={:.2}% chunk_metadata_reuses={} chunk_metadata_misses={} trusted_bytes_skipped={} batch_blocks={} single_blocks={} batched_files={} batch_cache_hits={} batch_cache_misses={} solid_groups={} solid_files={} solid_cache_hits={} solid_cache_misses={} solid_group_bytes={} chunked_files={} chunk_blocks={} chunk_cache_hits={} chunk_cache_misses={} chunk_bytes_reused={} chunk_bytes_compressed={} chunk_plan_cache_hits={} chunk_plan_cache_misses={} sealed_block_hits={} sealed_block_misses={} sealed_bytes_reused={} reencrypted_cache_hits={} payload_source_cache_files={} payload_source_memory_bytes={} cache_pack_hits={} cache_pack_misses={} cache_pack_fallbacks={}",
        report.input_files,
        report.input_bytes,
        report.archive_bytes,
        report.duration.as_millis(),
        mib / seconds,
        report.encryption_mode,
        report.speed,
        report.kdf_profile,
        report.session.session_used,
        report.session.session_lookup_ms,
        report.session.session_key_age_secs,
        report.session.kdf_skipped_by_session,
        report.worker_count,
        report.writer_strategy,
        report.archive_preallocated_bytes,
        report.preallocation_enabled,
        report.cached_payload_open_count,
        report.cached_range_open_count,
        report.cached_payload_read_bytes,
        report.prefetched_bytes,
        report.direct_write_count,
        report.buffered_write_count,
        report.peak_pipeline_memory_bytes,
        report.timings.scan_ms,
        report.timings.plan_ms,
        report.timings.kdf_ms,
        report.timings.kdf_overlapped_ms,
        report.timings.read_ms,
        report.timings.compression_ms,
        report.timings.crypto_ms,
        report.timings.pack_blocks_ms,
        report.timings.manifest_ms,
        report.timings.write_ms,
        report.timings.payload_read_ms,
        report.timings.payload_write_ms,
        report.timings.writer_wait_ms,
        report.timings.output_flush_ms,
        report.timings.output_rename_ms,
        report.cache.hits,
        report.cache.misses,
        report.cache.hit_rate() * 100.0,
        report.scan.hashed_files,
        report.scan.metadata_hash_reuses,
        report.scan.scan_cache_hits,
        report.scan.scan_cache_misses,
        report.scan.scan_cache_hit_rate() * 100.0,
        report.scan.chunk_metadata_reuses,
        report.scan.chunk_metadata_misses,
        report.scan.trusted_bytes_skipped,
        report.blocks.batch_blocks,
        report.blocks.single_blocks,
        report.blocks.batched_files,
        report.blocks.batch_cache_hits,
        report.blocks.batch_cache_misses,
        report.blocks.solid_groups,
        report.blocks.solid_files,
        report.blocks.solid_cache_hits,
        report.blocks.solid_cache_misses,
        report.blocks.solid_group_bytes,
        report.blocks.chunked_files,
        report.blocks.chunk_blocks,
        report.blocks.chunk_cache_hits,
        report.blocks.chunk_cache_misses,
        report.blocks.chunk_bytes_reused,
        report.blocks.chunk_bytes_compressed,
        report.blocks.chunk_plan_cache_hits,
        report.blocks.chunk_plan_cache_misses,
        report.blocks.sealed_block_hits,
        report.blocks.sealed_block_misses,
        report.blocks.sealed_bytes_reused,
        report.blocks.reencrypted_cache_hits,
        report.blocks.payload_source_cache_files,
        report.blocks.payload_source_memory_bytes,
        report.blocks.cache_pack_hits,
        report.blocks.cache_pack_misses,
        report.blocks.cache_pack_fallbacks
    );
    println!(
        "{label}:us total_us={} daemon_connect_us={} socket_request_us={} socket_connect_us={} socket_pack_roundtrip_us={} daemon_auth_us={} daemon_job_execute_us={} daemon_response_bytes={} client_decode_us={} queue_wait_us={} cache_hot_lookup_us={} walk_us={} metadata_us={} hash_us={} plan_us={} read_us={} compression_us={} crypto_us={} cache_commit_wait_us={} cache_commit_us={} manifest_serialize_us={} manifest_compress_us={} manifest_encrypt_us={} output_create_us={} output_write_us={} output_flush_us={} output_rename_us={} response_serialize_us={} unattributed_us={}",
        report.timings_us.total_us,
        report.timings_us.daemon_connect_us,
        report.timings_us.socket_request_us,
        report.timings_us.socket_connect_us,
        report.timings_us.socket_pack_roundtrip_us,
        report.timings_us.daemon_auth_us,
        report.timings_us.daemon_job_execute_us,
        report.timings_us.daemon_response_bytes,
        report.timings_us.client_decode_us,
        report.timings_us.queue_wait_us,
        report.timings_us.cache_hot_lookup_us,
        report.timings_us.walk_us,
        report.timings_us.metadata_us,
        report.timings_us.hash_us,
        report.timings_us.plan_us,
        report.timings_us.read_us,
        report.timings_us.compression_us,
        report.timings_us.crypto_us,
        report.timings_us.cache_commit_wait_us,
        report.timings_us.cache_commit_us,
        report.timings_us.manifest_serialize_us,
        report.timings_us.manifest_compress_us,
        report.timings_us.manifest_encrypt_us,
        report.timings_us.output_create_us,
        report.timings_us.output_write_us,
        report.timings_us.output_flush_us,
        report.timings_us.output_rename_us,
        report.timings_us.response_serialize_us,
        report.timings_us.unattributed_us,
    );
    println!(
        "{label}:critical setup_ms={} cache_open_ms={} scan_kdf_wall_ms={} plan_ms={} block_prepare_ms={} cache_commit_ms={} manifest_build_ms={} output_write_ms={} cleanup_ms={} unattributed_ms={} cache_index_format={} cache_index_open_ms={} cache_index_commit_ms={} cache_shards_read={} cache_shards_written={} cache_shard_dirty_count={} cache_commit_mode={} journal_upsert_records={} journal_upsert_paths={} journal_upsert_objects={} journal_upsert_sealed={} l1_index_hits={} l1_metadata_hits={} l1_scratch_reuses={} rayon_pool_reused={} daemon_used={} daemon_lookup_ms={} scheduler_queue_ms={} cpu_worker_wait_ms={} buffer_pool_hits={} buffer_pool_misses={} cache_pack_range_hits={} cache_pack_open_count={} hot_index_reuses={} hot_metadata_reuses={} pipeline_peak_memory_bytes={} header_bytes={} manifest_plain_bytes={} manifest_compressed_bytes={} manifest_protected_bytes={} payload_bytes={} compression_level_counts={:?} legacy_cache_hits={} parameterized_cache_hits={} cache_policy_misses={}",
        report.critical.setup_ms,
        report.critical.cache_open_ms,
        report.critical.scan_kdf_wall_ms,
        report.critical.plan_ms,
        report.critical.block_prepare_ms,
        report.critical.cache_commit_ms,
        report.critical.manifest_build_ms,
        report.critical.output_write_ms,
        report.critical.cleanup_ms,
        report.critical.unattributed_ms,
        report.l2.cache_index_format,
        report.l2.cache_index_open_ms,
        report.l2.cache_index_commit_ms,
        report.l2.cache_shards_read,
        report.l2.cache_shards_written,
        report.l2.cache_shard_dirty_count,
        report.l2.cache_commit_mode,
        report.l2.journal_upsert_records,
        report.l2.journal_upsert_paths,
        report.l2.journal_upsert_objects,
        report.l2.journal_upsert_sealed,
        report.l1.l1_index_hits,
        report.l1.l1_metadata_hits,
        report.l1.l1_scratch_reuses,
        report.l1.rayon_pool_reused,
        report.pipeline.daemon_used,
        report.pipeline.daemon_lookup_ms,
        report.pipeline.scheduler_queue_ms,
        report.pipeline.cpu_worker_wait_ms,
        report.pipeline.buffer_pool_hits,
        report.pipeline.buffer_pool_misses,
        report.pipeline.cache_pack_range_hits,
        report.pipeline.cache_pack_open_count,
        report.pipeline.hot_index_reuses,
        report.pipeline.hot_metadata_reuses,
        report.pipeline.pipeline_peak_memory_bytes,
        report.metadata.header_bytes,
        report.metadata.manifest_plain_bytes,
        report.metadata.manifest_compressed_bytes,
        report.metadata.manifest_protected_bytes,
        report.metadata.payload_bytes,
        report.blocks.compression_level_counts,
        report.blocks.legacy_cache_hits,
        report.blocks.parameterized_cache_hits,
        report.blocks.cache_policy_misses,
    );
    Ok(())
}

#[derive(Debug)]
struct BenchmarkRow {
    tool: String,
    input_bytes: u64,
    archive_bytes: Option<u64>,
    duration_ms: Option<u128>,
    cache_hit_rate: Option<f64>,
    scan_cache_hit_rate: Option<f64>,
    chunk_metadata_reuses: Option<usize>,
    trusted_bytes_skipped: Option<u64>,
    scan_ms: Option<u128>,
    plan_ms: Option<u128>,
    kdf_ms: Option<u128>,
    pack_blocks_ms: Option<u128>,
    speed: Option<String>,
    kdf_profile: Option<String>,
    encryption: Option<String>,
    worker_count: Option<usize>,
    kdf_overlapped_ms: Option<u128>,
    read_ms: Option<u128>,
    compression_ms: Option<u128>,
    crypto_ms: Option<u128>,
    payload_write_ms: Option<u128>,
    writer_strategy: Option<String>,
    archive_preallocated_bytes: Option<u64>,
    preallocation_enabled: Option<bool>,
    cached_payload_open_count: Option<usize>,
    cached_range_open_count: Option<usize>,
    cached_payload_read_bytes: Option<u64>,
    prefetched_bytes: Option<u64>,
    direct_write_count: Option<usize>,
    buffered_write_count: Option<usize>,
    peak_pipeline_memory_bytes: Option<u64>,
    payload_read_ms: Option<u128>,
    writer_wait_ms: Option<u128>,
    output_flush_ms: Option<u128>,
    output_rename_ms: Option<u128>,
    batch_blocks: Option<usize>,
    single_blocks: Option<usize>,
    batched_files: Option<usize>,
    chunked_files: Option<usize>,
    chunk_blocks: Option<usize>,
    chunk_cache_hits: Option<usize>,
    chunk_cache_misses: Option<usize>,
    chunk_plan_cache_hits: Option<usize>,
    chunk_plan_cache_misses: Option<usize>,
    sealed_block_hits: Option<usize>,
    sealed_block_misses: Option<usize>,
    sealed_bytes_reused: Option<u64>,
    reencrypted_cache_hits: Option<usize>,
    payload_source_cache_files: Option<usize>,
    payload_source_memory_bytes: Option<u64>,
    cache_pack_hits: Option<usize>,
    cache_pack_misses: Option<usize>,
    cache_pack_fallbacks: Option<usize>,
    session_used: Option<bool>,
    session_lookup_ms: Option<u128>,
    kdf_skipped_by_session: Option<bool>,
    solid_groups: Option<usize>,
    solid_files: Option<usize>,
    cache_index_format: Option<String>,
    cache_index_open_ms: Option<u128>,
    cache_index_commit_ms: Option<u128>,
    socket_connect_us: Option<u64>,
    socket_pack_roundtrip_us: Option<u64>,
    daemon_auth_us: Option<u64>,
    daemon_job_execute_us: Option<u64>,
    daemon_response_bytes: Option<u64>,
    response_serialize_us: Option<u64>,
    client_decode_us: Option<u64>,
    pipeline: Option<hig_core::PipelineReport>,
    notes: String,
}

#[derive(Debug)]
struct CompareOptions {
    input_dir: PathBuf,
    output: PathBuf,
    password: Option<String>,
    cache_dir: Option<PathBuf>,
    threads: Option<usize>,
    compression: Compression,
    level: Option<i32>,
    use_cache: bool,
    batch: BatchOptions,
    chunk: ChunkOptions,
    bench_dir: Option<PathBuf>,
    bench_suite: BenchSuite,
    manifest_format: ManifestFormat,
    use_session: bool,
    daemon: DaemonMode,
    solid: SolidMode,
    report_mode: ReportMode,
}

#[derive(Debug, Clone)]
struct CopyProbe {
    path: PathBuf,
    free_bytes: u64,
    used_percent: f64,
    copy_32_mib_median: f64,
    copy_32_mib_p95: f64,
    copy_256_mib_median: f64,
    copy_256_mib_p95: f64,
    qualified: bool,
}

#[derive(Debug, Clone)]
struct AcceptanceSamples {
    standalone_second: SampleStats,
    pack_core: SampleStats,
    cli_wall: SampleStats,
    cli_wall_full: SampleStats,
    zip: Option<SampleStats>,
    runs: usize,
}

#[derive(Debug, Clone, serde::Serialize)]
struct SampleStats {
    median_ms: f64,
    p95_ms: f64,
    p99_ms: f64,
    min_ms: f64,
    max_ms: f64,
}

impl SampleStats {
    fn from_values(values: &[f64]) -> Self {
        Self {
            median_ms: median(values),
            p95_ms: p95(values),
            p99_ms: percentile(values, 0.99),
            min_ms: values.iter().copied().fold(f64::INFINITY, f64::min),
            max_ms: values.iter().copied().fold(0.0, f64::max),
        }
    }
}

#[derive(Debug, serde::Serialize)]
struct BenchmarkSummary {
    version: &'static str,
    input_dir: String,
    corpus_name: String,
    bench_suite: String,
    file_count: u64,
    input_bytes: u64,
    excluded_paths: Vec<String>,
    incremental_modified_files: Vec<String>,
    solid_groups: u64,
    solid_files: u64,
    cache_policy_misses: u64,
    journal_bytes_after: u64,
    journal_entries_after: u64,
    environment_status: String,
    copy_256_mib_median_mib_s: f64,
    copy_256_mib_p95_mib_s: f64,
    pack_core_gate: bool,
    cli_wall_gate: bool,
    size_quality_gate: bool,
    hig_pack_core: SampleStats,
    hig_standalone_second: SampleStats,
    hig_cli_wall: SampleStats,
    hig_cli_wall_full: SampleStats,
    zip_cli_wall: Option<SampleStats>,
    rows: Vec<BenchmarkSummaryRow>,
    incremental: Option<IncrementalSummary>,
}

#[derive(Debug, serde::Serialize)]
struct BenchmarkSummaryRow {
    tool: String,
    input_bytes: u64,
    archive_bytes: Option<u64>,
    duration_ms: Option<u128>,
    socket_connect_us: Option<u64>,
    socket_pack_roundtrip_us: Option<u64>,
    daemon_auth_us: Option<u64>,
    daemon_job_execute_us: Option<u64>,
    daemon_response_bytes: Option<u64>,
    response_serialize_us: Option<u64>,
    client_decode_us: Option<u64>,
    cache_index_commit_ms: Option<u128>,
    notes: String,
}

#[derive(Debug, Clone, serde::Serialize)]
struct IncrementalSummary {
    modified_files: Vec<String>,
    hig_pack_core_ms: f64,
    hig_cli_wall_ms: f64,
    zip_cli_wall_ms: Option<f64>,
    cache_hit_rate: f64,
    cache_policy_misses: u64,
    solid_groups: u64,
    solid_files: u64,
    journal_bytes_after: u64,
    journal_entries_after: u64,
}

fn run_compare(options: CompareOptions) -> anyhow::Result<()> {
    let source_input_dir = options.input_dir.canonicalize()?;
    let probe = select_benchmark_volume(options.bench_dir.as_deref(), options.output.parent())?;
    let work_dir = benchmark_work_dir(Some(&probe.path))?;
    fs::create_dir_all(work_dir.join("hig-out"))?;
    fs::create_dir_all(work_dir.join("zip-out"))?;
    fs::create_dir_all(work_dir.join("gzip-out"))?;
    fs::create_dir_all(work_dir.join("zstd-out"))?;
    fs::create_dir_all(work_dir.join("datasets"))?;
    let input_dir =
        materialize_bench_suite_input(options.bench_suite, &source_input_dir, &work_dir)?;
    let input_bytes = dir_size(&input_dir)?;
    let cache_dir = options
        .cache_dir
        .clone()
        .unwrap_or_else(|| work_dir.join("hig-cache"));
    let compare_invoked_with_session = options.use_session;
    let mut rows = Vec::new();

    let first = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.clone(),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(cache_dir.clone()),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: false,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Balanced,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: false,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report("bench:higv2:batch:first", &first, ReportMode::Quiet)?;
    rows.push(row_from_report(
        "higv2 balanced first",
        &first,
        "default HIGV2 batch/chunk format",
    ));

    let second = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("second.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(cache_dir.clone()),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: false,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Balanced,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: false,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report("bench:higv2:batch:second", &second, ReportMode::Quiet)?;
    rows.push(row_from_report(
        "higv2 balanced second",
        &second,
        "reuses batch/single/chunk cache but recomputes file hashes",
    ));

    let session_unlock_started = Instant::now();
    if let Some(password) = options.password.as_deref() {
        unlock_session_for_cache(&cache_dir, password, KdfProfile::Secure, 1_800)?;
    }
    let session_unlock_ms = session_unlock_started.elapsed().as_millis();
    let session_pack = pack_with_daemon_policy(
        PackOptions {
            input_dir: input_dir.clone(),
            output_file: options.output.with_extension("session.hig"),
            password: None,
            encryption: EncryptionMode::Password,
            cache_dir: Some(cache_dir.clone()),
            threads: options.threads,
            compression: options.compression,
            level: options.level,
            use_cache: options.use_cache,
            trust_metadata: false,
            format: ArchiveFormat::HigV2,
            batch: options.batch,
            chunk: options.chunk,
            speed: SpeedMode::Balanced,
            kdf_profile: KdfProfile::Secure,
            sealed_cache: false,
            manifest_format: options.manifest_format,
            use_session: true,
            session_required: true,
            session_ttl_secs: None,
            solid: options.solid,
            pipeline: PipelineOptions {
                daemon_mode: DaemonMode::Required,
                ..PipelineOptions::default()
            },
        },
        ReportMode::Json,
    )?;
    print_report(
        "bench:higv2:balanced:session",
        &session_pack,
        ReportMode::Quiet,
    )?;
    rows.push(row_from_report(
        "higv2 balanced secure session",
        &session_pack,
        &format!("secure session pack; unlock cost {session_unlock_ms} ms reported separately"),
    ));
    if compare_invoked_with_session {
        println!("benchmark: --use-session was set; compare still reports unlock cost separately");
    }

    let daemon_pack = pack_with_daemon_policy(
        PackOptions {
            input_dir: input_dir.clone(),
            output_file: options.output.with_extension("daemon.hig"),
            password: None,
            encryption: EncryptionMode::Password,
            cache_dir: Some(cache_dir.clone()),
            threads: options.threads,
            compression: options.compression,
            level: options.level,
            use_cache: options.use_cache,
            trust_metadata: false,
            format: ArchiveFormat::HigV2,
            batch: options.batch,
            chunk: options.chunk,
            speed: SpeedMode::Balanced,
            kdf_profile: KdfProfile::Secure,
            sealed_cache: false,
            manifest_format: options.manifest_format,
            use_session: true,
            session_required: true,
            session_ttl_secs: None,
            solid: options.solid,
            pipeline: PipelineOptions {
                daemon_mode: options.daemon,
                ..PipelineOptions::default()
            },
        },
        ReportMode::Json,
    )?;
    print_report(
        "bench:higv2:balanced:daemon",
        &daemon_pack,
        ReportMode::Quiet,
    )?;
    rows.push(row_from_report(
        "higv2 balanced secure daemon",
        &daemon_pack,
        "secure hot daemon/session path; KDF skipped and cache index is warm",
    ));

    let trusted = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("trusted.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(cache_dir.clone()),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: true,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Fastest,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: true,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report(
        "bench:higv2:fastest:secure:warm",
        &trusted,
        ReportMode::Quiet,
    )?;
    let fastest_secure = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("fastest.secure.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(cache_dir.clone()),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: true,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Fastest,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: true,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report(
        "bench:higv2:fastest:secure",
        &fastest_secure,
        ReportMode::Quiet,
    )?;
    rows.push(row_from_report(
        "higv2 fastest secure",
        &fastest_secure,
        "fastest mode with secure KDF and sealed block reuse",
    ));

    let fastest_interactive_warm = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("fastest.interactive.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(cache_dir.clone()),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: true,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Fastest,
        kdf_profile: KdfProfile::Interactive,
        sealed_cache: true,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report(
        "bench:higv2:fastest:interactive:warm",
        &fastest_interactive_warm,
        ReportMode::Quiet,
    )?;
    let fastest_interactive = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options
            .output
            .with_extension("fastest.interactive.second.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(cache_dir.clone()),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: true,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Fastest,
        kdf_profile: KdfProfile::Interactive,
        sealed_cache: true,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report(
        "bench:higv2:fastest:interactive",
        &fastest_interactive,
        ReportMode::Quiet,
    )?;
    rows.push(row_from_report(
        "higv2 fastest interactive",
        &fastest_interactive,
        "explicit fastest mode; metadata trust and sealed encrypted cache enabled",
    ));

    let fastest_bench = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("fastest.fast-bench.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(cache_dir.clone()),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: true,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Fastest,
        kdf_profile: KdfProfile::FastBench,
        sealed_cache: true,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report(
        "bench:higv2:fastest:fast-bench",
        &fastest_bench,
        ReportMode::Quiet,
    )?;
    rows.push(row_from_report(
        "higv2 fastest second --kdf-profile fast-bench",
        &fastest_bench,
        "fastest mode with benchmark-only KDF profile",
    ));

    let no_batch = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("higv2.no-batch.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(work_dir.join("higv2-no-batch-cache")),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: false,
        format: ArchiveFormat::HigV2,
        batch: BatchOptions {
            enabled: false,
            ..options.batch
        },
        chunk: options.chunk,
        speed: SpeedMode::Balanced,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: false,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report("bench:higv2:no-batch", &no_batch, ReportMode::Quiet)?;
    rows.push(row_from_report(
        "higv2 --no-batch",
        &no_batch,
        "HIGV2 with batching disabled",
    ));

    let no_chunk_cache = work_dir.join("higv2-no-chunk-cache");
    let no_chunk = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("higv2.no-chunk.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(no_chunk_cache.clone()),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: false,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: ChunkOptions {
            enabled: false,
            ..options.chunk
        },
        speed: SpeedMode::Balanced,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: false,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report("bench:higv2:no-chunk", &no_chunk, ReportMode::Quiet)?;
    rows.push(row_from_report(
        "higv2 --no-chunk first",
        &no_chunk,
        "HIGV2 with large-file chunking disabled",
    ));

    let no_chunk_second = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("higv2.no-chunk.second.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(no_chunk_cache),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: false,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: ChunkOptions {
            enabled: false,
            ..options.chunk
        },
        speed: SpeedMode::Balanced,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: false,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report(
        "bench:higv2:no-chunk:second",
        &no_chunk_second,
        ReportMode::Quiet,
    )?;
    rows.push(row_from_report(
        "higv2 --no-chunk second",
        &no_chunk_second,
        "HIGV2 second pack with large-file chunking disabled",
    ));

    let no_encryption = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("none.hig"),
        password: None,
        encryption: EncryptionMode::None,
        cache_dir: Some(work_dir.join("higv2-none-cache")),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: false,
        format: ArchiveFormat::HigV2,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Balanced,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: false,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report("bench:higv2:none", &no_encryption, ReportMode::Quiet)?;
    rows.push(row_from_report(
        "higv2 no-encryption",
        &no_encryption,
        "no confidentiality or AEAD; BLAKE3 corruption checks remain",
    ));

    let legacy = pack(PackOptions {
        input_dir: input_dir.clone(),
        output_file: options.output.with_extension("higv1.legacy.hig"),
        password: options.password.clone(),
        encryption: EncryptionMode::Password,
        cache_dir: Some(work_dir.join("higv1-cache")),
        threads: options.threads,
        compression: options.compression,
        level: options.level,
        use_cache: options.use_cache,
        trust_metadata: false,
        format: ArchiveFormat::HigV1,
        batch: options.batch,
        chunk: options.chunk,
        speed: SpeedMode::Balanced,
        kdf_profile: KdfProfile::Secure,
        sealed_cache: false,
        manifest_format: options.manifest_format,
        use_session: false,
        session_required: false,
        session_ttl_secs: None,
        solid: options.solid,
        pipeline: PipelineOptions::default(),
    })?;
    print_report("bench:higv1:legacy", &legacy, ReportMode::Quiet)?;
    rows.push(row_from_report(
        "higv1 legacy",
        &legacy,
        "legacy one-file-per-block format",
    ));

    rows.push(run_zip_benchmark(&input_dir, &work_dir, input_bytes)?);
    rows.push(run_tar_gzip_benchmark(&input_dir, &work_dir, input_bytes)?);
    rows.push(run_tar_zstd_benchmark(&input_dir, &work_dir, input_bytes)?);
    rows.push(run_7z_benchmark(&input_dir, input_bytes));

    let acceptance = run_acceptance_samples(
        &input_dir,
        &work_dir,
        &cache_dir,
        &options,
        command_exists("zip"),
    )?;
    let incremental = if options.bench_suite == BenchSuite::Lobehub {
        Some(run_lobehub_incremental(
            &input_dir,
            &work_dir,
            &cache_dir,
            &options,
            command_exists("zip"),
        )?)
    } else {
        None
    };
    let cache_status = request_daemon(&cache_dir, DaemonRequest::CacheStatus)?.and_then(
        |response| match response {
            DaemonResponse::CacheMaintenance(report) => Some(report),
            _ => None,
        },
    );
    let summary = build_benchmark_summary(
        &input_dir,
        &rows,
        &probe,
        &acceptance,
        &options,
        incremental.clone(),
        cache_status.as_ref(),
    );
    let markdown = render_markdown(&input_dir, &rows, &probe, &acceptance, &summary);
    fs::create_dir_all("artifacts")?;
    let (benchmark_path, summary_path, profile_path) = artifact_paths(options.bench_suite);
    fs::write(&benchmark_path, markdown)?;
    fs::write(&summary_path, serde_json::to_string_pretty(&summary)?)?;
    if options.bench_suite == BenchSuite::Lobehub {
        fs::write(
            &profile_path,
            render_lobehub_profile(&input_dir, &rows, &probe, &summary),
        )?;
    }
    if options.report_mode == ReportMode::Json {
        println!("{}", serde_json::to_string_pretty(&summary)?);
    } else {
        println!("benchmark: wrote {}", benchmark_path.display());
    }
    let _ = request_daemon(&cache_dir, DaemonRequest::ClearSession);
    Ok(())
}

fn build_benchmark_summary(
    input_dir: &Path,
    rows: &[BenchmarkRow],
    probe: &CopyProbe,
    acceptance: &AcceptanceSamples,
    options: &CompareOptions,
    incremental: Option<IncrementalSummary>,
    cache_status: Option<&hig_core::CacheMaintenanceReport>,
) -> BenchmarkSummary {
    let hig_size = rows
        .iter()
        .find(|row| row.tool == "higv2 balanced secure daemon")
        .and_then(|row| row.archive_bytes);
    let zip_size = rows
        .iter()
        .find(|row| row.tool == "zip")
        .and_then(|row| row.archive_bytes);
    let size_quality_gate = match (hig_size, zip_size) {
        (Some(hig), Some(zip)) => hig <= zip,
        _ => false,
    };
    let pack_core_gate = if options.bench_suite == BenchSuite::Lobehub {
        acceptance.zip.as_ref().is_some_and(|zip| {
            acceptance.pack_core.median_ms <= 600.0
                && acceptance.pack_core.median_ms < zip.median_ms
        })
    } else {
        acceptance.pack_core.median_ms < 3.0
    };
    let cli_wall_gate = acceptance.zip.as_ref().is_some_and(|zip| {
        acceptance.cli_wall.median_ms <= 750.0 && acceptance.cli_wall.median_ms < zip.median_ms
    });
    BenchmarkSummary {
        version: "1.8.5",
        input_dir: input_dir.display().to_string(),
        corpus_name: match options.bench_suite {
            BenchSuite::Lobehub => "lobehub-source".to_string(),
            other => format!("{other:?}"),
        },
        bench_suite: format!("{:?}", options.bench_suite),
        file_count: count_files(input_dir).unwrap_or_default(),
        input_bytes: dir_size(input_dir).unwrap_or_default(),
        excluded_paths: excluded_paths_for_suite(options.bench_suite),
        incremental_modified_files: incremental
            .as_ref()
            .map(|summary| summary.modified_files.clone())
            .unwrap_or_default(),
        solid_groups: rows
            .iter()
            .find(|row| row.tool == "higv2 balanced secure daemon")
            .and_then(|row| row.solid_groups)
            .unwrap_or_default() as u64,
        solid_files: rows
            .iter()
            .find(|row| row.tool == "higv2 balanced secure daemon")
            .and_then(|row| row.solid_files)
            .unwrap_or_default() as u64,
        cache_policy_misses: 0,
        journal_bytes_after: cache_status
            .map(|report| report.journal_bytes)
            .unwrap_or_default(),
        journal_entries_after: cache_status
            .map(|report| report.journal_entries)
            .unwrap_or_default(),
        environment_status: if probe.qualified {
            "QUALIFIED".to_string()
        } else {
            "ENVIRONMENT_NOT_QUALIFIED".to_string()
        },
        copy_256_mib_median_mib_s: probe.copy_256_mib_median,
        copy_256_mib_p95_mib_s: probe.copy_256_mib_p95,
        pack_core_gate,
        cli_wall_gate,
        size_quality_gate,
        hig_pack_core: acceptance.pack_core.clone(),
        hig_standalone_second: acceptance.standalone_second.clone(),
        hig_cli_wall: acceptance.cli_wall.clone(),
        hig_cli_wall_full: acceptance.cli_wall_full.clone(),
        zip_cli_wall: acceptance.zip.clone(),
        rows: rows
            .iter()
            .map(|row| BenchmarkSummaryRow {
                tool: row.tool.clone(),
                input_bytes: row.input_bytes,
                archive_bytes: row.archive_bytes,
                duration_ms: row.duration_ms,
                socket_connect_us: row.socket_connect_us,
                socket_pack_roundtrip_us: row.socket_pack_roundtrip_us,
                daemon_auth_us: row.daemon_auth_us,
                daemon_job_execute_us: row.daemon_job_execute_us,
                daemon_response_bytes: row.daemon_response_bytes,
                response_serialize_us: row.response_serialize_us,
                client_decode_us: row.client_decode_us,
                cache_index_commit_ms: row.cache_index_commit_ms,
                notes: row.notes.clone(),
            })
            .collect(),
        incremental,
    }
}

fn artifact_paths(suite: BenchSuite) -> (PathBuf, PathBuf, PathBuf) {
    if suite == BenchSuite::Lobehub {
        (
            PathBuf::from("artifacts/hig-v1.8.5-lobehub-benchmark.md"),
            PathBuf::from("artifacts/hig-v1.8.5-lobehub-summary.json"),
            PathBuf::from("artifacts/hig-v1.8.5-lobehub-profile.md"),
        )
    } else {
        (
            PathBuf::from("artifacts/hig-v1.8.5-benchmark.md"),
            PathBuf::from("artifacts/hig-v1.8.5-summary.json"),
            PathBuf::from("artifacts/hig-v1.8.5-profile.md"),
        )
    }
}

fn run_lobehub_incremental(
    input_dir: &Path,
    work_dir: &Path,
    cache_dir: &Path,
    options: &CompareOptions,
    zip_available: bool,
) -> anyhow::Result<IncrementalSummary> {
    let incremental_dir = recreate_dataset_dir(work_dir, "lobehub-incremental")?;
    copy_dir_filtered(input_dir, &incremental_dir, &[])?;
    let modified_files = apply_lobehub_incremental_changes(&incremental_dir)?;
    let output = work_dir.join("hig-out").join("lobehub-incremental.hig");
    let report = pack_with_daemon_policy(
        PackOptions {
            input_dir: incremental_dir.clone(),
            output_file: output.clone(),
            password: None,
            encryption: EncryptionMode::Password,
            cache_dir: Some(cache_dir.to_path_buf()),
            threads: options.threads,
            compression: options.compression,
            level: options.level,
            use_cache: options.use_cache,
            trust_metadata: false,
            format: ArchiveFormat::HigV2,
            batch: options.batch,
            chunk: options.chunk,
            speed: SpeedMode::Balanced,
            kdf_profile: KdfProfile::Secure,
            sealed_cache: false,
            manifest_format: options.manifest_format,
            use_session: true,
            session_required: true,
            session_ttl_secs: None,
            solid: options.solid,
            pipeline: PipelineOptions {
                daemon_mode: DaemonMode::Required,
                ..PipelineOptions::default()
            },
        },
        ReportMode::Json,
    )?;
    let cli_started = Instant::now();
    let cli_output = work_dir.join("hig-out").join("lobehub-incremental-cli.hig");
    let mut command = ProcessCommand::new(std::env::current_exe()?);
    command
        .arg("pack")
        .arg(&incremental_dir)
        .arg("-o")
        .arg(cli_output)
        .arg("--use-session")
        .arg("--daemon")
        .arg("required")
        .arg("--cache-dir")
        .arg(cache_dir)
        .arg("--manifest-format")
        .arg(match options.manifest_format {
            ManifestFormat::Compact => "compact",
            ManifestFormat::Legacy => "legacy",
        })
        .arg("--solid")
        .arg(match options.solid {
            SolidMode::Auto => "auto",
            SolidMode::Off => "off",
        })
        .arg("--quiet")
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    if let Some(threads) = options.threads {
        command.arg("--threads").arg(threads.to_string());
    }
    let status = command.status()?;
    anyhow::ensure!(status.success(), "lobehub incremental CLI pack failed");
    let hig_cli_wall_ms = cli_started.elapsed().as_secs_f64() * 1000.0;
    let zip_cli_wall_ms = if zip_available {
        let output = work_dir.join("zip-out").join("lobehub-incremental.zip");
        let started = Instant::now();
        let status = ProcessCommand::new("zip")
            .arg("-qr")
            .arg(output)
            .arg(".")
            .arg("-x")
            .arg(".hig-cache/*")
            .current_dir(&incremental_dir)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()?;
        anyhow::ensure!(status.success(), "lobehub incremental zip failed");
        Some(started.elapsed().as_secs_f64() * 1000.0)
    } else {
        None
    };
    let cache_status = request_daemon(cache_dir, DaemonRequest::CacheStatus)?.and_then(
        |response| match response {
            DaemonResponse::CacheMaintenance(report) => Some(report),
            _ => None,
        },
    );
    Ok(IncrementalSummary {
        modified_files,
        hig_pack_core_ms: report.duration.as_secs_f64() * 1000.0,
        hig_cli_wall_ms,
        zip_cli_wall_ms,
        cache_hit_rate: report.cache.hit_rate() * 100.0,
        cache_policy_misses: report.blocks.cache_policy_misses as u64,
        solid_groups: report.blocks.solid_groups as u64,
        solid_files: report.blocks.solid_files as u64,
        journal_bytes_after: cache_status
            .as_ref()
            .map(|report| report.journal_bytes)
            .unwrap_or_default(),
        journal_entries_after: cache_status
            .as_ref()
            .map(|report| report.journal_entries)
            .unwrap_or_default(),
    })
}

fn apply_lobehub_incremental_changes(root: &Path) -> anyhow::Result<Vec<String>> {
    let mut modified = Vec::new();
    let mut source_candidates = collect_files_with_extensions(
        root,
        &["ts", "tsx", "js", "jsx", "md", "json"],
        &["src", "packages", "apps"],
    )?;
    source_candidates.sort();
    for path in source_candidates.into_iter().take(3) {
        append_text(&path, "\n// hig deterministic incremental source change\n")?;
        modified.push(relative_string(root, &path));
    }
    if let Some(path) = collect_files_with_extensions(root, &["json", "ts", "md"], &["locales"])?
        .into_iter()
        .min()
    {
        append_text(&path, "\n{\"higIncremental\":\"locale\"}\n")?;
        modified.push(relative_string(root, &path));
    }
    if let Some(path) = collect_files_with_extensions(
        root,
        &["png", "jpg", "jpeg", "webp", "svg", "txt", "json"],
        &["public"],
    )?
    .into_iter()
    .min()
    {
        append_text(&path, "\nHIG_INCREMENTAL_PUBLIC_ASSET\n")?;
        modified.push(relative_string(root, &path));
    }
    anyhow::ensure!(
        !modified.is_empty(),
        "lobehub incremental scenario found no files to modify"
    );
    Ok(modified)
}

fn append_text(path: &Path, text: &str) -> anyhow::Result<()> {
    let mut file = fs::OpenOptions::new().append(true).open(path)?;
    file.write_all(text.as_bytes())?;
    Ok(())
}

fn collect_files_with_extensions(
    root: &Path,
    extensions: &[&str],
    top_level_dirs: &[&str],
) -> anyhow::Result<Vec<PathBuf>> {
    let mut files = Vec::new();
    for dir in top_level_dirs {
        let path = root.join(dir);
        if path.exists() {
            collect_files_recursive(&path, extensions, &mut files)?;
        }
    }
    Ok(files)
}

fn collect_files_recursive(
    root: &Path,
    extensions: &[&str],
    files: &mut Vec<PathBuf>,
) -> anyhow::Result<()> {
    for entry in fs::read_dir(root)? {
        let entry = entry?;
        let path = entry.path();
        let metadata = entry.metadata()?;
        if metadata.is_dir() {
            collect_files_recursive(&path, extensions, files)?;
        } else if metadata.is_file()
            && path
                .extension()
                .and_then(|extension| extension.to_str())
                .is_some_and(|extension| extensions.iter().any(|value| value == &extension))
        {
            files.push(path);
        }
    }
    Ok(())
}

fn relative_string(root: &Path, path: &Path) -> String {
    path.strip_prefix(root)
        .unwrap_or(path)
        .to_string_lossy()
        .replace('\\', "/")
}

fn excluded_paths_for_suite(suite: BenchSuite) -> Vec<String> {
    if suite == BenchSuite::Lobehub {
        [
            ".git",
            ".hig-cache",
            "node_modules",
            ".next",
            "dist",
            "build",
        ]
        .into_iter()
        .map(str::to_string)
        .collect()
    } else {
        vec![".git".to_string(), ".hig-cache".to_string()]
    }
}

fn run_acceptance_samples(
    input_dir: &Path,
    work_dir: &Path,
    cache_dir: &Path,
    options: &CompareOptions,
    zip_available: bool,
) -> anyhow::Result<AcceptanceSamples> {
    const RUNS: usize = 20;
    let mut standalone_samples = Vec::with_capacity(RUNS);
    let mut pack_core_samples = Vec::with_capacity(RUNS);
    let mut cli_wall_samples = Vec::with_capacity(RUNS);
    let mut cli_wall_full_samples = Vec::with_capacity(RUNS);
    let mut zip_samples = Vec::with_capacity(RUNS);
    let executable = std::env::current_exe()?;
    let standalone_cache_dir = work_dir.join("acceptance-standalone-cache");
    let run_standalone = |run: usize, warmup: bool| -> anyhow::Result<f64> {
        let output = work_dir.join(if warmup {
            "acceptance-standalone-warmup.hig".to_string()
        } else {
            format!("acceptance-standalone-{run}.hig")
        });
        let report = pack(PackOptions {
            input_dir: input_dir.to_path_buf(),
            output_file: output.clone(),
            password: options.password.clone(),
            encryption: EncryptionMode::Password,
            cache_dir: Some(standalone_cache_dir.clone()),
            threads: options.threads,
            compression: options.compression,
            level: options.level,
            use_cache: options.use_cache,
            trust_metadata: false,
            format: ArchiveFormat::HigV2,
            batch: options.batch,
            chunk: options.chunk,
            speed: SpeedMode::Balanced,
            kdf_profile: KdfProfile::Secure,
            sealed_cache: false,
            manifest_format: options.manifest_format,
            use_session: false,
            session_required: false,
            session_ttl_secs: None,
            solid: options.solid,
            pipeline: PipelineOptions {
                daemon_mode: DaemonMode::Off,
                ..PipelineOptions::default()
            },
        })?;
        let duration_ms = report.duration.as_secs_f64() * 1000.0;
        let _ = fs::remove_file(&output);
        Ok(duration_ms)
    };
    let run_pack_core = |run: usize, warmup: bool| -> anyhow::Result<f64> {
        let output = work_dir.join(if warmup {
            "acceptance-core-warmup.hig".to_string()
        } else {
            format!("acceptance-core-{run}.hig")
        });
        let report = pack_with_daemon_policy(
            PackOptions {
                input_dir: input_dir.to_path_buf(),
                output_file: output.clone(),
                password: None,
                encryption: EncryptionMode::Password,
                cache_dir: Some(cache_dir.to_path_buf()),
                threads: options.threads,
                compression: options.compression,
                level: options.level,
                use_cache: options.use_cache,
                trust_metadata: false,
                format: ArchiveFormat::HigV2,
                batch: options.batch,
                chunk: options.chunk,
                speed: SpeedMode::Balanced,
                kdf_profile: KdfProfile::Secure,
                sealed_cache: false,
                manifest_format: options.manifest_format,
                use_session: true,
                session_required: true,
                session_ttl_secs: None,
                solid: options.solid,
                pipeline: PipelineOptions {
                    daemon_mode: DaemonMode::Required,
                    ..PipelineOptions::default()
                },
            },
            ReportMode::Json,
        )?;
        let duration_ms = report.duration.as_secs_f64() * 1000.0;
        let _ = fs::remove_file(&output);
        Ok(duration_ms)
    };
    let run_cli_wall = |run: usize, warmup: bool, mode: ReportMode| -> anyhow::Result<f64> {
        let output = work_dir.join(if warmup {
            format!("acceptance-cli-{mode:?}-warmup.hig")
        } else {
            format!("acceptance-cli-{mode:?}-{run}.hig")
        });
        let started = Instant::now();
        let mut command = ProcessCommand::new(&executable);
        command
            .arg("pack")
            .arg(input_dir)
            .arg("-o")
            .arg(&output)
            .arg("--use-session")
            .arg("--daemon")
            .arg("required")
            .arg("--cache-dir")
            .arg(cache_dir)
            .arg("--manifest-format")
            .arg(match options.manifest_format {
                ManifestFormat::Compact => "compact",
                ManifestFormat::Legacy => "legacy",
            })
            .arg("--solid")
            .arg(match options.solid {
                SolidMode::Auto => "auto",
                SolidMode::Off => "off",
            })
            .stdout(Stdio::null())
            .stderr(Stdio::null());
        command.arg(match mode {
            ReportMode::Json => "--json",
            ReportMode::Quiet => "--quiet",
            _ => unreachable!("acceptance CLI-wall supports quiet or JSON only"),
        });
        if let Some(threads) = options.threads {
            command.arg("--threads").arg(threads.to_string());
        }
        let status = command.status()?;
        anyhow::ensure!(status.success(), "independent daemon pack benchmark failed");
        let duration_ms = started.elapsed().as_secs_f64() * 1000.0;
        let _ = fs::remove_file(&output);
        Ok(duration_ms)
    };
    let _ = run_standalone(0, true)?;
    for run in 0..RUNS {
        standalone_samples.push(run_standalone(run, false)?);
    }
    let _ = run_pack_core(0, true)?;
    for run in 0..RUNS {
        pack_core_samples.push(run_pack_core(run, false)?);
    }
    let _ = run_cli_wall(0, true, ReportMode::Quiet)?;
    let _ = run_cli_wall(0, true, ReportMode::Json)?;
    for run in 0..RUNS {
        if run % 2 == 0 {
            cli_wall_samples.push(run_cli_wall(run, false, ReportMode::Quiet)?);
            cli_wall_full_samples.push(run_cli_wall(run, false, ReportMode::Json)?);
        } else {
            cli_wall_full_samples.push(run_cli_wall(run, false, ReportMode::Json)?);
            cli_wall_samples.push(run_cli_wall(run, false, ReportMode::Quiet)?);
        }
    }

    if zip_available {
        let warmup = work_dir.join("acceptance-zip-warmup.zip");
        let status = ProcessCommand::new("zip")
            .arg("-qr")
            .arg(&warmup)
            .arg(".")
            .arg("-x")
            .arg(".hig-cache/*")
            .current_dir(input_dir)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .status()?;
        anyhow::ensure!(status.success(), "zip warmup benchmark failed");
        let _ = fs::remove_file(&warmup);
        for run in 0..RUNS {
            let output = work_dir.join(format!("acceptance-{run}.zip"));
            let started = Instant::now();
            let status = ProcessCommand::new("zip")
                .arg("-qr")
                .arg(&output)
                .arg(".")
                .arg("-x")
                .arg(".hig-cache/*")
                .current_dir(input_dir)
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status()?;
            anyhow::ensure!(status.success(), "zip acceptance benchmark failed");
            zip_samples.push(started.elapsed().as_secs_f64() * 1000.0);
            let _ = fs::remove_file(&output);
        }
    }
    let zip = (!zip_samples.is_empty()).then(|| SampleStats::from_values(&zip_samples));
    Ok(AcceptanceSamples {
        standalone_second: SampleStats::from_values(&standalone_samples),
        pack_core: SampleStats::from_values(&pack_core_samples),
        cli_wall: SampleStats::from_values(&cli_wall_samples),
        cli_wall_full: SampleStats::from_values(&cli_wall_full_samples),
        zip,
        runs: RUNS,
    })
}

fn row_from_report(tool: &str, report: &PackReport, notes: &str) -> BenchmarkRow {
    BenchmarkRow {
        tool: tool.to_string(),
        input_bytes: report.input_bytes,
        archive_bytes: Some(report.archive_bytes),
        duration_ms: Some(report.duration.as_millis()),
        cache_hit_rate: Some(report.cache.hit_rate() * 100.0),
        scan_cache_hit_rate: Some(report.scan.scan_cache_hit_rate() * 100.0),
        chunk_metadata_reuses: Some(report.scan.chunk_metadata_reuses),
        trusted_bytes_skipped: Some(report.scan.trusted_bytes_skipped),
        scan_ms: Some(report.timings.scan_ms),
        plan_ms: Some(report.timings.plan_ms),
        kdf_ms: Some(report.timings.kdf_ms),
        pack_blocks_ms: Some(report.timings.pack_blocks_ms),
        speed: Some(format!("{:?}", report.speed)),
        kdf_profile: Some(format!("{:?}", report.kdf_profile)),
        encryption: Some(format!("{:?}", report.encryption_mode)),
        worker_count: Some(report.worker_count),
        kdf_overlapped_ms: Some(report.timings.kdf_overlapped_ms),
        read_ms: Some(report.timings.read_ms),
        compression_ms: Some(report.timings.compression_ms),
        crypto_ms: Some(report.timings.crypto_ms),
        payload_write_ms: Some(report.timings.payload_write_ms),
        writer_strategy: Some(format!("{:?}", report.writer_strategy)),
        archive_preallocated_bytes: Some(report.archive_preallocated_bytes),
        preallocation_enabled: Some(report.preallocation_enabled),
        cached_payload_open_count: Some(report.cached_payload_open_count),
        cached_range_open_count: Some(report.cached_range_open_count),
        cached_payload_read_bytes: Some(report.cached_payload_read_bytes),
        prefetched_bytes: Some(report.prefetched_bytes),
        direct_write_count: Some(report.direct_write_count),
        buffered_write_count: Some(report.buffered_write_count),
        peak_pipeline_memory_bytes: Some(report.peak_pipeline_memory_bytes),
        payload_read_ms: Some(report.timings.payload_read_ms),
        writer_wait_ms: Some(report.timings.writer_wait_ms),
        output_flush_ms: Some(report.timings.output_flush_ms),
        output_rename_ms: Some(report.timings.output_rename_ms),
        batch_blocks: Some(report.blocks.batch_blocks),
        single_blocks: Some(report.blocks.single_blocks),
        batched_files: Some(report.blocks.batched_files),
        chunked_files: Some(report.blocks.chunked_files),
        chunk_blocks: Some(report.blocks.chunk_blocks),
        chunk_cache_hits: Some(report.blocks.chunk_cache_hits),
        chunk_cache_misses: Some(report.blocks.chunk_cache_misses),
        chunk_plan_cache_hits: Some(report.blocks.chunk_plan_cache_hits),
        chunk_plan_cache_misses: Some(report.blocks.chunk_plan_cache_misses),
        sealed_block_hits: Some(report.blocks.sealed_block_hits),
        sealed_block_misses: Some(report.blocks.sealed_block_misses),
        sealed_bytes_reused: Some(report.blocks.sealed_bytes_reused),
        reencrypted_cache_hits: Some(report.blocks.reencrypted_cache_hits),
        payload_source_cache_files: Some(report.blocks.payload_source_cache_files),
        payload_source_memory_bytes: Some(report.blocks.payload_source_memory_bytes),
        cache_pack_hits: Some(report.blocks.cache_pack_hits),
        cache_pack_misses: Some(report.blocks.cache_pack_misses),
        cache_pack_fallbacks: Some(report.blocks.cache_pack_fallbacks),
        session_used: Some(report.session.session_used),
        session_lookup_ms: Some(report.session.session_lookup_ms),
        kdf_skipped_by_session: Some(report.session.kdf_skipped_by_session),
        solid_groups: Some(report.blocks.solid_groups),
        solid_files: Some(report.blocks.solid_files),
        cache_index_format: Some(report.l2.cache_index_format.clone()),
        cache_index_open_ms: Some(report.l2.cache_index_open_ms),
        cache_index_commit_ms: Some(report.l2.cache_index_commit_ms),
        socket_connect_us: Some(report.timings_us.socket_connect_us),
        socket_pack_roundtrip_us: Some(report.timings_us.socket_pack_roundtrip_us),
        daemon_auth_us: Some(report.timings_us.daemon_auth_us),
        daemon_job_execute_us: Some(report.timings_us.daemon_job_execute_us),
        daemon_response_bytes: Some(report.timings_us.daemon_response_bytes),
        response_serialize_us: Some(report.timings_us.response_serialize_us),
        client_decode_us: Some(report.timings_us.client_decode_us),
        pipeline: Some(report.pipeline.clone()),
        notes: notes.to_string(),
    }
}

fn run_zip_benchmark(
    input_dir: &Path,
    work_dir: &Path,
    input_bytes: u64,
) -> anyhow::Result<BenchmarkRow> {
    if !command_exists("zip") {
        return Ok(skipped_row("zip", input_bytes, "skipped (not installed)"));
    }
    let output = work_dir.join("compare.zip");
    let started = Instant::now();
    let status = ProcessCommand::new("zip")
        .arg("-qr")
        .arg(&output)
        .arg(".")
        .arg("-x")
        .arg(".hig-cache/*")
        .current_dir(input_dir)
        .status()?;
    if !status.success() {
        anyhow::bail!("zip benchmark failed");
    }
    Ok(BenchmarkRow {
        tool: "zip".to_string(),
        input_bytes,
        archive_bytes: Some(fs::metadata(output)?.len()),
        duration_ms: Some(started.elapsed().as_millis()),
        cache_hit_rate: None,
        scan_cache_hit_rate: None,
        chunk_metadata_reuses: None,
        trusted_bytes_skipped: None,
        scan_ms: None,
        plan_ms: None,
        kdf_ms: None,
        pack_blocks_ms: None,
        speed: None,
        kdf_profile: None,
        encryption: None,
        worker_count: None,
        kdf_overlapped_ms: None,
        read_ms: None,
        compression_ms: None,
        crypto_ms: None,
        payload_write_ms: None,
        writer_strategy: None,
        archive_preallocated_bytes: None,
        preallocation_enabled: None,
        cached_payload_open_count: None,
        cached_range_open_count: None,
        cached_payload_read_bytes: None,
        prefetched_bytes: None,
        direct_write_count: None,
        buffered_write_count: None,
        peak_pipeline_memory_bytes: None,
        payload_read_ms: None,
        writer_wait_ms: None,
        output_flush_ms: None,
        output_rename_ms: None,
        batch_blocks: None,
        single_blocks: None,
        batched_files: None,
        chunked_files: None,
        chunk_blocks: None,
        chunk_cache_hits: None,
        chunk_cache_misses: None,
        chunk_plan_cache_hits: None,
        chunk_plan_cache_misses: None,
        sealed_block_hits: None,
        sealed_block_misses: None,
        sealed_bytes_reused: None,
        reencrypted_cache_hits: None,
        payload_source_cache_files: None,
        payload_source_memory_bytes: None,
        cache_pack_hits: None,
        cache_pack_misses: None,
        cache_pack_fallbacks: None,
        session_used: None,
        session_lookup_ms: None,
        kdf_skipped_by_session: None,
        solid_groups: None,
        solid_files: None,
        cache_index_format: None,
        cache_index_open_ms: None,
        cache_index_commit_ms: None,
        socket_connect_us: None,
        socket_pack_roundtrip_us: None,
        daemon_auth_us: None,
        daemon_job_execute_us: None,
        daemon_response_bytes: None,
        response_serialize_us: None,
        client_decode_us: None,
        pipeline: None,
        notes: "zip -qr".to_string(),
    })
}

fn run_tar_zstd_benchmark(
    input_dir: &Path,
    work_dir: &Path,
    input_bytes: u64,
) -> anyhow::Result<BenchmarkRow> {
    if !command_exists("tar") || !command_exists("zstd") {
        return Ok(skipped_row(
            "tar.zst",
            input_bytes,
            "skipped (tar or zstd not installed)",
        ));
    }
    let tar_output = work_dir.join("compare.tar");
    let zstd_output = work_dir.join("compare.tar.zst");
    let started = Instant::now();
    let tar_status = ProcessCommand::new("tar")
        .arg("--exclude=.hig-cache")
        .arg("-cf")
        .arg(&tar_output)
        .arg("-C")
        .arg(input_dir)
        .arg(".")
        .status()?;
    if !tar_status.success() {
        anyhow::bail!("tar benchmark failed");
    }
    let zstd_status = ProcessCommand::new("zstd")
        .arg("-q")
        .arg("-1")
        .arg("-f")
        .arg(&tar_output)
        .arg("-o")
        .arg(&zstd_output)
        .status()?;
    if !zstd_status.success() {
        anyhow::bail!("zstd benchmark failed");
    }
    let _ = fs::remove_file(tar_output);
    Ok(BenchmarkRow {
        tool: "tar.zst".to_string(),
        input_bytes,
        archive_bytes: Some(fs::metadata(zstd_output)?.len()),
        duration_ms: Some(started.elapsed().as_millis()),
        cache_hit_rate: None,
        scan_cache_hit_rate: None,
        chunk_metadata_reuses: None,
        trusted_bytes_skipped: None,
        scan_ms: None,
        plan_ms: None,
        kdf_ms: None,
        pack_blocks_ms: None,
        speed: None,
        kdf_profile: None,
        encryption: None,
        worker_count: None,
        kdf_overlapped_ms: None,
        read_ms: None,
        compression_ms: None,
        crypto_ms: None,
        payload_write_ms: None,
        writer_strategy: None,
        archive_preallocated_bytes: None,
        preallocation_enabled: None,
        cached_payload_open_count: None,
        cached_range_open_count: None,
        cached_payload_read_bytes: None,
        prefetched_bytes: None,
        direct_write_count: None,
        buffered_write_count: None,
        peak_pipeline_memory_bytes: None,
        payload_read_ms: None,
        writer_wait_ms: None,
        output_flush_ms: None,
        output_rename_ms: None,
        batch_blocks: None,
        single_blocks: None,
        batched_files: None,
        chunked_files: None,
        chunk_blocks: None,
        chunk_cache_hits: None,
        chunk_cache_misses: None,
        chunk_plan_cache_hits: None,
        chunk_plan_cache_misses: None,
        sealed_block_hits: None,
        sealed_block_misses: None,
        sealed_bytes_reused: None,
        reencrypted_cache_hits: None,
        payload_source_cache_files: None,
        payload_source_memory_bytes: None,
        cache_pack_hits: None,
        cache_pack_misses: None,
        cache_pack_fallbacks: None,
        session_used: None,
        session_lookup_ms: None,
        kdf_skipped_by_session: None,
        solid_groups: None,
        solid_files: None,
        cache_index_format: None,
        cache_index_open_ms: None,
        cache_index_commit_ms: None,
        socket_connect_us: None,
        socket_pack_roundtrip_us: None,
        daemon_auth_us: None,
        daemon_job_execute_us: None,
        daemon_response_bytes: None,
        response_serialize_us: None,
        client_decode_us: None,
        pipeline: None,
        notes: "tar -cf + zstd -1".to_string(),
    })
}

fn run_tar_gzip_benchmark(
    input_dir: &Path,
    work_dir: &Path,
    input_bytes: u64,
) -> anyhow::Result<BenchmarkRow> {
    if !command_exists("tar") || !command_exists("gzip") {
        return Ok(skipped_row(
            "tar.gz",
            input_bytes,
            "skipped (tar or gzip not installed)",
        ));
    }
    let tar_output = work_dir.join("compare-gzip.tar");
    let gzip_output = work_dir.join("compare.tar.gz");
    let started = Instant::now();
    let tar_status = ProcessCommand::new("tar")
        .arg("--exclude=.hig-cache")
        .arg("-cf")
        .arg(&tar_output)
        .arg("-C")
        .arg(input_dir)
        .arg(".")
        .status()?;
    if !tar_status.success() {
        anyhow::bail!("tar benchmark failed");
    }
    let gzip_status = ProcessCommand::new("gzip")
        .arg("-6")
        .arg("-c")
        .arg(&tar_output)
        .stdout(fs::File::create(&gzip_output)?)
        .status()?;
    if !gzip_status.success() {
        anyhow::bail!("gzip benchmark failed");
    }
    let _ = fs::remove_file(tar_output);
    Ok(BenchmarkRow {
        tool: "tar.gz".to_string(),
        input_bytes,
        archive_bytes: Some(fs::metadata(gzip_output)?.len()),
        duration_ms: Some(started.elapsed().as_millis()),
        cache_hit_rate: None,
        scan_cache_hit_rate: None,
        chunk_metadata_reuses: None,
        trusted_bytes_skipped: None,
        scan_ms: None,
        plan_ms: None,
        kdf_ms: None,
        pack_blocks_ms: None,
        speed: None,
        kdf_profile: None,
        encryption: None,
        worker_count: None,
        kdf_overlapped_ms: None,
        read_ms: None,
        compression_ms: None,
        crypto_ms: None,
        payload_write_ms: None,
        writer_strategy: None,
        archive_preallocated_bytes: None,
        preallocation_enabled: None,
        cached_payload_open_count: None,
        cached_range_open_count: None,
        cached_payload_read_bytes: None,
        prefetched_bytes: None,
        direct_write_count: None,
        buffered_write_count: None,
        peak_pipeline_memory_bytes: None,
        payload_read_ms: None,
        writer_wait_ms: None,
        output_flush_ms: None,
        output_rename_ms: None,
        batch_blocks: None,
        single_blocks: None,
        batched_files: None,
        chunked_files: None,
        chunk_blocks: None,
        chunk_cache_hits: None,
        chunk_cache_misses: None,
        chunk_plan_cache_hits: None,
        chunk_plan_cache_misses: None,
        sealed_block_hits: None,
        sealed_block_misses: None,
        sealed_bytes_reused: None,
        reencrypted_cache_hits: None,
        payload_source_cache_files: None,
        payload_source_memory_bytes: None,
        cache_pack_hits: None,
        cache_pack_misses: None,
        cache_pack_fallbacks: None,
        session_used: None,
        session_lookup_ms: None,
        kdf_skipped_by_session: None,
        solid_groups: None,
        solid_files: None,
        cache_index_format: None,
        cache_index_open_ms: None,
        cache_index_commit_ms: None,
        socket_connect_us: None,
        socket_pack_roundtrip_us: None,
        daemon_auth_us: None,
        daemon_job_execute_us: None,
        daemon_response_bytes: None,
        response_serialize_us: None,
        client_decode_us: None,
        pipeline: None,
        notes: "tar -cf + gzip -6".to_string(),
    })
}

fn run_7z_benchmark(_input_dir: &Path, input_bytes: u64) -> BenchmarkRow {
    if !command_exists("7z") {
        return skipped_row("7z", input_bytes, "skipped (not installed)");
    }
    skipped_row(
        "7z",
        input_bytes,
        "skipped (7z runner not implemented in v1.0.1)",
    )
}

fn materialize_bench_suite_input(
    suite: BenchSuite,
    source_input_dir: &Path,
    work_dir: &Path,
) -> anyhow::Result<PathBuf> {
    match suite {
        BenchSuite::Source | BenchSuite::All => Ok(source_input_dir.to_path_buf()),
        BenchSuite::Lobehub => {
            anyhow::ensure!(
                source_input_dir.exists(),
                "lobehub source directory does not exist: {}",
                source_input_dir.display()
            );
            let dir = PathBuf::from("/private/tmp/hig-lobehub-source-data");
            if dir.exists() {
                fs::remove_dir_all(&dir)?;
            }
            fs::create_dir_all(&dir)?;
            copy_dir_filtered(
                source_input_dir,
                &dir,
                &excluded_paths_for_suite(BenchSuite::Lobehub),
            )?;
            Ok(dir)
        }
        BenchSuite::Small500 => {
            let dir = recreate_dataset_dir(work_dir, "small500")?;
            for index in 0..500 {
                fs::write(
                    dir.join(format!("file-{index:04}.txt")),
                    format!("record {index:04} common common common payload payload payload\n"),
                )?;
            }
            Ok(dir)
        }
        BenchSuite::Textmix => {
            let dir = recreate_dataset_dir(work_dir, "textmix")?;
            fs::create_dir_all(dir.join("src"))?;
            for index in 0..64 {
                fs::write(
                    dir.join("src").join(format!("module_{index:02}.rs")),
                    format!(
                        "pub fn value_{index}() -> usize {{ {index} }}\n#[test]\nfn test_{index}() {{ assert_eq!(value_{index}(), {index}); }}\n"
                    ),
                )?;
                fs::write(
                    dir.join(format!("config-{index:02}.toml")),
                    format!("name = \"module-{index}\"\nenabled = true\nlevel = {index}\n"),
                )?;
                fs::write(
                    dir.join(format!("doc-{index:02}.md")),
                    format!(
                        "# Module {index}\n\nRepeated markdown content for compression quality.\n"
                    ),
                )?;
            }
            Ok(dir)
        }
        BenchSuite::Repeat4m => {
            let dir = recreate_dataset_dir(work_dir, "repeat4m")?;
            let line = b"highly repeatable text payload for gzip and hig comparison\n";
            let mut data = Vec::with_capacity(4 * 1024 * 1024);
            while data.len() < 4 * 1024 * 1024 {
                data.extend_from_slice(line);
            }
            data.truncate(4 * 1024 * 1024);
            fs::write(dir.join("repeat.txt"), data)?;
            Ok(dir)
        }
        BenchSuite::Random8m => {
            let dir = recreate_dataset_dir(work_dir, "random8m")?;
            let mut data = vec![0_u8; 8 * 1024 * 1024];
            let mut state = 0x1234_5678_9abc_def0_u64;
            for byte in &mut data {
                state ^= state << 13;
                state ^= state >> 7;
                state ^= state << 17;
                *byte = state as u8;
            }
            fs::write(dir.join("random.bin"), data)?;
            Ok(dir)
        }
        BenchSuite::Binarymix => {
            let dir = recreate_dataset_dir(work_dir, "binarymix")?;
            fs::create_dir_all(dir.join("assets"))?;
            for index in 0..16 {
                let mut data = vec![0_u8; 64 * 1024];
                for (offset, byte) in data.iter_mut().enumerate() {
                    *byte = ((offset * 31 + index * 17) & 0xff) as u8;
                }
                fs::write(
                    dir.join("assets").join(format!("asset-{index:02}.bin")),
                    data,
                )?;
                fs::write(
                    dir.join(format!("manifest-{index:02}.json")),
                    format!(
                        "{{\"asset\":{index},\"kind\":\"binarymix\",\"repeat\":\"metadata\"}}\n"
                    ),
                )?;
            }
            Ok(dir)
        }
    }
}

fn copy_dir_filtered(source: &Path, target: &Path, excluded: &[String]) -> anyhow::Result<()> {
    fs::create_dir_all(target)?;
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        let file_name = entry.file_name();
        let file_name_str = file_name.to_string_lossy();
        if excluded
            .iter()
            .any(|exclude| exclude == file_name_str.as_ref())
        {
            continue;
        }
        let source_path = entry.path();
        let target_path = target.join(file_name);
        let metadata = entry.metadata()?;
        if metadata.is_dir() {
            copy_dir_filtered(&source_path, &target_path, excluded)?;
        } else if metadata.is_file() {
            fs::copy(&source_path, &target_path)?;
        }
    }
    Ok(())
}

fn recreate_dataset_dir(work_dir: &Path, name: &str) -> anyhow::Result<PathBuf> {
    let dir = work_dir.join("datasets").join(name);
    if dir.exists() {
        fs::remove_dir_all(&dir)?;
    }
    fs::create_dir_all(&dir)?;
    Ok(dir)
}

fn skipped_row(tool: &str, input_bytes: u64, notes: &str) -> BenchmarkRow {
    BenchmarkRow {
        tool: tool.to_string(),
        input_bytes,
        archive_bytes: None,
        duration_ms: None,
        cache_hit_rate: None,
        scan_cache_hit_rate: None,
        chunk_metadata_reuses: None,
        trusted_bytes_skipped: None,
        scan_ms: None,
        plan_ms: None,
        kdf_ms: None,
        pack_blocks_ms: None,
        speed: None,
        kdf_profile: None,
        encryption: None,
        worker_count: None,
        kdf_overlapped_ms: None,
        read_ms: None,
        compression_ms: None,
        crypto_ms: None,
        payload_write_ms: None,
        writer_strategy: None,
        archive_preallocated_bytes: None,
        preallocation_enabled: None,
        cached_payload_open_count: None,
        cached_range_open_count: None,
        cached_payload_read_bytes: None,
        prefetched_bytes: None,
        direct_write_count: None,
        buffered_write_count: None,
        peak_pipeline_memory_bytes: None,
        payload_read_ms: None,
        writer_wait_ms: None,
        output_flush_ms: None,
        output_rename_ms: None,
        batch_blocks: None,
        single_blocks: None,
        batched_files: None,
        chunked_files: None,
        chunk_blocks: None,
        chunk_cache_hits: None,
        chunk_cache_misses: None,
        chunk_plan_cache_hits: None,
        chunk_plan_cache_misses: None,
        sealed_block_hits: None,
        sealed_block_misses: None,
        sealed_bytes_reused: None,
        reencrypted_cache_hits: None,
        payload_source_cache_files: None,
        payload_source_memory_bytes: None,
        cache_pack_hits: None,
        cache_pack_misses: None,
        cache_pack_fallbacks: None,
        session_used: None,
        session_lookup_ms: None,
        kdf_skipped_by_session: None,
        solid_groups: None,
        solid_files: None,
        cache_index_format: None,
        cache_index_open_ms: None,
        cache_index_commit_ms: None,
        socket_connect_us: None,
        socket_pack_roundtrip_us: None,
        daemon_auth_us: None,
        daemon_job_execute_us: None,
        daemon_response_bytes: None,
        response_serialize_us: None,
        client_decode_us: None,
        pipeline: None,
        notes: notes.to_string(),
    }
}

fn render_markdown(
    input_dir: &Path,
    rows: &[BenchmarkRow],
    probe: &CopyProbe,
    acceptance: &AcceptanceSamples,
    summary: &BenchmarkSummary,
) -> String {
    let mut output = String::new();
    output.push_str("# Hig v1.8.5 Benchmark\n\n");
    output.push_str(&format!("Input: `{}`\n\n", input_dir.display()));
    output.push_str("## Gate Summary\n\n");
    output.push_str("| gate | status |\n|---|---|\n");
    output.push_str(&format!(
        "| environment_status | `{}` |\n",
        summary.environment_status
    ));
    output.push_str(&format!(
        "| pack_core_gate | {} |\n",
        summary.pack_core_gate
    ));
    output.push_str(&format!("| cli_wall_gate | {} |\n", summary.cli_wall_gate));
    output.push_str(&format!(
        "| size_quality_gate | {} |\n\n",
        summary.size_quality_gate
    ));
    output.push_str("## Environment Qualification\n\n");
    output.push_str(&format!(
        "Status: `{}`\n\n",
        if probe.qualified {
            "QUALIFIED"
        } else {
            "ENVIRONMENT_NOT_QUALIFIED"
        }
    ));
    output.push_str("## Release Gate Samples\n\n");
    output.push_str(&format!(
        "Standalone second, warm daemon pack-core, Summary/quiet CLI-wall, Full/JSON CLI-wall, and zip were each sampled {} times.\n\n",
        acceptance.runs
    ));
    output.push_str("| tool | median ms | p95 ms | p99 ms | min ms | max ms |\n|---|---:|---:|---:|---:|---:|\n");
    output.push_str(&format!(
        "| Hig Balanced secure standalone second | {:.3} | {:.3} | {:.3} | {:.3} | {:.3} |\n",
        acceptance.standalone_second.median_ms,
        acceptance.standalone_second.p95_ms,
        acceptance.standalone_second.p99_ms,
        acceptance.standalone_second.min_ms,
        acceptance.standalone_second.max_ms
    ));
    output.push_str(&format!(
        "| Hig Balanced secure daemon pack-core | {:.3} | {:.3} | {:.3} | {:.3} | {:.3} |\n",
        acceptance.pack_core.median_ms,
        acceptance.pack_core.p95_ms,
        acceptance.pack_core.p99_ms,
        acceptance.pack_core.min_ms,
        acceptance.pack_core.max_ms
    ));
    output.push_str(&format!(
        "| Hig Balanced secure daemon Summary + quiet cli-wall | {:.3} | {:.3} | {:.3} | {:.3} | {:.3} |\n",
        acceptance.cli_wall.median_ms,
        acceptance.cli_wall.p95_ms,
        acceptance.cli_wall.p99_ms,
        acceptance.cli_wall.min_ms,
        acceptance.cli_wall.max_ms
    ));
    output.push_str(&format!(
        "| Hig Balanced secure daemon Full + JSON cli-wall | {:.3} | {:.3} | {:.3} | {:.3} | {:.3} |\n",
        acceptance.cli_wall_full.median_ms,
        acceptance.cli_wall_full.p95_ms,
        acceptance.cli_wall_full.p99_ms,
        acceptance.cli_wall_full.min_ms,
        acceptance.cli_wall_full.max_ms
    ));
    output.push_str(&format!(
        "| zip -qr | {} | {} | {} | {} | {} |\n\n",
        acceptance
            .zip
            .as_ref()
            .map(|value| format!("{:.3}", value.median_ms))
            .unwrap_or_else(|| "-".to_string()),
        acceptance
            .zip
            .as_ref()
            .map(|value| format!("{:.3}", value.p95_ms))
            .unwrap_or_else(|| "-".to_string()),
        acceptance
            .zip
            .as_ref()
            .map(|value| format!("{:.3}", value.p99_ms))
            .unwrap_or_else(|| "-".to_string()),
        acceptance
            .zip
            .as_ref()
            .map(|value| format!("{:.3}", value.min_ms))
            .unwrap_or_else(|| "-".to_string()),
        acceptance
            .zip
            .as_ref()
            .map(|value| format!("{:.3}", value.max_ms))
            .unwrap_or_else(|| "-".to_string())
    ));
    output.push_str("| path | free bytes | used % | 32MiB cp median MiB/s | 32MiB cp p95 MiB/s | 256MiB cp median MiB/s | 256MiB cp p95 MiB/s |\n");
    output.push_str("|---|---:|---:|---:|---:|---:|---:|\n");
    output.push_str(&format!(
        "| `{}` | {} | {:.2} | {:.2} | {:.2} | {:.2} | {:.2} |\n\n",
        probe.path.display(),
        probe.free_bytes,
        probe.used_percent,
        probe.copy_32_mib_median,
        probe.copy_32_mib_p95,
        probe.copy_256_mib_median,
        probe.copy_256_mib_p95
    ));
    let headers = [
        "tool",
        "encryption",
        "speed",
        "kdf profile",
        "session used",
        "session lookup ms",
        "kdf skipped by session",
        "workers",
        "cache index",
        "cache index open ms",
        "cache index commit ms",
        "socket connect us",
        "socket pack roundtrip us",
        "daemon auth us",
        "daemon job execute us",
        "daemon response bytes",
        "response serialize us",
        "client decode us",
        "daemon used",
        "daemon lookup ms",
        "scheduler queue ms",
        "worker wait ms",
        "buffer pool hits",
        "buffer pool misses",
        "cache pack range hits",
        "cache pack opens",
        "hot index reuses",
        "hot metadata reuses",
        "pipeline peak memory",
        "writer",
        "preallocated bytes",
        "preallocation",
        "cached opens",
        "cached range opens",
        "cached read bytes",
        "prefetched bytes",
        "direct writes",
        "buffered writes",
        "peak pipeline bytes",
        "input bytes",
        "archive bytes",
        "reduction",
        "duration ms",
        "throughput MiB/s",
        "scan ms",
        "plan ms",
        "kdf ms",
        "kdf overlap ms",
        "read ms",
        "compression ms",
        "crypto ms",
        "pack blocks ms",
        "payload read ms",
        "payload write ms",
        "writer wait ms",
        "flush ms",
        "rename ms",
        "sealed hits",
        "sealed misses",
        "sealed bytes reused",
        "reencrypted cache hits",
        "payload cache files",
        "payload memory bytes",
        "cache pack hits",
        "cache pack misses",
        "cache pack fallbacks",
        "cache hit rate",
        "scan cache hit rate",
        "chunk metadata reuses",
        "trusted bytes skipped",
        "batch blocks",
        "solid groups",
        "solid files",
        "single blocks",
        "batched files",
        "chunked files",
        "chunk blocks",
        "chunk hits",
        "chunk misses",
        "chunk plan hits",
        "chunk plan misses",
        "notes",
    ];
    output.push_str("| ");
    output.push_str(&headers.join(" | "));
    output.push_str(" |\n|");
    output.push_str(&vec!["---"; headers.len()].join("|"));
    output.push_str("|\n");
    for row in rows {
        let archive_bytes = row
            .archive_bytes
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let reduction = row
            .archive_bytes
            .map(|archive| reduction_pct(row.input_bytes, archive))
            .map(|value| format!("{value:.2}%"))
            .unwrap_or_else(|| "-".to_string());
        let duration = row
            .duration_ms
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let throughput = row
            .duration_ms
            .filter(|duration| *duration > 0)
            .map(|duration| {
                let seconds = duration as f64 / 1000.0;
                let mib = row.input_bytes as f64 / 1024.0 / 1024.0;
                format!("{:.2}", mib / seconds)
            })
            .unwrap_or_else(|| "-".to_string());
        let cache_hit_rate = row
            .cache_hit_rate
            .map(|value| format!("{value:.2}%"))
            .unwrap_or_else(|| "-".to_string());
        let scan_cache_hit_rate = row
            .scan_cache_hit_rate
            .map(|value| format!("{value:.2}%"))
            .unwrap_or_else(|| "-".to_string());
        let scan_ms = optional_to_string(row.scan_ms);
        let plan_ms = optional_to_string(row.plan_ms);
        let kdf_ms = optional_to_string(row.kdf_ms);
        let pack_blocks_ms = optional_to_string(row.pack_blocks_ms);
        let speed = optional_to_string(row.speed.as_ref());
        let kdf_profile = optional_to_string(row.kdf_profile.as_ref());
        let encryption = optional_to_string(row.encryption.as_ref());
        let session_used = optional_to_string(row.session_used);
        let session_lookup_ms = optional_to_string(row.session_lookup_ms);
        let kdf_skipped_by_session = optional_to_string(row.kdf_skipped_by_session);
        let workers = optional_to_string(row.worker_count);
        let cache_index = optional_to_string(row.cache_index_format.as_ref());
        let cache_index_open_ms = optional_to_string(row.cache_index_open_ms);
        let cache_index_commit_ms = optional_to_string(row.cache_index_commit_ms);
        let socket_connect_us = optional_to_string(row.socket_connect_us);
        let socket_pack_roundtrip_us = optional_to_string(row.socket_pack_roundtrip_us);
        let daemon_auth_us = optional_to_string(row.daemon_auth_us);
        let daemon_job_execute_us = optional_to_string(row.daemon_job_execute_us);
        let daemon_response_bytes = optional_to_string(row.daemon_response_bytes);
        let response_serialize_us = optional_to_string(row.response_serialize_us);
        let client_decode_us = optional_to_string(row.client_decode_us);
        let daemon_used = optional_to_string(row.pipeline.as_ref().map(|value| value.daemon_used));
        let daemon_lookup_ms =
            optional_to_string(row.pipeline.as_ref().map(|value| value.daemon_lookup_ms));
        let scheduler_queue_ms =
            optional_to_string(row.pipeline.as_ref().map(|value| value.scheduler_queue_ms));
        let cpu_worker_wait_ms =
            optional_to_string(row.pipeline.as_ref().map(|value| value.cpu_worker_wait_ms));
        let buffer_pool_hits =
            optional_to_string(row.pipeline.as_ref().map(|value| value.buffer_pool_hits));
        let buffer_pool_misses =
            optional_to_string(row.pipeline.as_ref().map(|value| value.buffer_pool_misses));
        let cache_pack_range_hits = optional_to_string(
            row.pipeline
                .as_ref()
                .map(|value| value.cache_pack_range_hits),
        );
        let cache_pack_open_count = optional_to_string(
            row.pipeline
                .as_ref()
                .map(|value| value.cache_pack_open_count),
        );
        let hot_index_reuses =
            optional_to_string(row.pipeline.as_ref().map(|value| value.hot_index_reuses));
        let hot_metadata_reuses =
            optional_to_string(row.pipeline.as_ref().map(|value| value.hot_metadata_reuses));
        let pipeline_peak_memory = optional_to_string(
            row.pipeline
                .as_ref()
                .map(|value| value.pipeline_peak_memory_bytes),
        );
        let kdf_overlap = optional_to_string(row.kdf_overlapped_ms);
        let read_ms = optional_to_string(row.read_ms);
        let compression_ms = optional_to_string(row.compression_ms);
        let crypto_ms = optional_to_string(row.crypto_ms);
        let payload_write_ms = optional_to_string(row.payload_write_ms);
        let writer_strategy = optional_to_string(row.writer_strategy.as_ref());
        let preallocated = optional_to_string(row.archive_preallocated_bytes);
        let preallocation = optional_to_string(row.preallocation_enabled);
        let cached_opens = optional_to_string(row.cached_payload_open_count);
        let cached_range_opens = optional_to_string(row.cached_range_open_count);
        let cached_read_bytes = optional_to_string(row.cached_payload_read_bytes);
        let prefetched_bytes = optional_to_string(row.prefetched_bytes);
        let direct_writes = optional_to_string(row.direct_write_count);
        let buffered_writes = optional_to_string(row.buffered_write_count);
        let peak_pipeline_bytes = optional_to_string(row.peak_pipeline_memory_bytes);
        let payload_read_ms = optional_to_string(row.payload_read_ms);
        let writer_wait_ms = optional_to_string(row.writer_wait_ms);
        let flush_ms = optional_to_string(row.output_flush_ms);
        let rename_ms = optional_to_string(row.output_rename_ms);
        let sealed_hits = optional_to_string(row.sealed_block_hits);
        let sealed_misses = optional_to_string(row.sealed_block_misses);
        let sealed_bytes = optional_to_string(row.sealed_bytes_reused);
        let reencrypted = optional_to_string(row.reencrypted_cache_hits);
        let payload_files = optional_to_string(row.payload_source_cache_files);
        let payload_memory = optional_to_string(row.payload_source_memory_bytes);
        let cache_pack_hits = optional_to_string(row.cache_pack_hits);
        let cache_pack_misses = optional_to_string(row.cache_pack_misses);
        let cache_pack_fallbacks = optional_to_string(row.cache_pack_fallbacks);
        let chunk_metadata_reuses = optional_to_string(row.chunk_metadata_reuses);
        let trusted_bytes_skipped = optional_to_string(row.trusted_bytes_skipped);
        let batch_blocks = row
            .batch_blocks
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let solid_groups = optional_to_string(row.solid_groups);
        let solid_files = optional_to_string(row.solid_files);
        let single_blocks = row
            .single_blocks
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let batched_files = row
            .batched_files
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let chunked_files = row
            .chunked_files
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let chunk_blocks = row
            .chunk_blocks
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let chunk_hits = row
            .chunk_cache_hits
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let chunk_misses = row
            .chunk_cache_misses
            .map(|value| value.to_string())
            .unwrap_or_else(|| "-".to_string());
        let chunk_plan_hits = optional_to_string(row.chunk_plan_cache_hits);
        let chunk_plan_misses = optional_to_string(row.chunk_plan_cache_misses);
        let columns = vec![
            row.tool.clone(),
            encryption,
            speed,
            kdf_profile,
            session_used,
            session_lookup_ms,
            kdf_skipped_by_session,
            workers,
            cache_index,
            cache_index_open_ms,
            cache_index_commit_ms,
            socket_connect_us,
            socket_pack_roundtrip_us,
            daemon_auth_us,
            daemon_job_execute_us,
            daemon_response_bytes,
            response_serialize_us,
            client_decode_us,
            daemon_used,
            daemon_lookup_ms,
            scheduler_queue_ms,
            cpu_worker_wait_ms,
            buffer_pool_hits,
            buffer_pool_misses,
            cache_pack_range_hits,
            cache_pack_open_count,
            hot_index_reuses,
            hot_metadata_reuses,
            pipeline_peak_memory,
            writer_strategy,
            preallocated,
            preallocation,
            cached_opens,
            cached_range_opens,
            cached_read_bytes,
            prefetched_bytes,
            direct_writes,
            buffered_writes,
            peak_pipeline_bytes,
            row.input_bytes.to_string(),
            archive_bytes,
            reduction,
            duration,
            throughput,
            scan_ms,
            plan_ms,
            kdf_ms,
            kdf_overlap,
            read_ms,
            compression_ms,
            crypto_ms,
            pack_blocks_ms,
            payload_read_ms,
            payload_write_ms,
            writer_wait_ms,
            flush_ms,
            rename_ms,
            sealed_hits,
            sealed_misses,
            sealed_bytes,
            reencrypted,
            payload_files,
            payload_memory,
            cache_pack_hits,
            cache_pack_misses,
            cache_pack_fallbacks,
            cache_hit_rate,
            scan_cache_hit_rate,
            chunk_metadata_reuses,
            trusted_bytes_skipped,
            batch_blocks,
            solid_groups,
            solid_files,
            single_blocks,
            batched_files,
            chunked_files,
            chunk_blocks,
            chunk_hits,
            chunk_misses,
            chunk_plan_hits,
            chunk_plan_misses,
            row.notes.clone(),
        ];
        output.push_str("| ");
        output.push_str(&columns.join(" | "));
        output.push_str(" |\n");
    }
    output
}

fn render_lobehub_profile(
    input_dir: &Path,
    rows: &[BenchmarkRow],
    probe: &CopyProbe,
    summary: &BenchmarkSummary,
) -> String {
    let mut output = String::new();
    output.push_str("# Hig v1.8.5 Lobehub Profile\n\n");
    output.push_str("## Dataset\n\n");
    output.push_str(&format!("- Input: `{}`\n", input_dir.display()));
    output.push_str(&format!("- Files: `{}`\n", summary.file_count));
    output.push_str(&format!("- Bytes: `{}`\n", summary.input_bytes));
    output.push_str(&format!(
        "- Excluded: `{}`\n\n",
        summary.excluded_paths.join(", ")
    ));
    output.push_str("## Top-Level Sizes\n\n");
    output.push_str("| path | bytes |\n|---|---:|\n");
    for (name, bytes) in top_level_sizes(input_dir).unwrap_or_default() {
        output.push_str(&format!("| `{name}` | {bytes} |\n"));
    }
    output.push_str("\n## Comparison\n\n");
    output.push_str("| tool | duration ms | archive bytes | notes |\n|---|---:|---:|---|\n");
    for tool in [
        "higv2 balanced first",
        "higv2 balanced secure daemon",
        "higv2 fastest secure",
        "higv2 no-encryption",
        "zip",
        "tar.gz",
        "tar.zst",
    ] {
        if let Some(row) = rows.iter().find(|row| row.tool == tool) {
            output.push_str(&format!(
                "| {} | {} | {} | {} |\n",
                row.tool,
                row.duration_ms
                    .map(|value| value.to_string())
                    .unwrap_or_else(|| "-".to_string()),
                row.archive_bytes
                    .map(|value| value.to_string())
                    .unwrap_or_else(|| "-".to_string()),
                row.notes
            ));
        }
    }
    output.push_str("\n## Release Gates\n\n");
    output.push_str(&format!(
        "- Environment: `{}` (256MiB copy median {:.2} MiB/s)\n",
        summary.environment_status, probe.copy_256_mib_median
    ));
    output.push_str(&format!(
        "- Pack-core gate: `{}` median {:.3} ms\n",
        summary.pack_core_gate, summary.hig_pack_core.median_ms
    ));
    output.push_str(&format!(
        "- Standalone second median: `{:.3} ms`\n",
        summary.hig_standalone_second.median_ms
    ));
    output.push_str(&format!(
        "- Summary + quiet CLI-wall gate: `{}` median {:.3} ms\n",
        summary.cli_wall_gate, summary.hig_cli_wall.median_ms
    ));
    output.push_str(&format!(
        "- Full + JSON CLI-wall median: `{:.3} ms`\n",
        summary.hig_cli_wall_full.median_ms
    ));
    output.push_str(&format!(
        "- Size-quality gate: `{}`\n\n",
        summary.size_quality_gate
    ));
    if let Some(incremental) = &summary.incremental {
        output.push_str("## Incremental Scenario\n\n");
        output.push_str(&format!(
            "- Modified files: `{}`\n",
            incremental.modified_files.join(", ")
        ));
        output.push_str(&format!(
            "- Hig pack-core: `{:.3} ms`\n",
            incremental.hig_pack_core_ms
        ));
        output.push_str(&format!(
            "- Hig CLI-wall: `{:.3} ms`\n",
            incremental.hig_cli_wall_ms
        ));
        output.push_str(&format!(
            "- zip CLI-wall: `{}`\n",
            incremental
                .zip_cli_wall_ms
                .map(|value| format!("{value:.3} ms"))
                .unwrap_or_else(|| "not available".to_string())
        ));
        output.push_str(&format!(
            "- Cache hit rate: `{:.2}%`\n",
            incremental.cache_hit_rate
        ));
        output.push_str(&format!(
            "- Solid groups/files: `{}/{}`\n",
            incremental.solid_groups, incremental.solid_files
        ));
        output.push_str(&format!(
            "- Journal bytes/entries after: `{}/{}`\n\n",
            incremental.journal_bytes_after, incremental.journal_entries_after
        ));
    }
    output.push_str("## Daemon Hot Path\n\n");
    let daemon_gap_ms = summary.hig_pack_core.median_ms - summary.hig_standalone_second.median_ms;
    output.push_str(&format!(
        "- Daemon pack-core minus standalone second: `{daemon_gap_ms:.3} ms`\n"
    ));
    output.push_str(&format!(
        "- Summary response savings vs Full JSON CLI-wall: `{:.3} ms`\n",
        summary.hig_cli_wall_full.median_ms - summary.hig_cli_wall.median_ms
    ));
    if let Some(row) = rows
        .iter()
        .find(|row| row.tool == "higv2 balanced secure daemon")
    {
        output.push_str(&format!(
            "- Socket connect / roundtrip: `{}/{}` us\n",
            row.socket_connect_us.unwrap_or_default(),
            row.socket_pack_roundtrip_us.unwrap_or_default()
        ));
        output.push_str(&format!(
            "- Daemon auth / job execute: `{}/{}` us\n",
            row.daemon_auth_us.unwrap_or_default(),
            row.daemon_job_execute_us.unwrap_or_default()
        ));
        output.push_str(&format!(
            "- Response serialize / client decode / bytes: `{}/{}/{}`\n",
            row.response_serialize_us.unwrap_or_default(),
            row.client_decode_us.unwrap_or_default(),
            row.daemon_response_bytes.unwrap_or_default()
        ));
        output.push_str(&format!(
            "- Cache commit: `{} ms`\n",
            row.cache_index_commit_ms.unwrap_or_default()
        ));
    }
    output.push_str("\n## Bottleneck Readout\n\n");
    if daemon_gap_ms > 100.0 {
        output.push_str(
            "1. Daemon job execution and scheduler/cache ownership are the primary gap until internal execution is separated further.\n",
        );
        output.push_str(
            "2. Socket roundtrip and response serialization are the second measured source.\n",
        );
        output.push_str(
            "3. Client response decoding/report mode is the third measured source; compare Summary and Full rows.\n",
        );
    } else {
        output.push_str(
            "- Daemon-to-standalone gap is within the 100ms release tolerance; preserve this path as a regression gate.\n",
        );
    }
    output
}

fn top_level_sizes(root: &Path) -> anyhow::Result<Vec<(String, u64)>> {
    let mut rows = Vec::new();
    for entry in fs::read_dir(root)? {
        let entry = entry?;
        let name = entry.file_name().to_string_lossy().to_string();
        let path = entry.path();
        let metadata = entry.metadata()?;
        let bytes = if metadata.is_dir() {
            dir_size(&path)?
        } else if metadata.is_file() {
            metadata.len()
        } else {
            0
        };
        rows.push((name, bytes));
    }
    rows.sort_by_key(|row| std::cmp::Reverse(row.1));
    rows.truncate(20);
    Ok(rows)
}

fn optional_to_string(value: Option<impl ToString>) -> String {
    value
        .map(|value| value.to_string())
        .unwrap_or_else(|| "-".to_string())
}

fn reduction_pct(input_bytes: u64, archive_bytes: u64) -> f64 {
    if input_bytes == 0 {
        0.0
    } else {
        (1.0 - archive_bytes as f64 / input_bytes as f64) * 100.0
    }
}

fn dir_size(path: &Path) -> anyhow::Result<u64> {
    let mut total = 0;
    for entry in fs::read_dir(path)? {
        let entry = entry?;
        let file_name = entry.file_name();
        if file_name == OsStr::new(".hig-cache") {
            continue;
        }
        let metadata = entry.metadata()?;
        if metadata.is_dir() {
            total += dir_size(&entry.path())?;
        } else if metadata.is_file() {
            total += metadata.len();
        }
    }
    Ok(total)
}

fn count_files(path: &Path) -> anyhow::Result<u64> {
    let mut total = 0;
    for entry in fs::read_dir(path)? {
        let entry = entry?;
        let file_name = entry.file_name();
        if file_name == OsStr::new(".hig-cache") {
            continue;
        }
        let metadata = entry.metadata()?;
        if metadata.is_dir() {
            total += count_files(&entry.path())?;
        } else if metadata.is_file() {
            total += 1;
        }
    }
    Ok(total)
}

fn select_benchmark_volume(
    requested: Option<&Path>,
    output_parent: Option<&Path>,
) -> anyhow::Result<CopyProbe> {
    if let Some(path) = requested {
        fs::create_dir_all(path)?;
        return copy_probe(path).with_context(|| {
            format!(
                "requested benchmark directory is not usable: {}",
                path.display()
            )
        });
    }

    let mut candidates = Vec::new();
    if let Some(path) = output_parent {
        candidates.push(path.to_path_buf());
    }
    candidates.push(std::env::temp_dir());
    candidates.push(PathBuf::from("/tmp"));
    candidates.push(PathBuf::from("/private/tmp"));
    let mut unique_candidates = Vec::new();
    for candidate in candidates {
        if !unique_candidates.contains(&candidate) {
            unique_candidates.push(candidate);
        }
    }

    let mut probes = Vec::new();
    for candidate in unique_candidates {
        if fs::create_dir_all(&candidate).is_err() {
            continue;
        }
        if let Ok(probe) = copy_probe(&candidate) {
            if probe.qualified {
                return Ok(probe);
            }
            probes.push(probe);
        }
    }
    probes
        .into_iter()
        .max_by(|left, right| {
            left.copy_256_mib_median
                .partial_cmp(&right.copy_256_mib_median)
                .unwrap_or(std::cmp::Ordering::Equal)
        })
        .ok_or_else(|| anyhow::anyhow!("no usable benchmark directory found"))
}

fn copy_probe(path: &Path) -> anyhow::Result<CopyProbe> {
    let probe_dir = benchmark_work_dir(Some(path))?;
    let copy_32 = copy_speed_samples(&probe_dir, 32 * 1024 * 1024, 3)?;
    let copy_256 = copy_speed_samples(&probe_dir, 256 * 1024 * 1024, 3)?;
    let (free_bytes, used_percent) = volume_stats(path)?;
    let probe = CopyProbe {
        path: path.to_path_buf(),
        free_bytes,
        used_percent,
        copy_32_mib_median: median(&copy_32),
        copy_32_mib_p95: p95(&copy_32),
        copy_256_mib_median: median(&copy_256),
        copy_256_mib_p95: p95(&copy_256),
        qualified: median(&copy_256) >= 650.0
            && p95(&copy_256) >= 500.0
            && free_bytes >= 20 * 1024 * 1024 * 1024
            && used_percent < 90.0,
    };
    let _ = fs::remove_dir_all(probe_dir);
    Ok(probe)
}

fn copy_speed_samples(dir: &Path, bytes: usize, runs: usize) -> anyhow::Result<Vec<f64>> {
    let source = dir.join(format!("copy-source-{bytes}.bin"));
    let mut file = fs::File::create(&source)?;
    let chunk = vec![0xA5_u8; 1024 * 1024];
    let mut remaining = bytes;
    while remaining > 0 {
        let len = remaining.min(chunk.len());
        file.write_all(&chunk[..len])?;
        remaining -= len;
    }
    drop(file);

    let mut speeds = Vec::with_capacity(runs);
    for run in 0..runs {
        let target = dir.join(format!("copy-target-{bytes}-{run}.bin"));
        let started = Instant::now();
        copy_file_buffered(&source, &target)?;
        let seconds = started.elapsed().as_secs_f64().max(0.000_001);
        speeds.push(bytes as f64 / 1024.0 / 1024.0 / seconds);
        let _ = fs::remove_file(target);
    }
    let _ = fs::remove_file(source);
    Ok(speeds)
}

fn copy_file_buffered(source: &Path, target: &Path) -> anyhow::Result<()> {
    let mut input = fs::File::open(source)?;
    let mut output = fs::File::create(target)?;
    let mut buffer = vec![0_u8; 8 * 1024 * 1024];
    loop {
        let read = input.read(&mut buffer)?;
        if read == 0 {
            break;
        }
        output.write_all(&buffer[..read])?;
    }
    output.flush()?;
    Ok(())
}

fn volume_stats(path: &Path) -> anyhow::Result<(u64, f64)> {
    let output = ProcessCommand::new("df").arg("-k").arg(path).output()?;
    if !output.status.success() {
        anyhow::bail!("df failed for {}", path.display());
    }
    let text = String::from_utf8_lossy(&output.stdout);
    let line = text
        .lines()
        .nth(1)
        .ok_or_else(|| anyhow::anyhow!("df output missing data line"))?;
    let columns = line.split_whitespace().collect::<Vec<_>>();
    if columns.len() < 5 {
        anyhow::bail!("unexpected df output: {line}");
    }
    let free_kib = columns[3].parse::<u64>()?;
    let used_percent = columns[4].trim_end_matches('%').parse::<f64>()?;
    Ok((free_kib * 1024, used_percent))
}

fn median(values: &[f64]) -> f64 {
    percentile(values, 0.5)
}

fn p95(values: &[f64]) -> f64 {
    percentile(values, 0.95)
}

fn percentile(values: &[f64], percentile: f64) -> f64 {
    if values.is_empty() {
        return 0.0;
    }
    let mut values = values.to_vec();
    values.sort_by(|left, right| left.partial_cmp(right).unwrap_or(std::cmp::Ordering::Equal));
    let index = ((values.len() - 1) as f64 * percentile).ceil() as usize;
    values[index]
}

fn benchmark_work_dir(base: Option<&Path>) -> anyhow::Result<PathBuf> {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    let root = base
        .map(Path::to_path_buf)
        .unwrap_or_else(std::env::temp_dir);
    let path = root.join(format!("hig-bench-{}-{nanos}", std::process::id()));
    fs::create_dir_all(&path)?;
    Ok(path)
}

fn command_exists(name: &str) -> bool {
    ProcessCommand::new("sh")
        .arg("-c")
        .arg(format!("command -v {name} >/dev/null 2>&1"))
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn encryption_arguments_are_strict() {
        assert!(validate_pack_encryption_args(EncryptionMode::Password, Some("pw"), false).is_ok());
        assert!(validate_pack_encryption_args(EncryptionMode::Password, None, false).is_err());
        assert!(validate_pack_encryption_args(EncryptionMode::Password, None, true).is_ok());
        assert!(validate_pack_encryption_args(EncryptionMode::None, None, false).is_ok());
        assert!(validate_pack_encryption_args(EncryptionMode::None, Some("pw"), false).is_err());
        assert!(validate_pack_encryption_args(EncryptionMode::None, None, true).is_err());
    }

    #[test]
    fn fastest_defaults_to_interactive_but_respects_secure() {
        assert_eq!(
            effective_kdf_profile(SpeedMode::Balanced, None),
            KdfProfile::Secure
        );
        assert_eq!(
            effective_kdf_profile(SpeedMode::Fastest, None),
            KdfProfile::Interactive
        );
        assert_eq!(
            effective_kdf_profile(SpeedMode::Fastest, Some(KdfProfile::Secure)),
            KdfProfile::Secure
        );
    }

    #[test]
    fn report_flags_are_mutually_exclusive() {
        assert_eq!(
            ReportFlags {
                verbose: false,
                json: false,
                quiet: false,
            }
            .mode()
            .unwrap(),
            ReportMode::Short
        );
        assert_eq!(
            ReportFlags {
                verbose: true,
                json: false,
                quiet: false,
            }
            .mode()
            .unwrap(),
            ReportMode::Verbose
        );
        assert!(
            ReportFlags {
                verbose: true,
                json: true,
                quiet: false,
            }
            .mode()
            .is_err()
        );
    }

    #[test]
    fn report_mode_selects_daemon_response_shape() {
        assert_eq!(
            response_mode_for_report(ReportMode::Short),
            PackResponseMode::Summary
        );
        assert_eq!(
            response_mode_for_report(ReportMode::Quiet),
            PackResponseMode::Summary
        );
        assert_eq!(
            response_mode_for_report(ReportMode::Verbose),
            PackResponseMode::Full
        );
        assert_eq!(
            response_mode_for_report(ReportMode::Json),
            PackResponseMode::Full
        );
    }
}
