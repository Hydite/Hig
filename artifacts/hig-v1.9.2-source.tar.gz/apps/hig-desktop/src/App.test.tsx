import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";
import { api } from "./api";

vi.mock("./api", async () => {
  const actual = await vi.importActual<typeof import("./api")>("./api");
  return {
    ...actual,
    api: {
      bootstrap: vi.fn(),
      tasks: vi.fn(),
      projectStatus: vi.fn(),
      updateSettings: vi.fn(),
      unlockSession: vi.fn(),
      clearSession: vi.fn()
    }
  };
});

const snapshot = {
  version: "1.9.2",
  platform: "macos",
  daemonActive: true,
  sessionActive: false,
  settings: {
    defaultOutputDir: null,
    defaultSpeed: "balanced" as const,
    defaultEncryption: "password" as const,
    sessionTtlSecs: 1800,
    recentProjects: []
  }
};

describe("Hig desktop", () => {
  afterEach(() => cleanup());

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(api.bootstrap).mockResolvedValue(snapshot);
    vi.mocked(api.tasks).mockResolvedValue([]);
  });

  it("opens on the operational project workspace", async () => {
    render(<App />);
    expect(await screen.findByRole("heading", { name: "Projects" })).toBeInTheDocument();
    expect(screen.getByText("Secure defaults")).toBeInTheDocument();
    expect(screen.getByText("Daemon online")).toBeInTheDocument();
  });

  it("shows safe archive defaults and explicit fastest risk", async () => {
    render(<App />);
    await waitFor(() => expect(screen.getByText("Secure defaults")).toBeInTheDocument());
    fireEvent.click(screen.getByRole("button", { name: "Create archive" }));
    expect(screen.getByText("Balanced")).toBeInTheDocument();
    expect(screen.getByText("Password")).toBeInTheDocument();
    fireEvent.change(screen.getByRole("combobox", { name: "Speed mode" }), { target: { value: "fastest" } });
    expect(screen.getByText(/trusts metadata/i)).toBeInTheDocument();
  });

  it("clears the session password after unlock", async () => {
    vi.mocked(api.unlockSession).mockResolvedValue({});
    render(<App />);
    await waitFor(() => expect(screen.getByText("Secure defaults")).toBeInTheDocument());
    fireEvent.click(screen.getByRole("button", { name: /Session locked/i }));
    const password = screen.getByLabelText("Password");
    fireEvent.change(password, { target: { value: "temporary-password" } });
    fireEvent.click(screen.getByRole("button", { name: "Unlock" }));
    await waitFor(() => expect(api.unlockSession).toHaveBeenCalled());
    expect(screen.queryByDisplayValue("temporary-password")).not.toBeInTheDocument();
  });
});
