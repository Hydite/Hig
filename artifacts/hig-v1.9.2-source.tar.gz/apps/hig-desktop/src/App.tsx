import { useEffect, useMemo, useState } from "react";
import {
  Archive,
  ArchiveRestore,
  Boxes,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  Database,
  FolderArchive,
  FolderOpen,
  Gauge,
  KeyRound,
  ListTree,
  LoaderCircle,
  LockKeyhole,
  Menu,
  PackageOpen,
  Play,
  RefreshCw,
  Search,
  Settings as SettingsIcon,
  ShieldCheck,
  Square,
  Trash2,
  Unlock,
  X,
} from "lucide-react";
import { api, errorMessage } from "./api";
import type {
  AppSnapshot,
  ArchiveInspection,
  CacheReport,
  NavId,
  ProjectStatus,
  Settings,
  TaskStatus,
} from "./types";

const navigation: Array<{ id: NavId; label: string; icon: typeof Archive }> = [
  { id: "projects", label: "Projects", icon: ListTree },
  { id: "create", label: "Create archive", icon: FolderArchive },
  { id: "open", label: "Open archive", icon: PackageOpen },
  { id: "tasks", label: "Tasks", icon: Gauge },
  { id: "cache", label: "Cache", icon: Database },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];

const emptySettings: Settings = {
  defaultOutputDir: null,
  defaultSpeed: "balanced",
  defaultEncryption: "password",
  sessionTtlSecs: 1800,
  recentProjects: [],
};

function formatBytes(value: number | null | undefined): string {
  if (!value) return "0 B";
  const units = ["B", "KiB", "MiB", "GiB"];
  const power = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
  return `${(value / 1024 ** power).toFixed(power === 0 ? 0 : 1)} ${units[power]}`;
}

function basename(path: string): string {
  return path.split(/[\\/]/).filter(Boolean).at(-1) ?? path;
}

function statusTone(phase: string): "ok" | "warn" | "bad" | "live" {
  if (phase === "Completed" || phase === "Ready") return "ok";
  if (phase === "Failed" || phase === "Invalid") return "bad";
  if (phase === "Cancelled" || phase === "Dirty") return "warn";
  return "live";
}

export default function App() {
  const [nav, setNav] = useState<NavId>("projects");
  const [snapshot, setSnapshot] = useState<AppSnapshot | null>(null);
  const [tasks, setTasks] = useState<TaskStatus[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sessionDialog, setSessionDialog] = useState(false);
  const [sessionPassword, setSessionPassword] = useState("");

  useEffect(() => {
    api.bootstrap().then(setSnapshot).catch((error) => setNotice(errorMessage(error)));
    const poll = window.setInterval(() => api.tasks().then(setTasks).catch(() => undefined), 500);
    return () => window.clearInterval(poll);
  }, []);

  const activeTasks = tasks.filter((task) => !["Completed", "Failed", "Cancelled"].includes(task.phase));
  const settings = snapshot?.settings ?? emptySettings;
  const updateSnapshotSettings = (next: Settings) => {
    setSnapshot((current) => current && { ...current, settings: next });
  };
  const unlockSession = async () => {
    try {
      await api.unlockSession(sessionPassword, settings.sessionTtlSecs);
      setSessionPassword("");
      setSessionDialog(false);
      setSnapshot((current) => current && { ...current, daemonActive: true, sessionActive: true });
    } catch (error) {
      setSessionPassword("");
      setNotice(errorMessage(error));
    }
  };
  const clearSession = async () => {
    try {
      await api.clearSession();
      setSnapshot((current) => current && { ...current, sessionActive: false });
    } catch (error) {
      setNotice(errorMessage(error));
    }
  };

  return (
    <div className="app-shell">
      <aside className={sidebarOpen ? "sidebar is-open" : "sidebar"}>
        <div className="brand-row">
          <img src="/icon.png" alt="" className="brand-mark" />
          <div><strong>Hig</strong><span>Archive engine</span></div>
          <button className="icon-button sidebar-close" onClick={() => setSidebarOpen(false)} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <nav aria-label="Primary navigation">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <button key={item.id} className={nav === item.id ? "nav-item active" : "nav-item"} onClick={() => { setNav(item.id); setSidebarOpen(false); }}>
                <Icon size={18} /><span>{item.label}</span>
                {item.id === "tasks" && activeTasks.length > 0 && <b>{activeTasks.length}</b>}
              </button>
            );
          })}
        </nav>
        <div className="sidebar-status">
          <div className="status-line"><span className={snapshot?.daemonActive ? "status-dot ok" : "status-dot"} />Daemon {snapshot?.daemonActive ? "online" : "offline"}</div>
          <button className="status-line session-action" onClick={() => snapshot?.sessionActive ? void clearSession() : setSessionDialog(true)}><KeyRound size={14} />Session {snapshot?.sessionActive ? "unlocked" : "locked"}</button>
          <small>v{snapshot?.version ?? "1.9.2"}</small>
        </div>
      </aside>

      <div className="workspace">
        <header className="topbar">
          <button className="icon-button menu-button" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Menu size={20} /></button>
          <div><span className="eyebrow">HIG WORKSPACE</span><h1>{navigation.find((item) => item.id === nav)?.label}</h1></div>
          <div className="topbar-actions">
            {activeTasks.length > 0 && <button className="task-live" onClick={() => setNav("tasks")}><LoaderCircle size={15} className="spin" />{activeTasks.length} active</button>}
            <span className="security-chip"><ShieldCheck size={15} />Secure defaults</span>
          </div>
        </header>

        {notice && <div className="notice"><CircleAlert size={17} /><span>{notice}</span><button onClick={() => setNotice(null)} aria-label="Dismiss"><X size={16} /></button></div>}

        <main className="content">
          {nav === "projects" && <ProjectsPage settings={settings} onSettings={updateSnapshotSettings} onNavigate={setNav} onError={setNotice} />}
          {nav === "create" && <CreatePage settings={settings} onTask={(task) => { setTasks((items) => [task, ...items]); setNav("tasks"); }} onError={setNotice} />}
          {nav === "open" && <OpenArchivePage onTask={(task) => { setTasks((items) => [task, ...items]); setNav("tasks"); }} onError={setNotice} />}
          {nav === "tasks" && <TasksPage tasks={tasks} onTasks={setTasks} onError={setNotice} />}
          {nav === "cache" && <CachePage onError={setNotice} />}
          {nav === "settings" && <SettingsPage settings={settings} onSettings={updateSnapshotSettings} onError={setNotice} />}
        </main>
      </div>
      {sessionDialog && <div className="modal-backdrop" role="presentation" onMouseDown={() => { setSessionPassword(""); setSessionDialog(false); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="session-title" onMouseDown={(event) => event.stopPropagation()}><div className="modal-icon"><Unlock size={22} /></div><h2 id="session-title">Unlock secure session</h2><p>Derive the secure key once and keep it only in daemon memory for {Math.round(settings.sessionTtlSecs / 60)} minutes.</p><label><span>Password</span><input autoFocus type="password" value={sessionPassword} onChange={(event) => setSessionPassword(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && sessionPassword) void unlockSession(); }} /></label><div className="modal-actions"><button className="secondary-button" onClick={() => { setSessionPassword(""); setSessionDialog(false); }}>Cancel</button><button className="primary-button" disabled={!sessionPassword} onClick={unlockSession}><KeyRound size={16} />Unlock</button></div></section></div>}
    </div>
  );
}

function ProjectsPage({ settings, onSettings, onNavigate, onError }: { settings: Settings; onSettings: (settings: Settings) => void; onNavigate: (nav: NavId) => void; onError: (message: string) => void }) {
  const [statuses, setStatuses] = useState<Record<string, ProjectStatus>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    settings.recentProjects.forEach((path) => api.projectStatus(path).then((status) => setStatuses((current) => ({ ...current, [path]: status }))).catch(() => undefined));
  }, [settings.recentProjects]);

  const addProject = async () => {
    const directory = await api.chooseDirectory();
    if (!directory) return;
    setBusy(true);
    try {
      const status = await api.initializeProject(directory);
      setStatuses((current) => ({ ...current, [directory]: status }));
      const next = { ...settings, recentProjects: [directory, ...settings.recentProjects.filter((path) => path !== directory)].slice(0, 12) };
      onSettings(await api.updateSettings(next));
    } catch (error) { onError(errorMessage(error)); } finally { setBusy(false); }
  };

  return (
    <div className="page-stack">
      <section className="page-heading">
        <div><h2>Watched projects</h2><p>Verified snapshots and prepared objects stay ready for the next archive.</p></div>
        <button className="primary-button" onClick={addProject} disabled={busy}><FolderOpen size={17} />Initialize project</button>
      </section>
      {settings.recentProjects.length === 0 ? (
        <section className="empty-state"><ListTree size={28} /><h3>No initialized projects</h3><p>Initialize a codebase to enable verified watching and background preparation.</p><button className="secondary-button" onClick={addProject}>Choose directory</button></section>
      ) : (
        <div className="project-list">
          {settings.recentProjects.map((path) => {
            const status = statuses[path];
            const state = status?.snapshotValidity ?? "Building";
            return <article className="project-row" key={path}>
              <div className={`project-icon ${statusTone(state)}`}><Boxes size={20} /></div>
              <div className="project-main"><div className="project-name"><strong>{basename(path)}</strong><span className={`badge ${statusTone(state)}`}>{state}</span></div><code>{path}</code></div>
              <dl><div><dt>Files</dt><dd>{status?.files?.toLocaleString() ?? "—"}</dd></div><div><dt>Generation</dt><dd>{status?.generation ?? "—"}</dd></div><div><dt>Prepared</dt><dd>{formatBytes(status?.preparedBytes)}</dd></div></dl>
              <div className="row-actions"><button className="icon-button" title="Rebuild project" onClick={() => api.rebuildProject(path).then((next) => setStatuses((current) => ({ ...current, [path]: next }))).catch((error) => onError(errorMessage(error)))}><RefreshCw size={17} /></button><button className="secondary-button" onClick={() => onNavigate("create")}>Archive<ChevronRight size={15} /></button></div>
            </article>;
          })}
        </div>
      )}
      <section className="metric-band"><div><span>Project mode</span><strong>Content verified</strong></div><div><span>Watcher</span><strong>Event-aware</strong></div><div><span>Prepared cache</span><strong>Encrypted on pack</strong></div></section>
    </div>
  );
}

function CreatePage({ settings, onTask, onError }: { settings: Settings; onTask: (task: TaskStatus) => void; onError: (message: string) => void }) {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [password, setPassword] = useState("");
  const [speed, setSpeed] = useState(settings.defaultSpeed);
  const [encryption, setEncryption] = useState(settings.defaultEncryption);
  const [advanced, setAdvanced] = useState(false);
  const [trustMetadata, setTrustMetadata] = useState(false);
  const [busy, setBusy] = useState(false);

  const selectInput = async () => { const path = await api.chooseDirectory(); if (path) { setInput(path); if (!output) setOutput(`${path}.hig`); } };
  const selectOutput = async () => { const path = await api.chooseArchiveOutput(); if (path) setOutput(path); };
  const submit = async () => {
    if (!input || !output) return onError("Choose an input directory and output archive.");
    if (encryption === "password" && !password) return onError("A password is required for secure archives.");
    setBusy(true);
    try {
      const task = await api.startPack({ inputDir: input, outputFile: output, password: encryption === "password" ? password : null, encryption, speed, cacheDir: null, trustMetadata: trustMetadata || speed === "fastest" });
      setPassword("");
      onTask(task);
    } catch (error) { onError(errorMessage(error)); } finally { setBusy(false); }
  };

  return <div className="page-stack form-page">
    <section className="page-heading"><div><h2>Create a Hig archive</h2><p>Balanced mode keeps strong security and high compression quality.</p></div></section>
    <section className="form-section"><h3>Source and destination</h3><PathField label="Input directory" value={input} placeholder="Choose a directory" onChoose={selectInput} /><PathField label="Output archive" value={output} placeholder="Choose an .hig file" onChoose={selectOutput} /></section>
    <section className="form-section"><h3>Archive policy</h3><div className="field-grid"><label><span>Speed mode</span><select value={speed} onChange={(event) => setSpeed(event.target.value as "balanced" | "fastest")}><option value="balanced">Balanced</option><option value="fastest">Fastest</option></select></label><label><span>Encryption</span><select value={encryption} onChange={(event) => setEncryption(event.target.value as "password" | "none")}><option value="password">Password + AEAD</option><option value="none">No encryption</option></select></label></div>{encryption === "password" ? <label className="password-field"><span>Password</span><div><LockKeyhole size={17} /><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="new-password" placeholder="Not stored" /></div></label> : <div className="warning-line"><CircleAlert size={17} />No-encryption archives provide integrity checks but no confidentiality.</div>}{speed === "fastest" && <div className="warning-line"><CircleAlert size={17} />Fastest mode trusts metadata and can reveal equal blocks across local archives.</div>}</section>
    <section className="advanced-toggle"><button onClick={() => setAdvanced(!advanced)}>Advanced settings<ChevronRight className={advanced ? "rotate" : ""} size={16} /></button>{advanced && <div className="advanced-panel"><label className="check-row"><input type="checkbox" checked={trustMetadata} onChange={(event) => setTrustMetadata(event.target.checked)} /><span><strong>Trust file metadata</strong><small>Skip content hashing when size, times and permissions match.</small></span></label><div className="policy-readout"><span>Batch</span><b>Auto · 4 MiB</b><span>Chunks</span><b>1 MiB · ≥8 MiB files</b><span>Solid groups</span><b>{speed === "balanced" ? "Auto" : "Off"}</b></div></div>}</section>
    <footer className="form-footer"><div><ShieldCheck size={18} /><span>{encryption === "password" ? "Argon2id + ChaCha20-Poly1305" : "BLAKE3 integrity only"}</span></div><button className="primary-button" onClick={submit} disabled={busy}><Play size={17} />{busy ? "Starting…" : "Create archive"}</button></footer>
  </div>;
}

function PathField({ label, value, placeholder, onChoose }: { label: string; value: string; placeholder: string; onChoose: () => void }) {
  return <label className="path-field"><span>{label}</span><div><code>{value || placeholder}</code><button className="icon-button" onClick={onChoose} type="button" aria-label={`Choose ${label}`}><FolderOpen size={18} /></button></div></label>;
}

function OpenArchivePage({ onTask, onError }: { onTask: (task: TaskStatus) => void; onError: (message: string) => void }) {
  const [path, setPath] = useState("");
  const [password, setPassword] = useState("");
  const [inspection, setInspection] = useState<ArchiveInspection | null>(null);
  const [query, setQuery] = useState("");
  const [output, setOutput] = useState("");
  const files = useMemo(() => inspection?.files.filter((file) => file.relativePath.toLowerCase().includes(query.toLowerCase())) ?? [], [inspection, query]);
  const choose = async () => { const next = await api.chooseArchive(); if (next) { setPath(next); setInspection(null); } };
  const inspect = async () => { try { const result = await api.inspectArchive(path, password); setInspection(result); setPassword(""); } catch (error) { onError(errorMessage(error)); } };
  const extract = async () => { if (!output) return onError("Choose an output directory."); try { const task = await api.startUnpack({ archiveFile: path, outputDir: output, password: password || null, overwrite: false }); setPassword(""); onTask(task); } catch (error) { onError(errorMessage(error)); } };
  return <div className="page-stack"><section className="page-heading"><div><h2>Inspect and extract</h2><p>Authenticate the manifest before viewing archive contents.</p></div><button className="secondary-button" onClick={choose}><FolderOpen size={17} />Choose archive</button></section><section className="archive-toolbar"><code>{path || "No archive selected"}</code><label><LockKeyhole size={16} /><input type="password" placeholder="Password if encrypted" value={password} onChange={(event) => setPassword(event.target.value)} /></label><button className="primary-button" disabled={!path} onClick={inspect}><Search size={16} />Inspect</button></section>{inspection ? <><section className="archive-summary"><div><span>Format</span><strong>{inspection.format}</strong></div><div><span>Files</span><strong>{inspection.files.length.toLocaleString()}</strong></div><div><span>Original</span><strong>{formatBytes(inspection.inputBytes)}</strong></div><div><span>Archive</span><strong>{formatBytes(inspection.archiveBytes)}</strong></div><div><span>Security</span><strong>{inspection.encrypted ? "Encrypted" : "Integrity only"}</strong></div></section><section className="file-browser"><div className="table-toolbar"><h3>Archive contents</h3><label><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Filter paths" /></label></div><div className="file-table" role="table"><div className="file-row header" role="row"><span>Path</span><span>Size</span><span>Mode</span></div>{files.slice(0, 500).map((file) => <div className="file-row" role="row" key={file.relativePath}><span title={file.relativePath}>{file.relativePath}</span><span>{formatBytes(file.size)}</span><span>{file.permissions.toString(8)}</span></div>)}</div>{files.length > 500 && <small className="table-note">Showing 500 of {files.length.toLocaleString()} matches</small>}</section><section className="extract-bar"><PathField label="Extract to" value={output} placeholder="Choose destination" onChoose={async () => { const selected = await api.chooseDirectory(); if (selected) setOutput(selected); }} /><button className="primary-button" onClick={extract}><ArchiveRestore size={17} />Extract archive</button></section></> : <section className="empty-state compact"><Archive size={28} /><h3>Choose an archive to inspect</h3><p>Hig reads and authenticates only the manifest until extraction starts.</p></section>}</div>;
}

function TasksPage({ tasks, onTasks, onError }: { tasks: TaskStatus[]; onTasks: (tasks: TaskStatus[]) => void; onError: (message: string) => void }) {
  const cancel = async (id: string) => { try { const next = await api.cancelTask(id); onTasks(tasks.map((task) => task.id === id ? next : task)); } catch (error) { onError(errorMessage(error)); } };
  return <div className="page-stack"><section className="page-heading"><div><h2>Current session</h2><p>Progress and results are kept in memory and cleared when Hig exits.</p></div><span className="count-label">{tasks.length} tasks</span></section>{tasks.length === 0 ? <section className="empty-state"><Gauge size={28} /><h3>No tasks yet</h3><p>Create or extract an archive to see detailed task state here.</p></section> : <div className="task-list">{[...tasks].reverse().map((task) => <article className="task-row" key={task.id}><div className={`task-state ${statusTone(task.phase)}`}>{task.phase === "Completed" ? <CheckCircle2 size={20} /> : task.phase === "Failed" ? <CircleAlert size={20} /> : task.phase === "Cancelled" ? <Square size={18} /> : <LoaderCircle className="spin" size={20} />}</div><div className="task-main"><div><strong>{task.kind === "Pack" ? "Create archive" : "Extract archive"}</strong><span className={`badge ${statusTone(task.phase)}`}>{task.phase}</span></div><code>{task.outputPath}</code><div className="progress-track"><span style={{ width: task.bytesTotal ? `${Math.min(100, task.bytesDone / task.bytesTotal * 100)}%` : task.phase === "Completed" ? "100%" : "35%" }} /></div><small>{task.message ?? task.phase}{task.archiveBytes ? ` · ${formatBytes(task.archiveBytes)}` : ""}</small>{task.error && <p className="task-error">{task.error.message}</p>}</div><div className="task-actions">{task.cancellable && <button className="icon-button danger" title="Cancel task" onClick={() => cancel(task.id)}><Square size={16} /></button>}</div></article>)}</div>}</div>;
}

function CachePage({ onError }: { onError: (message: string) => void }) {
  const [report, setReport] = useState<CacheReport | null>(null);
  const refresh = () => api.cacheStatus().then(setReport).catch((error) => onError(errorMessage(error)));
  useEffect(() => {
    void api.cacheStatus().then(setReport).catch((error) => onError(errorMessage(error)));
  }, [onError]);
  const maintain = async (kind: "gc" | "compact") => { try { const preview = kind === "gc" ? await api.cacheGc(undefined, true) : await api.cacheCompact(undefined, true); if (window.confirm(`${kind === "gc" ? "Remove" : "Compact"} up to ${formatBytes(preview.removableBytes || preview.journalEstimatedReclaimedBytes)}?`)) { setReport(kind === "gc" ? await api.cacheGc(undefined, false) : await api.cacheCompact(undefined, false)); } } catch (error) { onError(errorMessage(error)); } };
  return <div className="page-stack"><section className="page-heading"><div><h2>Cache maintenance</h2><p>Compressed objects accelerate repeated archives without storing passwords or keys.</p></div><button className="icon-button" onClick={refresh} title="Refresh cache"><RefreshCw size={18} /></button></section>{report ? <><section className="cache-usage"><div className="cache-gauge"><span style={{ width: `${Math.min(100, report.totalBytes / Math.max(1, report.budgetBytes) * 100)}%` }} /></div><div><strong>{formatBytes(report.totalBytes)}</strong><span>of {formatBytes(report.budgetBytes)} budget</span></div></section><section className="stats-grid"><div><span>Objects</span><strong>{report.files.toLocaleString()}</strong></div><div><span>Generation</span><strong>{report.generation}</strong></div><div><span>Journal</span><strong>{formatBytes(report.journalBytes)}</strong></div><div><span>Entries</span><strong>{report.journalEntries.toLocaleString()}</strong></div></section><section className="maintenance-list"><div><div><Trash2 size={20} /><span><strong>Garbage collection</strong><small>Remove least-recently-used cache objects above the budget.</small></span></div><button className="secondary-button" onClick={() => maintain("gc")}>Dry-run and clean</button></div><div><div><Database size={20} /><span><strong>Journal compaction</strong><small>{report.journalCompactRecommended ? "Recommended now" : "Journal is within healthy limits"}</small></span></div><button className="secondary-button" onClick={() => maintain("compact")}>Dry-run and compact</button></div></section></> : <section className="empty-state compact"><Database size={28} /><h3>Cache daemon unavailable</h3><p>Start a project watcher or daemon to inspect its cache.</p></section>}</div>;
}

function SettingsPage({ settings, onSettings, onError }: { settings: Settings; onSettings: (settings: Settings) => void; onError: (message: string) => void }) {
  const [draft, setDraft] = useState(settings);
  useEffect(() => setDraft(settings), [settings]);
  const save = async () => { try { onSettings(await api.updateSettings(draft)); } catch (error) { onError(errorMessage(error)); } };
  return <div className="page-stack form-page"><section className="page-heading"><div><h2>Application defaults</h2><p>Only non-sensitive preferences are written to disk.</p></div></section><section className="form-section"><h3>Archive defaults</h3><div className="field-grid"><label><span>Speed</span><select value={draft.defaultSpeed} onChange={(event) => setDraft({ ...draft, defaultSpeed: event.target.value as Settings["defaultSpeed"] })}><option value="balanced">Balanced</option><option value="fastest">Fastest</option></select></label><label><span>Encryption</span><select value={draft.defaultEncryption} onChange={(event) => setDraft({ ...draft, defaultEncryption: event.target.value as Settings["defaultEncryption"] })}><option value="password">Password</option><option value="none">None</option></select></label><label><span>Session TTL</span><select value={draft.sessionTtlSecs} onChange={(event) => setDraft({ ...draft, sessionTtlSecs: Number(event.target.value) })}><option value={900}>15 minutes</option><option value={1800}>30 minutes</option><option value={3600}>1 hour</option><option value={7200}>2 hours</option></select></label></div></section><section className="form-section"><h3>Security</h3><div className="security-note"><ShieldCheck size={21} /><div><strong>Passwords never enter settings or task history.</strong><p>They are cleared from the interface after the Rust operation begins.</p></div></div></section><footer className="form-footer"><span>{draft.recentProjects.length} recent projects</span><button className="primary-button" onClick={save}>Save settings</button></footer></div>;
}
