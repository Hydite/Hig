import { invoke } from "@tauri-apps/api/core";
import { open, save } from "@tauri-apps/plugin-dialog";
import type {
  AppSnapshot,
  ArchiveInspection,
  CacheReport,
  ProjectStatus,
  Settings,
  TaskStatus,
} from "./types";

export const api = {
  bootstrap: () => invoke<AppSnapshot>("bootstrap_app"),
  settings: () => invoke<Settings>("get_settings"),
  updateSettings: (settings: Settings) => invoke<Settings>("update_settings", { settings }),
  initializeProject: (directory: string, cacheDir?: string) =>
    invoke<ProjectStatus>("initialize_project", { directory, cacheDir: cacheDir ?? null }),
  projectStatus: (directory: string) => invoke<ProjectStatus>("get_project_status", { directory }),
  rebuildProject: (directory: string) => invoke<ProjectStatus>("rebuild_project", { directory }),
  startPack: (request: Record<string, unknown>) => invoke<TaskStatus>("start_pack", { request }),
  startUnpack: (request: Record<string, unknown>) => invoke<TaskStatus>("start_unpack", { request }),
  inspectArchive: (path: string, password?: string) =>
    invoke<ArchiveInspection>("inspect_archive", { path, password: password || null }),
  tasks: () => invoke<TaskStatus[]>("list_tasks"),
  task: (taskId: string) => invoke<TaskStatus>("get_task_status", { taskId }),
  cancelTask: (taskId: string) => invoke<TaskStatus>("cancel_task", { taskId }),
  sessionStatus: (cacheDir?: string) => invoke("get_session_status", { cacheDir: cacheDir || null }),
  unlockSession: (password: string, ttlSecs: number, cacheDir?: string) =>
    invoke("unlock_session", { cacheDir: cacheDir || null, password, ttlSecs }),
  clearSession: (cacheDir?: string) => invoke<boolean>("clear_session", { cacheDir: cacheDir || null }),
  cacheStatus: (cacheDir?: string) => invoke<CacheReport>("get_cache_status", { cacheDir: cacheDir || null }),
  cacheGc: (cacheDir: string | undefined, dryRun: boolean) =>
    invoke<CacheReport>("run_cache_gc", { cacheDir: cacheDir || null, dryRun }),
  cacheCompact: (cacheDir: string | undefined, dryRun: boolean) =>
    invoke<CacheReport>("run_cache_compact", { cacheDir: cacheDir || null, dryRun }),
  chooseDirectory: async () => {
    const path = await open({ directory: true, multiple: false });
    return typeof path === "string" ? path : null;
  },
  chooseArchive: async () => {
    const path = await open({ multiple: false, filters: [{ name: "Hig Archive", extensions: ["hig"] }] });
    return typeof path === "string" ? path : null;
  },
  chooseArchiveOutput: async () =>
    save({ filters: [{ name: "Hig Archive", extensions: ["hig"] }], defaultPath: "archive.hig" }),
};

export function errorMessage(error: unknown): string {
  if (typeof error === "string") return error;
  if (error && typeof error === "object" && "message" in error) return String(error.message);
  return "The operation could not be completed.";
}
