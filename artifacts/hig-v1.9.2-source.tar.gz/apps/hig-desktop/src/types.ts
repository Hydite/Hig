export type NavId = "projects" | "create" | "open" | "tasks" | "cache" | "settings";

export interface AppError {
  code: string;
  message: string;
  recoverable: boolean;
}

export interface Settings {
  defaultOutputDir: string | null;
  defaultSpeed: "balanced" | "fastest";
  defaultEncryption: "password" | "none";
  sessionTtlSecs: number;
  recentProjects: string[];
}

export interface AppSnapshot {
  version: string;
  platform: string;
  settings: Settings;
  daemonActive: boolean;
  sessionActive: boolean;
}

export interface ProjectStatus {
  initialized: boolean;
  projectId: number[] | null;
  root: string;
  cacheDir: string;
  snapshotValidity: "Building" | "Ready" | "Dirty" | "Invalid";
  generation: number;
  eventSequence: number;
  files: number;
  pendingEvents: number;
  dirtyFiles: number;
  dirtyGroups: number;
  watcherBackend: string;
  watcherOverflowCount: number;
  preparedBytes: number;
  lastEventAgeMs: number;
}

export interface TaskStatus {
  id: string;
  kind: "Pack" | "Unpack" | "Inspect" | "ProjectRebuild" | "CacheMaintenance";
  phase: string;
  filesDone: number;
  filesTotal: number | null;
  bytesDone: number;
  bytesTotal: number | null;
  elapsedUs: number;
  message: string | null;
  outputPath: string | null;
  archiveBytes: number | null;
  inputBytes: number | null;
  error: AppError | null;
  cancellable: boolean;
}

export interface ArchiveFile {
  relativePath: string;
  size: number;
  modifiedUnixNs: number;
  permissions: number;
  contentHash: number[];
}

export interface ArchiveInspection {
  format: "HigV1" | "HigV2";
  encrypted: boolean;
  files: ArchiveFile[];
  inputBytes: number;
  archiveBytes: number;
}

export interface CacheReport {
  totalBytes: number;
  budgetBytes: number;
  files: number;
  removableBytes: number;
  removedBytes: number;
  compactedBytes: number;
  generation: number;
  dryRun: boolean;
  journalBytes: number;
  journalEntries: number;
  journalCompactRecommended: boolean;
  journalEstimatedReclaimedBytes: number;
}
