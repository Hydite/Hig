use hig_core::{
    ArchiveInspection, BatchOptions, ChunkOptions, Compression, DaemonRequest, DaemonResponse,
    EncryptionMode, KdfProfile, ManifestFormat, OperationKind, OperationPhase, PackAuthMode,
    PackJobRequest, PipelineOptions, ProjectStatusReport, SerializablePackOptions,
    SerializableUnpackOptions, SolidMode, SpeedMode, TaskRequest, TaskResult, TaskState,
    TaskStatusReport, TaskSubmitRequest, UnpackJobRequest, daemon_status, default_session_ttl,
    derive_key, derive_session_binding, discover_project, init_project,
    inspect_archive as inspect_hig_archive, request_daemon, resolve_project_cache_dir,
};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tauri::{AppHandle, Emitter, Manager, State};
use zeroize::{Zeroize, Zeroizing};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AppError {
    code: String,
    message: String,
    recoverable: bool,
}

impl AppError {
    fn from_error(code: &str, error: impl std::fmt::Display, recoverable: bool) -> Self {
        Self {
            code: code.to_string(),
            message: error.to_string(),
            recoverable,
        }
    }
}

type AppResult<T> = Result<T, AppError>;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct AppSettings {
    default_output_dir: Option<String>,
    default_speed: String,
    default_encryption: String,
    session_ttl_secs: u64,
    recent_projects: Vec<String>,
    #[serde(default = "default_language")]
    language: String,
}

impl Default for AppSettings {
    fn default() -> Self {
        Self {
            default_output_dir: None,
            default_speed: "balanced".to_string(),
            default_encryption: "password".to_string(),
            session_ttl_secs: 1_800,
            recent_projects: Vec::new(),
            language: default_language(),
        }
    }
}

fn default_language() -> String {
    "system".to_string()
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct AppSnapshot {
    version: &'static str,
    platform: &'static str,
    settings: AppSettings,
    daemon_active: bool,
    session_active: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct StartPackRequest {
    input_dir: String,
    output_file: String,
    password: Option<String>,
    encryption: String,
    speed: String,
    cache_dir: Option<String>,
    trust_metadata: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct StartUnpackRequest {
    archive_file: String,
    output_dir: String,
    password: Option<String>,
    overwrite: bool,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct TaskStatus {
    id: String,
    kind: OperationKind,
    phase: OperationPhase,
    files_done: u64,
    files_total: Option<u64>,
    bytes_done: u64,
    bytes_total: Option<u64>,
    elapsed_us: u64,
    message: Option<String>,
    output_path: Option<String>,
    archive_bytes: Option<u64>,
    input_bytes: Option<u64>,
    error: Option<AppError>,
    cancellable: bool,
}

struct TaskRecord {
    status: TaskStatus,
    cache_dir: PathBuf,
}

#[derive(Default)]
struct DesktopState {
    tasks: Mutex<BTreeMap<String, TaskRecord>>,
    settings: Mutex<AppSettings>,
}

fn settings_path(app: &AppHandle) -> AppResult<PathBuf> {
    let root = app
        .path()
        .app_data_dir()
        .map_err(|error| AppError::from_error("settings_path", error, false))?;
    fs::create_dir_all(&root)
        .map_err(|error| AppError::from_error("settings_create", error, false))?;
    Ok(root.join("settings.json"))
}

fn save_settings(app: &AppHandle, settings: &AppSettings) -> AppResult<()> {
    let bytes = serde_json::to_vec_pretty(settings)
        .map_err(|error| AppError::from_error("settings_encode", error, false))?;
    fs::write(settings_path(app)?, bytes)
        .map_err(|error| AppError::from_error("settings_write", error, true))
}

fn load_settings(app: &AppHandle) -> AppSettings {
    settings_path(app)
        .ok()
        .and_then(|path| fs::read(path).ok())
        .and_then(|bytes| serde_json::from_slice(&bytes).ok())
        .unwrap_or_default()
}

fn default_cache_dir() -> PathBuf {
    std::env::temp_dir().join("hig-desktop-cache")
}

fn sidecar_path() -> AppResult<PathBuf> {
    let executable = std::env::current_exe()
        .map_err(|error| AppError::from_error("sidecar_path", error, false))?;
    let sibling = executable.with_file_name("hig");
    if sibling.is_file() {
        return Ok(sibling);
    }
    let development = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../../target/debug/hig");
    if development.is_file() {
        return Ok(development);
    }
    Err(AppError::from_error(
        "sidecar_missing",
        "The bundled Hig command-line engine is missing",
        false,
    ))
}

fn ensure_daemon(cache_dir: &Path, ttl_secs: u64) -> AppResult<()> {
    if daemon_status(cache_dir).is_ok_and(|status| status.active) {
        return Ok(());
    }
    fs::create_dir_all(cache_dir)
        .map_err(|error| AppError::from_error("cache_create", error, true))?;
    Command::new(sidecar_path()?)
        .args([
            "daemon",
            "serve",
            "--cache-dir",
            &cache_dir.to_string_lossy(),
            "--ttl-secs",
            &ttl_secs.to_string(),
        ])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|error| AppError::from_error("daemon_start", error, true))?;
    for _ in 0..100 {
        if daemon_status(cache_dir).is_ok_and(|status| status.active) {
            return Ok(());
        }
        std::thread::sleep(Duration::from_millis(20));
    }
    Err(AppError::from_error(
        "daemon_unavailable",
        "The Hig daemon did not become ready",
        true,
    ))
}

fn task_id_hex(id: &[u8; 16]) -> String {
    hex::encode(id)
}

fn decode_task_id(value: &str) -> AppResult<[u8; 16]> {
    let bytes =
        hex::decode(value).map_err(|error| AppError::from_error("task_id", error, false))?;
    bytes
        .try_into()
        .map_err(|_| AppError::from_error("task_id", "Task id must be 16 bytes", false))
}

#[cfg(test)]
fn temp_output_path(output: &Path, task_id: &str) -> PathBuf {
    let name = output
        .file_name()
        .and_then(|value| value.to_str())
        .unwrap_or("archive.hig");
    output.with_file_name(format!(".{name}.hig-ui-task-{task_id}"))
}

fn task_status_from_report(report: TaskStatusReport) -> TaskStatus {
    TaskStatus {
        id: task_id_hex(&report.task_id),
        kind: report.kind,
        phase: report.progress.phase,
        files_done: report.progress.files_done,
        files_total: report.progress.files_total,
        bytes_done: report.progress.bytes_done,
        bytes_total: report.progress.bytes_total,
        elapsed_us: report.progress.elapsed_us,
        message: report.progress.message,
        output_path: report
            .output_path
            .as_ref()
            .map(|path| path.display().to_string()),
        archive_bytes: None,
        input_bytes: None,
        error: report.error.map(|error| AppError {
            code: error.code,
            message: error.message,
            recoverable: error.recoverable,
        }),
        cancellable: report.cancellable
            && matches!(report.state, TaskState::Queued | TaskState::Running),
    }
}

fn task_status_from_result(mut status: TaskStatus, result: Option<TaskResult>) -> TaskStatus {
    match result {
        Some(TaskResult::Pack { report }) => {
            status.phase = OperationPhase::Completed;
            status.archive_bytes = Some(report.archive_bytes);
            status.input_bytes = Some(report.input_bytes);
            status.message = Some("Archive created".to_string());
            status.cancellable = false;
        }
        Some(TaskResult::Unpack { .. }) => {
            status.phase = OperationPhase::Completed;
            status.message = Some("Archive extracted".to_string());
            status.cancellable = false;
        }
        Some(TaskResult::CacheMaintenance(_)) | Some(TaskResult::ProjectRebuild(_)) => {
            status.phase = OperationPhase::Completed;
            status.message = Some("Task completed".to_string());
            status.cancellable = false;
        }
        Some(TaskResult::Cancelled) => {
            status.phase = OperationPhase::Cancelled;
            status.message = Some("Cancelled safely".to_string());
            status.cancellable = false;
        }
        Some(TaskResult::Failed(error)) => {
            status.phase = OperationPhase::Failed;
            status.error = Some(AppError {
                code: error.code,
                message: error.message,
                recoverable: error.recoverable,
            });
            status.cancellable = false;
        }
        None => {}
    }
    status
}

#[tauri::command]
fn bootstrap_app(app: AppHandle, state: State<'_, Arc<DesktopState>>) -> AppResult<AppSnapshot> {
    let settings = load_settings(&app);
    *state.settings.lock().expect("settings mutex poisoned") = settings.clone();
    let daemon = daemon_status(&default_cache_dir()).unwrap_or_default();
    Ok(AppSnapshot {
        version: env!("CARGO_PKG_VERSION"),
        platform: std::env::consts::OS,
        settings,
        daemon_active: daemon.active,
        session_active: daemon.session_active,
    })
}

#[tauri::command]
fn get_settings(state: State<'_, Arc<DesktopState>>) -> AppSettings {
    state
        .settings
        .lock()
        .expect("settings mutex poisoned")
        .clone()
}

#[tauri::command]
fn update_settings(
    app: AppHandle,
    state: State<'_, Arc<DesktopState>>,
    settings: AppSettings,
) -> AppResult<AppSettings> {
    save_settings(&app, &settings)?;
    *state.settings.lock().expect("settings mutex poisoned") = settings.clone();
    Ok(settings)
}

#[tauri::command]
fn initialize_project(
    app: AppHandle,
    state: State<'_, Arc<DesktopState>>,
    directory: String,
    cache_dir: Option<String>,
) -> AppResult<ProjectStatusReport> {
    let root = PathBuf::from(&directory);
    let config = init_project(&root, cache_dir.map(PathBuf::from), Vec::new())
        .map_err(|error| AppError::from_error("project_init", error, true))?;
    let root = root
        .canonicalize()
        .map_err(|error| AppError::from_error("project_path", error, true))?;
    let cache = resolve_project_cache_dir(&root, &config);
    let status = match request_daemon(
        &cache,
        DaemonRequest::ProjectRegister(hig_core::ProjectRegistration {
            root: root.clone(),
            config,
        }),
    ) {
        Ok(Some(DaemonResponse::ProjectRegistered(status))) => status,
        _ => ProjectStatusReport {
            initialized: true,
            root: root.display().to_string(),
            cache_dir: cache.display().to_string(),
            ..ProjectStatusReport::default()
        },
    };
    if let Ok(mut settings) = state.settings.lock() {
        settings.recent_projects.retain(|path| path != &directory);
        settings.recent_projects.insert(0, directory);
        settings.recent_projects.truncate(12);
        save_settings(&app, &settings)?;
    }
    Ok(status)
}

#[tauri::command]
fn get_project_status(directory: String) -> AppResult<ProjectStatusReport> {
    let (root, config) = discover_project(Path::new(&directory))
        .map_err(|error| AppError::from_error("project_discovery", error, true))?
        .ok_or_else(|| {
            AppError::from_error(
                "project_not_initialized",
                "Project is not initialized",
                true,
            )
        })?;
    let cache = resolve_project_cache_dir(&root, &config);
    match request_daemon(
        &cache,
        DaemonRequest::ProjectStatus {
            project_id: config.project_id,
        },
    ) {
        Ok(Some(DaemonResponse::ProjectStatus(status))) => Ok(status),
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            Err(AppError::from_error("project_status", message, true))
        }
        Ok(_) => Err(AppError::from_error(
            "daemon_unavailable",
            "Project watcher is offline",
            true,
        )),
        Err(error) => Err(AppError::from_error("daemon_unavailable", error, true)),
    }
}

#[tauri::command]
fn rebuild_project(directory: String) -> AppResult<ProjectStatusReport> {
    let (root, config) = discover_project(Path::new(&directory))
        .map_err(|error| AppError::from_error("project_discovery", error, true))?
        .ok_or_else(|| {
            AppError::from_error(
                "project_not_initialized",
                "Project is not initialized",
                true,
            )
        })?;
    let cache = resolve_project_cache_dir(&root, &config);
    match request_daemon(
        &cache,
        DaemonRequest::ProjectRebuild {
            project_id: config.project_id,
        },
    ) {
        Ok(Some(DaemonResponse::ProjectStatus(status))) => Ok(status),
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            Err(AppError::from_error("project_rebuild", message, true))
        }
        Ok(_) => Err(AppError::from_error(
            "daemon_unavailable",
            "Project watcher is offline",
            true,
        )),
        Err(error) => Err(AppError::from_error("daemon_unavailable", error, true)),
    }
}

#[tauri::command]
fn start_pack(
    app: AppHandle,
    state: State<'_, Arc<DesktopState>>,
    request: StartPackRequest,
) -> AppResult<TaskStatus> {
    let encryption = if request.encryption == "none" {
        EncryptionMode::None
    } else {
        EncryptionMode::Password
    };
    let speed = if request.speed == "fastest" {
        SpeedMode::Fastest
    } else {
        SpeedMode::Balanced
    };
    let cache_dir = request
        .cache_dir
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(&request.input_dir).join(".hig-cache"));
    ensure_daemon(&cache_dir, default_session_ttl(None))?;
    let mut password = request.password.map(Zeroizing::new);
    let kdf_profile = if speed == SpeedMode::Fastest {
        KdfProfile::Interactive
    } else {
        KdfProfile::Secure
    };
    let kdf = kdf_profile.params();
    let binding = derive_session_binding(&cache_dir, kdf_profile, &kdf, encryption);
    let mut ephemeral_key = None;
    let auth_mode = if encryption == EncryptionMode::None {
        PackAuthMode::None
    } else if let Some(password) = password.as_ref() {
        let salt = hig_core::random_bytes::<16>();
        let key = derive_key(password, &salt, &kdf)
            .map_err(|error| AppError::from_error("pack_kdf", error, true))?;
        ephemeral_key = Some(hig_core::JobKeyMaterial { key, salt });
        PackAuthMode::PreferSessionOrJobKey
    } else {
        PackAuthMode::UseSession
    };
    if let Some(password) = password.as_mut() {
        password.zeroize();
    }
    let options = SerializablePackOptions {
        input_dir: PathBuf::from(&request.input_dir),
        output_file: PathBuf::from(&request.output_file),
        encryption,
        threads: None,
        compression: Compression::Zstd,
        level: None,
        use_cache: true,
        trust_metadata: request.trust_metadata || speed == SpeedMode::Fastest,
        format: hig_core::ArchiveFormat::HigV2,
        batch: BatchOptions::default(),
        chunk: ChunkOptions::default(),
        speed,
        kdf_profile,
        sealed_cache: speed == SpeedMode::Fastest,
        manifest_format: ManifestFormat::Compact,
        use_session: false,
        session_required: false,
        solid: if speed == SpeedMode::Fastest {
            SolidMode::Off
        } else {
            SolidMode::Auto
        },
        pipeline: PipelineOptions::default(),
    };
    let response = request_daemon(
        &cache_dir,
        DaemonRequest::SubmitTask(TaskSubmitRequest {
            request: TaskRequest::Pack(PackJobRequest {
                options,
                binding_fingerprint: Some(binding.fingerprint),
                ephemeral_key,
                auth_mode,
                response_mode: hig_core::PackResponseMode::Full,
            }),
        }),
    );
    let report = match response {
        Ok(Some(DaemonResponse::TaskAccepted(report))) => report,
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            return Err(AppError::from_error("daemon_task", message, true));
        }
        Ok(_) => {
            return Err(AppError::from_error(
                "daemon_task",
                "Daemon returned an unexpected task response",
                true,
            ));
        }
        Err(error) => return Err(AppError::from_error("daemon_task", error, true)),
    };
    let mut status = task_status_from_report(report.clone());
    if let Ok(Some(DaemonResponse::TaskResult(result))) = request_daemon(
        &cache_dir,
        DaemonRequest::TaskResult {
            task_id: report.task_id,
        },
    ) {
        status = task_status_from_result(status, Some(result));
    }
    let id = status.id.clone();
    state.tasks.lock().expect("task mutex poisoned").insert(
        id.clone(),
        TaskRecord {
            status: status.clone(),
            cache_dir,
        },
    );
    let _ = app.emit("hig://task-progress", status.clone());
    Ok(status)
}

#[tauri::command]
fn start_unpack(
    app: AppHandle,
    state: State<'_, Arc<DesktopState>>,
    request: StartUnpackRequest,
) -> AppResult<TaskStatus> {
    let cache_dir = default_cache_dir();
    ensure_daemon(&cache_dir, default_session_ttl(None))?;
    let response = request_daemon(
        &cache_dir,
        DaemonRequest::SubmitTask(TaskSubmitRequest {
            request: TaskRequest::Unpack(UnpackJobRequest {
                options: SerializableUnpackOptions {
                    archive_file: PathBuf::from(request.archive_file),
                    output_dir: PathBuf::from(request.output_dir),
                    overwrite: request.overwrite,
                },
                password: request.password,
            }),
        }),
    );
    let report = match response {
        Ok(Some(DaemonResponse::TaskAccepted(report))) => report,
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            return Err(AppError::from_error("daemon_task", message, true));
        }
        Ok(_) => {
            return Err(AppError::from_error(
                "daemon_task",
                "Daemon returned an unexpected task response",
                true,
            ));
        }
        Err(error) => return Err(AppError::from_error("daemon_task", error, true)),
    };
    let mut status = task_status_from_report(report.clone());
    if let Ok(Some(DaemonResponse::TaskResult(result))) = request_daemon(
        &cache_dir,
        DaemonRequest::TaskResult {
            task_id: report.task_id,
        },
    ) {
        status = task_status_from_result(status, Some(result));
    }
    let id = status.id.clone();
    state.tasks.lock().expect("task mutex poisoned").insert(
        id,
        TaskRecord {
            status: status.clone(),
            cache_dir,
        },
    );
    let _ = app.emit("hig://task-progress", status.clone());
    Ok(status)
}

#[tauri::command]
fn inspect_archive(path: String, password: Option<String>) -> AppResult<ArchiveInspection> {
    let password = password.map(Zeroizing::new);
    inspect_hig_archive(Path::new(&path), password.as_deref().map(String::as_str))
        .map_err(|error| AppError::from_error("inspect_failed", error, true))
}

#[tauri::command]
fn get_task_status(state: State<'_, Arc<DesktopState>>, task_id: String) -> AppResult<TaskStatus> {
    let id = decode_task_id(&task_id)?;
    let mut tasks = state.tasks.lock().expect("task mutex poisoned");
    let task = tasks
        .get_mut(&task_id)
        .ok_or_else(|| AppError::from_error("task_not_found", "Task not found", false))?;
    match request_daemon(&task.cache_dir, DaemonRequest::TaskStatus { task_id: id }) {
        Ok(Some(DaemonResponse::TaskStatus(report))) => {
            task.status = task_status_from_report(report);
            if let Ok(Some(DaemonResponse::TaskResult(result))) =
                request_daemon(&task.cache_dir, DaemonRequest::TaskResult { task_id: id })
            {
                task.status = task_status_from_result(task.status.clone(), Some(result));
            }
            Ok(task.status.clone())
        }
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            Err(AppError::from_error("task_status", message, true))
        }
        Ok(_) => Ok(task.status.clone()),
        Err(error) => Err(AppError::from_error("task_status", error, true)),
    }
}

#[tauri::command]
fn list_tasks(state: State<'_, Arc<DesktopState>>) -> Vec<TaskStatus> {
    state
        .tasks
        .lock()
        .expect("task mutex poisoned")
        .values()
        .map(|task| task.status.clone())
        .collect()
}

#[tauri::command]
fn cancel_task(state: State<'_, Arc<DesktopState>>, task_id: String) -> AppResult<TaskStatus> {
    let mut tasks = state.tasks.lock().expect("task mutex poisoned");
    let task = tasks
        .get_mut(&task_id)
        .ok_or_else(|| AppError::from_error("task_not_found", "Task not found", false))?;
    let id = decode_task_id(&task_id)?;
    match request_daemon(&task.cache_dir, DaemonRequest::TaskCancel { task_id: id }) {
        Ok(Some(DaemonResponse::TaskStatus(report))) => {
            task.status = task_status_from_report(report);
            task.status.message = Some("Cancellation requested".to_string());
            Ok(task.status.clone())
        }
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            Err(AppError::from_error("task_cancel", message, true))
        }
        Ok(_) => Err(AppError::from_error(
            "task_cancel",
            "Daemon returned an unexpected cancel response",
            true,
        )),
        Err(error) => Err(AppError::from_error("task_cancel", error, true)),
    }
}

#[tauri::command]
fn get_cache_status(cache_dir: Option<String>) -> AppResult<hig_core::CacheMaintenanceReport> {
    cache_request(cache_dir, DaemonRequest::CacheStatus)
}

#[tauri::command]
fn run_cache_gc(
    cache_dir: Option<String>,
    dry_run: bool,
) -> AppResult<hig_core::CacheMaintenanceReport> {
    cache_request(cache_dir, DaemonRequest::CacheGc { dry_run })
}

#[tauri::command]
fn run_cache_compact(
    cache_dir: Option<String>,
    dry_run: bool,
) -> AppResult<hig_core::CacheMaintenanceReport> {
    cache_request(cache_dir, DaemonRequest::CacheCompact { dry_run })
}

fn cache_request(
    cache_dir: Option<String>,
    request: DaemonRequest,
) -> AppResult<hig_core::CacheMaintenanceReport> {
    let cache = cache_dir
        .map(PathBuf::from)
        .unwrap_or_else(default_cache_dir);
    match request_daemon(&cache, request) {
        Ok(Some(DaemonResponse::CacheMaintenance(report))) => Ok(report),
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            Err(AppError::from_error("cache_maintenance", message, true))
        }
        Ok(_) => Err(AppError::from_error(
            "daemon_unavailable",
            "Cache daemon is offline",
            true,
        )),
        Err(error) => Err(AppError::from_error("daemon_unavailable", error, true)),
    }
}

#[tauri::command]
fn get_session_status(cache_dir: Option<String>) -> AppResult<hig_core::DaemonStatus> {
    let cache = cache_dir
        .map(PathBuf::from)
        .unwrap_or_else(default_cache_dir);
    daemon_status(&cache).map_err(|error| AppError::from_error("session_status", error, true))
}

#[tauri::command]
fn unlock_session(
    cache_dir: Option<String>,
    password: String,
    ttl_secs: Option<u64>,
) -> AppResult<hig_core::DaemonStatus> {
    let cache = cache_dir
        .map(PathBuf::from)
        .unwrap_or_else(default_cache_dir);
    ensure_daemon(&cache, default_session_ttl(ttl_secs))?;
    let mut password = Zeroizing::new(password);
    let kdf_profile = KdfProfile::Secure;
    let kdf = kdf_profile.params();
    let binding = derive_session_binding(&cache, kdf_profile, &kdf, EncryptionMode::Password);
    let salt = match request_daemon(
        &cache,
        DaemonRequest::UnlockChallenge {
            binding: binding.clone(),
        },
    ) {
        Ok(Some(DaemonResponse::UnlockChallenge { salt })) => salt,
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            return Err(AppError::from_error("session_unlock", message, true));
        }
        Ok(_) => {
            return Err(AppError::from_error(
                "daemon_unavailable",
                "Daemon is offline",
                true,
            ));
        }
        Err(error) => return Err(AppError::from_error("daemon_unavailable", error, true)),
    };
    let mut key = derive_key(&password, &salt, &kdf)
        .map_err(|error| AppError::from_error("session_kdf", error, true))?;
    password.zeroize();
    let response = request_daemon(
        &cache,
        DaemonRequest::InstallSessionKey {
            binding,
            key,
            salt,
            ttl_secs: default_session_ttl(ttl_secs),
        },
    );
    key.zeroize();
    match response {
        Ok(Some(DaemonResponse::SessionInstalled)) => {
            get_session_status(Some(cache.display().to_string()))
        }
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            Err(AppError::from_error("session_unlock", message, true))
        }
        Ok(_) => Err(AppError::from_error(
            "session_unlock",
            "Session was not installed",
            true,
        )),
        Err(error) => Err(AppError::from_error("session_unlock", error, true)),
    }
}

#[tauri::command]
fn clear_session(cache_dir: Option<String>) -> AppResult<bool> {
    let cache = cache_dir
        .map(PathBuf::from)
        .unwrap_or_else(default_cache_dir);
    match request_daemon(&cache, DaemonRequest::ClearSession) {
        Ok(Some(DaemonResponse::SessionCleared)) => Ok(true),
        Ok(None) => Ok(false),
        Ok(Some(DaemonResponse::Error { message, .. })) => {
            Err(AppError::from_error("session_clear", message, true))
        }
        Ok(_) => Ok(false),
        Err(error) => Err(AppError::from_error("session_clear", error, true)),
    }
}

#[tauri::command]
fn current_unix_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let state = Arc::new(DesktopState::default());
    tauri::Builder::default()
        .manage(state)
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_shell::init())
        .invoke_handler(tauri::generate_handler![
            bootstrap_app,
            get_settings,
            update_settings,
            initialize_project,
            get_project_status,
            rebuild_project,
            start_pack,
            start_unpack,
            inspect_archive,
            get_task_status,
            list_tasks,
            cancel_task,
            get_cache_status,
            run_cache_gc,
            run_cache_compact,
            get_session_status,
            unlock_session,
            clear_session,
            current_unix_ms,
        ])
        .run(tauri::generate_context!())
        .expect("failed to run Hig desktop");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn task_temp_output_is_hidden_and_local_to_destination() {
        let output = Path::new("/tmp/releases/example.hig");
        let temporary = temp_output_path(output, "001122");
        assert_eq!(temporary.parent(), output.parent());
        assert_eq!(
            temporary.file_name().and_then(|name| name.to_str()),
            Some(".example.hig.hig-ui-task-001122")
        );
    }

    #[test]
    fn settings_serialization_contains_no_password_field() {
        let encoded = serde_json::to_string(&AppSettings::default()).unwrap();
        assert!(!encoded.to_ascii_lowercase().contains("benchmark-password"));
        assert!(!encoded.to_ascii_lowercase().contains("temporary-password"));
        assert!(!encoded.to_ascii_lowercase().contains("secret"));
    }

    #[test]
    fn legacy_settings_default_to_system_language() {
        let settings: AppSettings = serde_json::from_str(
            r#"{
                "defaultOutputDir": null,
                "defaultSpeed": "balanced",
                "defaultEncryption": "password",
                "sessionTtlSecs": 1800,
                "recentProjects": []
            }"#,
        )
        .unwrap();
        assert_eq!(settings.language, "system");
    }
}
