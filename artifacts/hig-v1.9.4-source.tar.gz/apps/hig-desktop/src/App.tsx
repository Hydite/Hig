import { useEffect, useMemo, useState } from "react";
import {
  Archive,
  ArchiveRestore,
  Boxes,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  Database,
  FolderArchive,
  FolderOpen,
  Gauge,
  KeyRound,
  ListTree,
  LoaderCircle,
  LockKeyhole,
  Menu,
  PackageOpen,
  Play,
  RefreshCw,
  Search,
  Settings as SettingsIcon,
  ShieldCheck,
  Square,
  Trash2,
  Unlock,
  X,
} from "lucide-react";
import { api } from "./api";
import { createTranslator, type I18nKey } from "./i18n";
import type {
  AppError,
  AppSnapshot,
  ArchiveInspection,
  CacheReport,
  NavId,
  ProjectStatus,
  Settings,
  TaskStatus,
} from "./types";

const navItems: Array<{ id: NavId; label: I18nKey; icon: typeof Archive }> = [
  { id: "projects", label: "nav.projects", icon: ListTree },
  { id: "create", label: "nav.create", icon: FolderArchive },
  { id: "open", label: "nav.open", icon: PackageOpen },
  { id: "tasks", label: "nav.tasks", icon: Gauge },
  { id: "cache", label: "nav.cache", icon: Database },
  { id: "settings", label: "nav.settings", icon: SettingsIcon },
];

const emptySettings: Settings = {
  defaultOutputDir: null,
  defaultSpeed: "balanced",
  defaultEncryption: "password",
  sessionTtlSecs: 1800,
  recentProjects: [],
  language: "system",
};

function normalizeSettings(settings: Settings): Settings {
  return { ...emptySettings, ...settings, language: settings.language ?? "system" };
}

function formatBytes(value: number | null | undefined): string {
  if (!value) return "0 B";
  const units = ["B", "KiB", "MiB", "GiB"];
  const power = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);
  return `${(value / 1024 ** power).toFixed(power === 0 ? 0 : 1)} ${units[power]}`;
}

function basename(path: string): string {
  return path.split(/[\\/]/).filter(Boolean).at(-1) ?? path;
}

function statusTone(phase: string): "ok" | "warn" | "bad" | "live" {
  if (phase === "Completed" || phase === "Ready") return "ok";
  if (phase === "Failed" || phase === "Invalid") return "bad";
  if (phase === "Cancelled" || phase === "Dirty") return "warn";
  return "live";
}

function asStatusKey(phase: string): I18nKey {
  const key = `status.${phase}` as I18nKey;
  return key;
}

function asTaskKindKey(kind: TaskStatus["kind"]): I18nKey {
  return `task.kind.${kind}` as I18nKey;
}

type Translator = ReturnType<typeof createTranslator>;

function appErrorMessage(error: unknown, i18n: Translator): string {
  if (typeof error === "string") return i18n.error(undefined, error);
  if (error && typeof error === "object") {
    const maybe = error as Partial<AppError>;
    return i18n.error(maybe.code, maybe.message);
  }
  return i18n.error(undefined);
}

export default function App() {
  const [nav, setNav] = useState<NavId>("projects");
  const [snapshot, setSnapshot] = useState<AppSnapshot | null>(null);
  const [localSettings, setLocalSettings] = useState<Settings>(emptySettings);
  const [tasks, setTasks] = useState<TaskStatus[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sessionDialog, setSessionDialog] = useState(false);
  const [sessionPassword, setSessionPassword] = useState("");

  const settings = localSettings;
  const i18n = useMemo(() => createTranslator(settings.language), [settings.language]);
  const { t } = i18n;

  useEffect(() => {
    api.bootstrap()
      .then((next) => {
        const normalized = normalizeSettings(next.settings);
        setLocalSettings(normalized);
        setSnapshot({ ...next, settings: normalized });
      })
      .catch((error) => setNotice(appErrorMessage(error, createTranslator(emptySettings.language))));
    const poll = window.setInterval(() => api.tasks().then(setTasks).catch(() => undefined), 500);
    return () => window.clearInterval(poll);
  }, []);

  const activeTasks = tasks.filter((task) => !["Completed", "Failed", "Cancelled"].includes(task.phase));
  const updateSnapshotSettings = (next: Settings) => {
    const normalized = normalizeSettings(next);
    setLocalSettings(normalized);
    setSnapshot((current) => current && { ...current, settings: normalized });
  };
  const onError = (error: unknown) => setNotice(appErrorMessage(error, i18n));
  const unlockSession = async () => {
    try {
      await api.unlockSession(sessionPassword, settings.sessionTtlSecs);
      setSessionPassword("");
      setSessionDialog(false);
      setSnapshot((current) => current && { ...current, daemonActive: true, sessionActive: true });
    } catch (error) {
      setSessionPassword("");
      onError(error);
    }
  };
  const clearSession = async () => {
    try {
      await api.clearSession();
      setSnapshot((current) => current && { ...current, sessionActive: false });
    } catch (error) {
      onError(error);
    }
  };

  return (
    <div className="app-shell" lang={i18n.language}>
      <aside className={sidebarOpen ? "sidebar is-open" : "sidebar"}>
        <div className="brand-row">
          <img src="/icon.png" alt="" className="brand-mark" />
          <div><strong>Hig</strong><span>{t("app.brandSubtitle")}</span></div>
          <button className="icon-button sidebar-close" onClick={() => setSidebarOpen(false)} aria-label={t("sidebar.close")}><X size={18} /></button>
        </div>
        <nav aria-label={t("sidebar.navigation")}>
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button key={item.id} className={nav === item.id ? "nav-item active" : "nav-item"} onClick={() => { setNav(item.id); setSidebarOpen(false); }}>
                <Icon size={18} /><span>{t(item.label)}</span>
                {item.id === "tasks" && activeTasks.length > 0 && <b>{activeTasks.length}</b>}
              </button>
            );
          })}
        </nav>
        <div className="sidebar-status">
          <div className="status-line"><span className={snapshot?.daemonActive ? "status-dot ok" : "status-dot"} />{snapshot?.daemonActive ? t("daemon.online") : t("daemon.offline")}</div>
          <button className="status-line session-action" onClick={() => snapshot?.sessionActive ? void clearSession() : setSessionDialog(true)}><KeyRound size={14} />{snapshot?.sessionActive ? t("session.unlocked") : t("session.locked")}</button>
          <small>v{snapshot?.version ?? "1.9.4"}</small>
        </div>
      </aside>

      <div className="workspace">
        <header className="topbar">
          <button className="icon-button menu-button" onClick={() => setSidebarOpen(true)} aria-label={t("sidebar.open")}><Menu size={20} /></button>
          <div><span className="eyebrow">{t("app.workspace")}</span><h1>{t(navItems.find((item) => item.id === nav)?.label ?? "nav.projects")}</h1></div>
          <div className="topbar-actions">
            {activeTasks.length > 0 && <button className="task-live" onClick={() => setNav("tasks")}><LoaderCircle size={15} className="spin" />{t("app.activeTasks", { count: activeTasks.length })}</button>}
            <span className="security-chip"><ShieldCheck size={15} />{t("app.secureDefaults")}</span>
          </div>
        </header>

        {notice && <div className="notice"><CircleAlert size={17} /><span>{notice}</span><button onClick={() => setNotice(null)} aria-label={t("app.dismiss")}><X size={16} /></button></div>}

        <main className="content">
          {nav === "projects" && <ProjectsPage settings={settings} i18n={i18n} onSettings={updateSnapshotSettings} onNavigate={setNav} onError={onError} />}
          {nav === "create" && <CreatePage settings={settings} i18n={i18n} onTask={(task) => { setTasks((items) => [task, ...items]); setNav("tasks"); }} onError={onError} />}
          {nav === "open" && <OpenArchivePage i18n={i18n} onTask={(task) => { setTasks((items) => [task, ...items]); setNav("tasks"); }} onError={onError} />}
          {nav === "tasks" && <TasksPage tasks={tasks} i18n={i18n} onTasks={setTasks} onError={onError} />}
          {nav === "cache" && <CachePage i18n={i18n} onError={onError} />}
          {nav === "settings" && <SettingsPage settings={settings} i18n={i18n} onSettings={updateSnapshotSettings} onError={onError} />}
        </main>
      </div>
      {sessionDialog && <div className="modal-backdrop" role="presentation" onMouseDown={() => { setSessionPassword(""); setSessionDialog(false); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="session-title" onMouseDown={(event) => event.stopPropagation()}><div className="modal-icon"><Unlock size={22} /></div><h2 id="session-title">{t("session.title")}</h2><p>{t("session.body", { minutes: Math.round(settings.sessionTtlSecs / 60) })}</p><label><span>{t("session.password")}</span><input autoFocus type="password" value={sessionPassword} onChange={(event) => setSessionPassword(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && sessionPassword) void unlockSession(); }} /></label><div className="modal-actions"><button className="secondary-button" onClick={() => { setSessionPassword(""); setSessionDialog(false); }}>{t("session.cancel")}</button><button className="primary-button" disabled={!sessionPassword} onClick={unlockSession}><KeyRound size={16} />{t("session.unlock")}</button></div></section></div>}
    </div>
  );
}

function ProjectsPage({ settings, i18n, onSettings, onNavigate, onError }: { settings: Settings; i18n: Translator; onSettings: (settings: Settings) => void; onNavigate: (nav: NavId) => void; onError: (error: unknown) => void }) {
  const { t } = i18n;
  const [statuses, setStatuses] = useState<Record<string, ProjectStatus>>({});
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    settings.recentProjects.forEach((path) => api.projectStatus(path).then((status) => setStatuses((current) => ({ ...current, [path]: status }))).catch(() => undefined));
  }, [settings.recentProjects]);

  const addProject = async () => {
    const directory = await api.chooseDirectory();
    if (!directory) return;
    setBusy(true);
    try {
      const status = await api.initializeProject(directory);
      setStatuses((current) => ({ ...current, [directory]: status }));
      const next = { ...settings, recentProjects: [directory, ...settings.recentProjects.filter((path) => path !== directory)].slice(0, 12) };
      onSettings(await api.updateSettings(next));
    } catch (error) { onError(error); } finally { setBusy(false); }
  };

  return (
    <div className="page-stack">
      <section className="page-heading">
        <div><h2>{t("projects.title")}</h2><p>{t("projects.subtitle")}</p></div>
        <button className="primary-button" onClick={addProject} disabled={busy}><FolderOpen size={17} />{t("projects.initialize")}</button>
      </section>
      {settings.recentProjects.length === 0 ? (
        <section className="empty-state"><ListTree size={28} /><h3>{t("projects.emptyTitle")}</h3><p>{t("projects.emptyBody")}</p><button className="secondary-button" onClick={addProject}>{t("projects.choose")}</button></section>
      ) : (
        <div className="project-list">
          {settings.recentProjects.map((path) => {
            const status = statuses[path];
            const state = status?.snapshotValidity ?? "Building";
            return <article className="project-row" key={path}>
              <div className={`project-icon ${statusTone(state)}`}><Boxes size={20} /></div>
              <div className="project-main"><div className="project-name"><strong>{basename(path)}</strong><span className={`badge ${statusTone(state)}`}>{t(asStatusKey(state))}</span></div><code title={path}>{path}</code></div>
              <dl><div><dt>{t("projects.files")}</dt><dd>{status?.files?.toLocaleString() ?? "—"}</dd></div><div><dt>{t("projects.generation")}</dt><dd>{status?.generation ?? "—"}</dd></div><div><dt>{t("projects.prepared")}</dt><dd>{formatBytes(status?.preparedBytes)}</dd></div></dl>
              <div className="row-actions"><button className="icon-button" title={t("projects.rebuild")} aria-label={t("projects.rebuild")} onClick={() => api.rebuildProject(path).then((next) => setStatuses((current) => ({ ...current, [path]: next }))).catch(onError)}><RefreshCw size={17} /></button><button className="secondary-button" onClick={() => onNavigate("create")}>{t("projects.archive")}<ChevronRight size={15} /></button></div>
            </article>;
          })}
        </div>
      )}
      <section className="metric-band"><div><span>{t("projects.metricMode")}</span><strong>{t("projects.metricVerified")}</strong></div><div><span>{t("projects.metricWatcher")}</span><strong>{t("projects.metricEventAware")}</strong></div><div><span>{t("projects.metricPrepared")}</span><strong>{t("projects.metricEncrypted")}</strong></div></section>
    </div>
  );
}

function CreatePage({ settings, i18n, onTask, onError }: { settings: Settings; i18n: Translator; onTask: (task: TaskStatus) => void; onError: (error: unknown) => void }) {
  const { t } = i18n;
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [password, setPassword] = useState("");
  const [speed, setSpeed] = useState(settings.defaultSpeed);
  const [encryption, setEncryption] = useState(settings.defaultEncryption);
  const [advanced, setAdvanced] = useState(false);
  const [trustMetadata, setTrustMetadata] = useState(false);
  const [busy, setBusy] = useState(false);

  const selectInput = async () => { const path = await api.chooseDirectory(); if (path) { setInput(path); if (!output) setOutput(`${path}.hig`); } };
  const selectOutput = async () => { const path = await api.chooseArchiveOutput(); if (path) setOutput(path); };
  const submit = async () => {
    if (!input || !output) return onError(t("create.missingPath"));
    if (encryption === "password" && !password) return onError(t("create.missingPassword"));
    setBusy(true);
    try {
      const task = await api.startPack({ inputDir: input, outputFile: output, password: encryption === "password" ? password : null, encryption, speed, cacheDir: null, trustMetadata: trustMetadata || speed === "fastest" });
      setPassword("");
      onTask(task);
    } catch (error) { onError(error); } finally { setBusy(false); }
  };

  return <div className="page-stack form-page">
    <section className="page-heading"><div><h2>{t("create.title")}</h2><p>{t("create.subtitle")}</p></div></section>
    <section className="form-section"><h3>{t("create.source")}</h3><PathField label={t("create.input")} value={input} placeholder={t("create.inputPlaceholder")} onChoose={selectInput} t={t} /><PathField label={t("create.output")} value={output} placeholder={t("create.outputPlaceholder")} onChoose={selectOutput} t={t} /></section>
    <section className="form-section"><h3>{t("create.policy")}</h3><div className="field-grid"><label><span>{t("create.speed")}</span><select aria-label={t("create.speed")} value={speed} onChange={(event) => setSpeed(event.target.value as "balanced" | "fastest")}><option value="balanced">{t("create.speedBalanced")}</option><option value="fastest">{t("create.speedFastest")}</option></select></label><label><span>{t("create.encryption")}</span><select aria-label={t("create.encryption")} value={encryption} onChange={(event) => setEncryption(event.target.value as "password" | "none")}><option value="password">{t("create.encryptionPassword")}</option><option value="none">{t("create.encryptionNone")}</option></select></label></div>{encryption === "password" ? <label className="password-field"><span>{t("create.password")}</span><div><LockKeyhole size={17} /><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="new-password" placeholder={t("create.passwordPlaceholder")} /></div></label> : <div className="warning-line"><CircleAlert size={17} />{t("create.noEncryptionWarning")}</div>}{speed === "fastest" && <div className="warning-line"><CircleAlert size={17} />{t("create.fastestWarning")}</div>}</section>
    <section className="advanced-toggle"><button onClick={() => setAdvanced(!advanced)}>{t("create.advanced")}<ChevronRight className={advanced ? "rotate" : ""} size={16} /></button>{advanced && <div className="advanced-panel"><label className="check-row"><input type="checkbox" checked={trustMetadata} onChange={(event) => setTrustMetadata(event.target.checked)} /><span><strong>{t("create.trustMetadata")}</strong><small>{t("create.trustMetadataHelp")}</small></span></label><div className="policy-readout"><span>{t("create.batch")}</span><b>{t("create.auto4MiB")}</b><span>{t("create.chunks")}</span><b>{t("create.chunkPolicy")}</b><span>{t("create.solidGroups")}</span><b>{speed === "balanced" ? t("create.auto") : t("create.off")}</b></div></div>}</section>
    <footer className="form-footer"><div><ShieldCheck size={18} /><span>{encryption === "password" ? t("create.securityPassword") : t("create.securityNone")}</span></div><button className="primary-button" onClick={submit} disabled={busy}><Play size={17} />{busy ? t("create.starting") : t("create.submit")}</button></footer>
  </div>;
}

function PathField({ label, value, placeholder, onChoose, t }: { label: string; value: string; placeholder: string; onChoose: () => void; t: Translator["t"] }) {
  return <label className="path-field"><span>{label}</span><div><code title={value || placeholder}>{value || placeholder}</code><button className="icon-button" onClick={onChoose} type="button" aria-label={t("path.choose", { label })}><FolderOpen size={18} /></button></div></label>;
}

function OpenArchivePage({ i18n, onTask, onError }: { i18n: Translator; onTask: (task: TaskStatus) => void; onError: (error: unknown) => void }) {
  const { t } = i18n;
  const [path, setPath] = useState("");
  const [password, setPassword] = useState("");
  const [inspection, setInspection] = useState<ArchiveInspection | null>(null);
  const [query, setQuery] = useState("");
  const [output, setOutput] = useState("");
  const files = useMemo(() => inspection?.files.filter((file) => file.relativePath.toLowerCase().includes(query.toLowerCase())) ?? [], [inspection, query]);
  const choose = async () => { const next = await api.chooseArchive(); if (next) { setPath(next); setInspection(null); } };
  const inspect = async () => { try { const result = await api.inspectArchive(path, password); setInspection(result); setPassword(""); } catch (error) { onError(error); } };
  const extract = async () => { if (!output) return onError(t("open.missingOutput")); try { const task = await api.startUnpack({ archiveFile: path, outputDir: output, password: password || null, overwrite: false }); setPassword(""); onTask(task); } catch (error) { onError(error); } };
  return <div className="page-stack"><section className="page-heading"><div><h2>{t("open.title")}</h2><p>{t("open.subtitle")}</p></div><button className="secondary-button" onClick={choose}><FolderOpen size={17} />{t("open.choose")}</button></section><section className="archive-toolbar"><code title={path || t("open.noArchive")}>{path || t("open.noArchive")}</code><label><LockKeyhole size={16} /><input type="password" placeholder={t("open.passwordPlaceholder")} value={password} onChange={(event) => setPassword(event.target.value)} /></label><button className="primary-button" disabled={!path} onClick={inspect}><Search size={16} />{t("open.inspect")}</button></section>{inspection ? <><section className="archive-summary"><div><span>{t("open.format")}</span><strong>{inspection.format}</strong></div><div><span>{t("open.files")}</span><strong>{inspection.files.length.toLocaleString()}</strong></div><div><span>{t("open.original")}</span><strong>{formatBytes(inspection.inputBytes)}</strong></div><div><span>{t("open.archive")}</span><strong>{formatBytes(inspection.archiveBytes)}</strong></div><div><span>{t("open.security")}</span><strong>{inspection.encrypted ? t("open.encrypted") : t("open.integrityOnly")}</strong></div></section><section className="file-browser"><div className="table-toolbar"><h3>{t("open.contents")}</h3><label><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t("open.filter")} /></label></div><div className="file-table" role="table"><div className="file-row header" role="row"><span>{t("open.path")}</span><span>{t("open.size")}</span><span>{t("open.mode")}</span></div>{files.slice(0, 500).map((file) => <div className="file-row" role="row" key={file.relativePath}><span title={file.relativePath}>{file.relativePath}</span><span>{formatBytes(file.size)}</span><span>{file.permissions.toString(8)}</span></div>)}</div>{files.length > 500 && <small className="table-note">{t("open.showing", { count: files.length.toLocaleString() })}</small>}</section><section className="extract-bar"><PathField label={t("open.extractTo")} value={output} placeholder={t("open.extractPlaceholder")} t={t} onChoose={async () => { const selected = await api.chooseDirectory(); if (selected) setOutput(selected); }} /><button className="primary-button" onClick={extract}><ArchiveRestore size={17} />{t("open.extract")}</button></section></> : <section className="empty-state compact"><Archive size={28} /><h3>{t("open.emptyTitle")}</h3><p>{t("open.emptyBody")}</p></section>}</div>;
}

function TasksPage({ tasks, i18n, onTasks, onError }: { tasks: TaskStatus[]; i18n: Translator; onTasks: (tasks: TaskStatus[]) => void; onError: (error: unknown) => void }) {
  const { t } = i18n;
  const cancel = async (id: string) => { try { const next = await api.cancelTask(id); onTasks(tasks.map((task) => task.id === id ? next : task)); } catch (error) { onError(error); } };
  const clearCompleted = () => onTasks(tasks.filter((task) => !["Completed", "Failed", "Cancelled"].includes(task.phase)));
  return <div className="page-stack"><section className="page-heading"><div><h2>{t("tasks.title")}</h2><p>{t("tasks.subtitle")}</p></div><div className="heading-actions"><span className="count-label">{t("tasks.count", { count: tasks.length })}</span>{tasks.some((task) => ["Completed", "Failed", "Cancelled"].includes(task.phase)) && <button className="secondary-button" onClick={clearCompleted}>{t("tasks.clearLocal")}</button>}</div></section>{tasks.length === 0 ? <section className="empty-state"><Gauge size={28} /><h3>{t("tasks.emptyTitle")}</h3><p>{t("tasks.emptyBody")}</p></section> : <div className="task-list">{[...tasks].reverse().map((task) => <article className="task-row" key={task.id}><div className={`task-state ${statusTone(task.phase)}`}>{task.phase === "Completed" ? <CheckCircle2 size={20} /> : task.phase === "Failed" ? <CircleAlert size={20} /> : task.phase === "Cancelled" ? <Square size={18} /> : <LoaderCircle className="spin" size={20} />}</div><div className="task-main"><div><strong>{t(asTaskKindKey(task.kind))}</strong><span className={`badge ${statusTone(task.phase)}`}>{t(asStatusKey(task.phase))}</span></div><code title={task.outputPath ?? task.id}>{task.outputPath ?? task.id.slice(0, 12)}</code><div className="progress-track"><span style={{ width: task.bytesTotal ? `${Math.min(100, task.bytesDone / task.bytesTotal * 100)}%` : task.phase === "Completed" ? "100%" : "35%" }} /></div><small>{task.message ?? t(asStatusKey(task.phase))}{task.archiveBytes ? ` · ${formatBytes(task.archiveBytes)}` : ""}</small>{task.error && <p className="task-error">{appErrorMessage(task.error, i18n)} <code>{task.error.code}</code></p>}</div><div className="task-actions">{task.cancellable && <button className="icon-button danger" title={t("tasks.cancel")} aria-label={t("tasks.cancel")} onClick={() => cancel(task.id)}><Square size={16} /></button>}</div></article>)}</div>}</div>;
}

function CachePage({ i18n, onError }: { i18n: Translator; onError: (error: unknown) => void }) {
  const { t } = i18n;
  const [report, setReport] = useState<CacheReport | null>(null);
  const refresh = () => api.cacheStatus().then(setReport).catch(onError);
  useEffect(() => {
    void api.cacheStatus().then(setReport).catch(onError);
  }, [onError]);
  const maintain = async (kind: "gc" | "compact") => { try { const preview = kind === "gc" ? await api.cacheGc(undefined, true) : await api.cacheCompact(undefined, true); const bytes = formatBytes(preview.removableBytes || preview.journalEstimatedReclaimedBytes); if (window.confirm(kind === "gc" ? t("cache.confirmGc", { bytes }) : t("cache.confirmCompact", { bytes }))) { setReport(kind === "gc" ? await api.cacheGc(undefined, false) : await api.cacheCompact(undefined, false)); } } catch (error) { onError(error); } };
  return <div className="page-stack"><section className="page-heading"><div><h2>{t("cache.title")}</h2><p>{t("cache.subtitle")}</p></div><button className="icon-button" onClick={refresh} title={t("cache.refresh")} aria-label={t("cache.refresh")}><RefreshCw size={18} /></button></section>{report ? <><section className="cache-usage"><div className="cache-gauge"><span style={{ width: `${Math.min(100, report.totalBytes / Math.max(1, report.budgetBytes) * 100)}%` }} /></div><div><strong>{formatBytes(report.totalBytes)}</strong><span>{t("cache.budget", { bytes: formatBytes(report.budgetBytes) })}</span></div></section><section className="stats-grid"><div><span>{t("cache.objects")}</span><strong>{report.files.toLocaleString()}</strong></div><div><span>{t("cache.generation")}</span><strong>{report.generation}</strong></div><div><span>{t("cache.journal")}</span><strong>{formatBytes(report.journalBytes)}</strong></div><div><span>{t("cache.entries")}</span><strong>{report.journalEntries.toLocaleString()}</strong></div></section><section className="maintenance-list"><div><div><Trash2 size={20} /><span><strong>{t("cache.gc")}</strong><small>{t("cache.gcBody")}</small></span></div><button className="secondary-button" onClick={() => maintain("gc")}>{t("cache.gcAction")}</button></div><div><div><Database size={20} /><span><strong>{t("cache.compact")}</strong><small>{report.journalCompactRecommended ? t("cache.compactRecommended") : t("cache.compactHealthy")}</small></span></div><button className="secondary-button" onClick={() => maintain("compact")}>{t("cache.compactAction")}</button></div></section></> : <section className="empty-state compact"><Database size={28} /><h3>{t("cache.emptyTitle")}</h3><p>{t("cache.emptyBody")}</p></section>}</div>;
}

function SettingsPage({ settings, i18n, onSettings, onError }: { settings: Settings; i18n: Translator; onSettings: (settings: Settings) => void; onError: (error: unknown) => void }) {
  const { t } = i18n;
  const [draft, setDraft] = useState(settings);
  useEffect(() => setDraft(settings), [settings]);
  const save = async () => { try { onSettings(await api.updateSettings(normalizeSettings(draft))); } catch (error) { onError(error); } };
  const clearRecent = () => setDraft({ ...draft, recentProjects: [] });
  const previewLanguage = (language: Settings["language"]) => {
    const next = { ...draft, language };
    setDraft(next);
    onSettings(next);
  };
  return <div className="page-stack form-page"><section className="page-heading"><div><h2>{t("settings.title")}</h2><p>{t("settings.subtitle")}</p></div></section><section className="form-section"><h3>{t("settings.archiveDefaults")}</h3><div className="field-grid"><label><span>{t("settings.language")}</span><select aria-label={t("settings.language")} value={draft.language ?? "system"} onChange={(event) => previewLanguage(event.target.value as Settings["language"])}><option value="system">{t("settings.languageSystem")}</option><option value="en">{t("settings.languageEnglish")}</option><option value="zh-CN">{t("settings.languageChinese")}</option></select></label><label><span>{t("settings.speed")}</span><select value={draft.defaultSpeed} onChange={(event) => setDraft({ ...draft, defaultSpeed: event.target.value as Settings["defaultSpeed"] })}><option value="balanced">{t("create.speedBalanced")}</option><option value="fastest">{t("create.speedFastest")}</option></select></label><label><span>{t("settings.encryption")}</span><select value={draft.defaultEncryption} onChange={(event) => setDraft({ ...draft, defaultEncryption: event.target.value as Settings["defaultEncryption"] })}><option value="password">{t("settings.password")}</option><option value="none">{t("settings.none")}</option></select></label><label><span>{t("settings.ttl")}</span><select value={draft.sessionTtlSecs} onChange={(event) => setDraft({ ...draft, sessionTtlSecs: Number(event.target.value) })}><option value={900}>{t("settings.15m")}</option><option value={1800}>{t("settings.30m")}</option><option value={3600}>{t("settings.1h")}</option><option value={7200}>{t("settings.2h")}</option></select></label></div></section><section className="form-section"><h3>{t("settings.security")}</h3><div className="security-note"><ShieldCheck size={21} /><div><strong>{t("settings.securityTitle")}</strong><p>{t("settings.securityBody")}</p></div></div></section><footer className="form-footer"><span>{t("settings.recent", { count: draft.recentProjects.length })}</span><div className="footer-actions"><button className="secondary-button" onClick={clearRecent} disabled={draft.recentProjects.length === 0}>{t("settings.clearRecent")}</button><button className="primary-button" onClick={save}>{t("settings.save")}</button></div></footer></div>;
}
